"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const appointments = [
  {
    id: "1",
    patient: "Sarah Johnson",
    time: "9:00 AM",
    type: "Cleaning",
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "SJ",
  },
  {
    id: "2",
    patient: "Michael Brown",
    time: "10:30 AM",
    type: "Checkup",
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "MB",
  },
  {
    id: "3",
    patient: "Emily Davis",
    time: "11:45 AM",
    type: "Filling",
    status: "Pending",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "ED",
  },
  {
    id: "4",
    patient: "Robert Wilson",
    time: "1:15 PM",
    type: "Root Canal",
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "RW",
  },
  {
    id: "5",
    patient: "Jennifer Lee",
    time: "2:30 PM",
    type: "Checkup",
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "JL",
  },
]

export function RecentAppointments() {
  return (
    <div className="space-y-4">
      {appointments.map((appointment) => (
        <div key={appointment.id} className="flex items-center justify-between space-x-4 rounded-md border p-4">
          <div className="flex items-center space-x-4">
            <Avatar>
              <AvatarImage src={appointment.avatar} alt={appointment.patient} />
              <AvatarFallback>{appointment.initials}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium leading-none">{appointment.patient}</p>
              <p className="text-sm text-muted-foreground">
                {appointment.time} - {appointment.type}
              </p>
            </div>
          </div>
          <Badge variant={appointment.status === "Confirmed" ? "default" : "secondary"}>{appointment.status}</Badge>
        </div>
      ))}
    </div>
  )
}


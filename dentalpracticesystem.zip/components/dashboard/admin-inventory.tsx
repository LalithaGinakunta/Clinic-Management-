"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Package, Search, Filter, Plus } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const inventoryItems = [
  {
    id: "1",
    name: "Dental Composite",
    category: "Materials",
    currentStock: 15,
    minStock: 10,
    supplier: "Dental Supplies Co.",
    status: "In Stock",
  },
  {
    id: "2",
    name: "Disposable Gloves (S)",
    category: "Supplies",
    currentStock: 5,
    minStock: 20,
    supplier: "Medical Essentials",
    status: "Low Stock",
  },
  {
    id: "3",
    name: "Dental Anesthetic",
    category: "Medications",
    currentStock: 8,
    minStock: 15,
    supplier: "Pharma Solutions",
    status: "Low Stock",
  },
  {
    id: "4",
    name: "Sterilization Pouches",
    category: "Supplies",
    currentStock: 2,
    minStock: 15,
    supplier: "Medical Essentials",
    status: "Critical",
  },
]

export function AdminInventory() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Inventory Status</CardTitle>
          <CardDescription>Monitor stock levels and reorder supplies</CardDescription>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Inventory Item
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4 justify-between">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder="Search inventory..." className="w-full pl-8" />
          </div>
          <div className="flex gap-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="materials">Materials</SelectItem>
                <SelectItem value="supplies">Supplies</SelectItem>
                <SelectItem value="medications">Medications</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="all">
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="in-stock">In Stock</SelectItem>
                <SelectItem value="low-stock">Low Stock</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          {inventoryItems.map((item) => (
            <div
              key={item.id}
              className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0 md:space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
            >
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="rounded-full bg-primary/10 p-1.5">
                      <Package className="h-4 w-4 text-primary" />
                    </div>
                    <p className="font-medium">{item.name}</p>
                  </div>
                  <Badge
                    variant={
                      item.status === "In Stock" ? "default" : item.status === "Low Stock" ? "outline" : "destructive"
                    }
                    className={
                      item.status === "In Stock"
                        ? "bg-green-500 hover:bg-green-600"
                        : item.status === "Low Stock"
                          ? "border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100"
                          : ""
                    }
                  >
                    {item.status}
                  </Badge>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mb-1">
                  <span>Current: {item.currentStock}</span>
                  <span>Minimum: {item.minStock}</span>
                </div>
                <Progress
                  value={(item.currentStock / item.minStock) * 100}
                  className="h-2"
                  indicatorClassName={
                    item.status === "Critical"
                      ? "bg-destructive"
                      : item.status === "Low Stock"
                        ? "bg-amber-500"
                        : "bg-green-500"
                  }
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Category: {item.category}</span>
                  <span>Supplier: {item.supplier}</span>
                </div>
              </div>
              <div className="flex space-x-2 self-end md:self-center">
                <Button size="sm" variant="outline">
                  Edit
                </Button>
                <Button size="sm" className="bg-primary hover:bg-primary/90">
                  Reorder
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}


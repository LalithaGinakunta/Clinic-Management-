"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageSquare, FileText, Calendar, AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const recentPatients = [
  {
    id: "1",
    name: "Sarah Johnson",
    lastVisit: "Yesterday",
    reason: "Dental Cleaning",
    nextAppointment: "In 6 months",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "SJ",
    alert: "Allergic to penicillin",
    status: "Active",
  },
  {
    id: "2",
    name: "Michael Brown",
    lastVisit: "3 days ago",
    reason: "Tooth Pain",
    nextAppointment: "Next week",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "MB",
    alert: null,
    status: "Active",
  },
  {
    id: "3",
    name: "Emily Davis",
    lastVisit: "1 week ago",
    reason: "Filling",
    nextAppointment: "In 3 months",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "ED",
    alert: "Requires pre-medication",
    status: "Active",
  },
  {
    id: "4",
    name: "Robert Wilson",
    lastVisit: "2 weeks ago",
    reason: "Root Canal",
    nextAppointment: "Tomorrow",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "RW",
    alert: null,
    status: "Active",
  },
]

export function DentistPatients() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Recent Patients</CardTitle>
          <CardDescription>Patients you've seen recently</CardDescription>
        </div>
        <Button variant="outline" size="sm">
          View All Patients
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentPatients.map((patient) => (
            <div
              key={patient.id}
              className="flex items-center justify-between space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
            >
              <div className="flex items-center space-x-4">
                <Avatar>
                  <AvatarImage src={patient.avatar} alt={patient.name} />
                  <AvatarFallback className="bg-primary/10 text-primary">{patient.initials}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium leading-none">{patient.name}</p>
                    <Badge variant="outline" className="text-xs">
                      {patient.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Last visit: {patient.lastVisit} ({patient.reason})
                  </p>
                  <div className="flex items-center text-xs text-muted-foreground mt-1">
                    <Calendar className="mr-1 h-3 w-3 text-primary" />
                    <span>Next appointment: {patient.nextAppointment}</span>
                  </div>
                  {patient.alert && (
                    <div className="flex items-center text-xs text-red-500 mt-1">
                      <AlertCircle className="mr-1 h-3 w-3" />
                      <span>{patient.alert}</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 hover:text-blue-800"
                >
                  <FileText className="mr-2 h-4 w-4" />
                  Records
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-green-200 bg-green-50 text-green-700 hover:bg-green-100 hover:text-green-800"
                >
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Message
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}


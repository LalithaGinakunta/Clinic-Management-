"use client"

import type React from "react"

import { useState } from "react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { CalendarIcon } from "lucide-react"

interface AppointmentFormProps {
  isOpen: boolean
  onClose: () => void
  selectedDate?: Date
  userRole?: "dentist" | "admin" | "patient"
}

export function AppointmentForm({ isOpen, onClose, selectedDate, userRole = "admin" }: AppointmentFormProps) {
  const [date, setDate] = useState<Date | undefined>(selectedDate)
  const [appointmentType, setAppointmentType] = useState("")
  const [time, setTime] = useState("")
  const [patient, setPatient] = useState("")
  const [dentist, setDentist] = useState("")
  const [notes, setNotes] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would handle the form submission, e.g., by calling an API
    console.log({
      type: appointmentType,
      time,
      patient,
      dentist,
      notes,
      date,
    })
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[550px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>{userRole === "patient" ? "Book Appointment" : "Schedule Appointment"}</DialogTitle>
            <DialogDescription>
              {selectedDate
                ? `Schedule an appointment for ${format(selectedDate, "MMMM d, yyyy")}`
                : "Schedule a new appointment"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="date" className="text-right">
                Date
              </Label>
              <div className="col-span-3">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {(userRole === "admin" || userRole === "dentist") && (
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="patient" className="text-right">
                  Patient
                </Label>
                <div className="col-span-3">
                  <Select value={patient} onValueChange={setPatient} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select patient" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sarah-johnson">Sarah Johnson</SelectItem>
                      <SelectItem value="michael-brown">Michael Brown</SelectItem>
                      <SelectItem value="emily-davis">Emily Davis</SelectItem>
                      <SelectItem value="robert-wilson">Robert Wilson</SelectItem>
                      <SelectItem value="jennifer-lee">Jennifer Lee</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {(userRole === "admin" || userRole === "patient") && (
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="dentist" className="text-right">
                  Dentist
                </Label>
                <div className="col-span-3">
                  <Select value={dentist} onValueChange={setDentist} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select dentist" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dr-emily-white">Dr. Emily White</SelectItem>
                      <SelectItem value="dr-james-miller">Dr. James Miller</SelectItem>
                      <SelectItem value="dr-sarah-johnson">Dr. Sarah Johnson</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="type" className="text-right">
                Type
              </Label>
              <div className="col-span-3">
                <Select value={appointmentType} onValueChange={setAppointmentType} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select appointment type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cleaning">Cleaning</SelectItem>
                    <SelectItem value="checkup">Checkup</SelectItem>
                    <SelectItem value="filling">Filling</SelectItem>
                    <SelectItem value="rootcanal">Root Canal</SelectItem>
                    <SelectItem value="extraction">Extraction</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="time" className="text-right">
                Time
              </Label>
              <div className="col-span-3">
                <Select value={time} onValueChange={setTime} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="9:00">9:00 AM</SelectItem>
                    <SelectItem value="9:30">9:30 AM</SelectItem>
                    <SelectItem value="10:00">10:00 AM</SelectItem>
                    <SelectItem value="10:30">10:30 AM</SelectItem>
                    <SelectItem value="11:00">11:00 AM</SelectItem>
                    <SelectItem value="11:30">11:30 AM</SelectItem>
                    <SelectItem value="1:00">1:00 PM</SelectItem>
                    <SelectItem value="1:30">1:30 PM</SelectItem>
                    <SelectItem value="2:00">2:00 PM</SelectItem>
                    <SelectItem value="2:30">2:30 PM</SelectItem>
                    <SelectItem value="3:00">3:00 PM</SelectItem>
                    <SelectItem value="3:30">3:30 PM</SelectItem>
                    <SelectItem value="4:00">4:00 PM</SelectItem>
                    <SelectItem value="4:30">4:30 PM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="notes" className="text-right">
                Notes
              </Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add any additional notes"
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">{userRole === "patient" ? "Book Appointment" : "Schedule Appointment"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}


"use client"

import { Chart, ChartContainer, ChartTooltip, ChartLegend, ChartLegendItem } from "@/components/ui/chart"
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, XAxis, YAxis } from "recharts"

const data = [
  {
    name: "Jan",
    total: 240000,
    insurance: 160000,
  },
  {
    name: "Feb",
    total: 139800,
    insurance: 90000,
  },
  {
    name: "Mar",
    total: 980000,
    insurance: 680000,
  },
  {
    name: "Apr",
    total: 390800,
    insurance: 260000,
  },
  {
    name: "May",
    total: 480000,
    insurance: 320000,
  },
  {
    name: "Jun",
    total: 380000,
    insurance: 250000,
  },
  {
    name: "Jul",
    total: 430000,
    insurance: 290000,
  },
]

// Function to format Indian currency
const formatIndianCurrency = (value: number) => {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value)
}

// Custom tooltip content component
const CustomTooltipContent = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-lg shadow-md p-3 animate-in">
        <p className="font-medium text-sm mb-1">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={`item-${index}`} className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }}></div>
            <span className="font-medium">{entry.name}:</span>
            <span>{formatIndianCurrency(entry.value)}</span>
          </div>
        ))}
      </div>
    )
  }
  return null
}

export function RevenueChart() {
  return (
    <Chart className="h-[300px]">
      <ChartLegend className="mb-4 justify-end gap-4">
        <ChartLegendItem name="Total Revenue" color="hsl(var(--primary))" />
        <ChartLegendItem name="Insurance Claims" color="hsl(var(--muted-foreground))" />
      </ChartLegend>
      <ChartContainer>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{
              top: 5,
              right: 10,
              left: 10,
              bottom: 0,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis dataKey="name" className="text-sm text-muted-foreground" tickLine={false} axisLine={false} />
            <YAxis
              className="text-sm text-muted-foreground"
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `₹${value / 1000}K`}
            />
            <ChartTooltip content={<CustomTooltipContent />} />
            <Area
              type="monotone"
              dataKey="total"
              stroke="hsl(var(--primary))"
              fill="hsl(var(--primary))"
              fillOpacity={0.2}
              strokeWidth={2}
            />
            <Area
              type="monotone"
              dataKey="insurance"
              stroke="hsl(var(--muted-foreground))"
              fill="hsl(var(--muted-foreground))"
              fillOpacity={0.1}
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
      </ChartContainer>
    </Chart>
  )
}


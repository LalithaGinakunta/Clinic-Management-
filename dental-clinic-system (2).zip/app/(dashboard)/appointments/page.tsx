"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Clock, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { format } from "date-fns"

export default function AppointmentsPage() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Appointments</h1>
          <p className="text-muted-foreground">Schedule and manage patient appointments</p>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild>
            <Link href="/appointments/new">
              <Plus className="mr-2 h-4 w-4" />
              New Appointment
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Calendar</CardTitle>
              <CardDescription>Select a date to view appointments</CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
              <div className="mt-4 space-y-2">
                <h3 className="font-medium">Appointment Legend</h3>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span className="text-sm">Confirmed</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                  <span className="text-sm">Pending</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <span className="text-sm">In Progress</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <span className="text-sm">Cancelled</span>
                </div>
              </div>

              <div className="mt-6 space-y-2">
                <h3 className="font-medium">Today's Summary</h3>
                <div className="grid grid-cols-2 gap-2">
                  <Card className="p-3">
                    <p className="text-xs text-muted-foreground">Total</p>
                    <p className="text-xl font-bold">12</p>
                  </Card>
                  <Card className="p-3">
                    <p className="text-xs text-muted-foreground">Completed</p>
                    <p className="text-xl font-bold">5</p>
                  </Card>
                  <Card className="p-3">
                    <p className="text-xs text-muted-foreground">Upcoming</p>
                    <p className="text-xl font-bold">7</p>
                  </Card>
                  <Card className="p-3">
                    <p className="text-xs text-muted-foreground">Cancelled</p>
                    <p className="text-xl font-bold">0</p>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div>
                  <CardTitle>{date ? format(date, "MMMM d, yyyy") : "Today's Schedule"}</CardTitle>
                  <CardDescription>{date ? format(date, "EEEE") : "March 28, 2025"}</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input type="search" placeholder="Search appointments..." className="pl-8 w-[200px]" />
                  </div>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Filter by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="confirmed">Confirmed</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="all" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="morning">Morning</TabsTrigger>
                  <TabsTrigger value="afternoon">Afternoon</TabsTrigger>
                  <TabsTrigger value="evening">Evening</TabsTrigger>
                </TabsList>
                <TabsContent value="all" className="space-y-4">
                  {[
                    {
                      time: "9:00 AM",
                      patient: "Sarah Johnson",
                      procedure: "Dental Cleaning",
                      status: "Confirmed",
                      duration: "45 min",
                      doctor: "Dr. Johnson",
                      fee: "₹1,200",
                    },
                    {
                      time: "10:30 AM",
                      patient: "Michael Chen",
                      procedure: "Root Canal",
                      status: "Confirmed",
                      duration: "1 hour 30 min",
                      doctor: "Dr. Martinez",
                      fee: "₹8,500",
                    },
                    {
                      time: "11:45 AM",
                      patient: "Emily Davis",
                      procedure: "Consultation",
                      status: "Pending",
                      duration: "30 min",
                      doctor: "Dr. Johnson",
                      fee: "₹800",
                    },
                    {
                      time: "2:15 PM",
                      patient: "Robert Wilson",
                      procedure: "Crown Fitting",
                      status: "Confirmed",
                      duration: "1 hour",
                      doctor: "Dr. Johnson",
                      fee: "₹5,500",
                    },
                    {
                      time: "3:30 PM",
                      patient: "Jennifer Lopez",
                      procedure: "Teeth Whitening",
                      status: "Confirmed",
                      duration: "1 hour",
                      doctor: "Dr. Martinez",
                      fee: "₹4,000",
                    },
                    {
                      time: "4:45 PM",
                      patient: "David Brown",
                      procedure: "Follow-up",
                      status: "Cancelled",
                      duration: "30 min",
                      doctor: "Dr. Johnson",
                      fee: "₹600",
                    },
                  ].map((appointment, i) => (
                    <Card key={i} className="overflow-hidden">
                      <div
                        className={`h-1 ${
                          appointment.status === "Confirmed"
                            ? "bg-green-500"
                            : appointment.status === "Pending"
                              ? "bg-amber-500"
                              : appointment.status === "In Progress"
                                ? "bg-blue-500"
                                : "bg-red-500"
                        }`}
                      ></div>
                      <CardContent className="p-4">
                        <div className="flex flex-col md:flex-row justify-between gap-4">
                          <div className="flex items-start gap-4">
                            <div className="bg-primary/10 p-2 rounded-full">
                              <Clock className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="font-medium">{appointment.time}</h3>
                                <Badge
                                  variant={
                                    appointment.status === "Confirmed"
                                      ? "default"
                                      : appointment.status === "Pending"
                                        ? "outline"
                                        : appointment.status === "In Progress"
                                          ? "secondary"
                                          : "destructive"
                                  }
                                >
                                  {appointment.status}
                                </Badge>
                              </div>
                              <p className="text-sm font-medium">{appointment.patient}</p>
                              <p className="text-sm text-muted-foreground">{appointment.procedure}</p>
                              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                <span>{appointment.duration}</span>
                                <span>{appointment.doctor}</span>
                                <span className="font-medium text-primary">{appointment.fee}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 md:self-center">
                            <Button variant="outline" size="sm">
                              Reschedule
                            </Button>
                            <Button variant="outline" size="sm">
                              Cancel
                            </Button>
                            <Button size="sm">Check In</Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>
                <TabsContent value="morning">
                  <div className="space-y-4">
                    {[
                      {
                        time: "9:00 AM",
                        patient: "Sarah Johnson",
                        procedure: "Dental Cleaning",
                        status: "Confirmed",
                        duration: "45 min",
                        doctor: "Dr. Johnson",
                        fee: "₹1,200",
                      },
                      {
                        time: "10:30 AM",
                        patient: "Michael Chen",
                        procedure: "Root Canal",
                        status: "Confirmed",
                        duration: "1 hour 30 min",
                        doctor: "Dr. Martinez",
                        fee: "₹8,500",
                      },
                      {
                        time: "11:45 AM",
                        patient: "Emily Davis",
                        procedure: "Consultation",
                        status: "Pending",
                        duration: "30 min",
                        doctor: "Dr. Johnson",
                        fee: "₹800",
                      },
                    ].map((appointment, i) => (
                      <Card key={i} className="overflow-hidden">
                        <div
                          className={`h-1 ${
                            appointment.status === "Confirmed"
                              ? "bg-green-500"
                              : appointment.status === "Pending"
                                ? "bg-amber-500"
                                : appointment.status === "In Progress"
                                  ? "bg-blue-500"
                                  : "bg-red-500"
                          }`}
                        ></div>
                        <CardContent className="p-4">
                          <div className="flex flex-col md:flex-row justify-between gap-4">
                            <div className="flex items-start gap-4">
                              <div className="bg-primary/10 p-2 rounded-full">
                                <Clock className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <h3 className="font-medium">{appointment.time}</h3>
                                  <Badge
                                    variant={
                                      appointment.status === "Confirmed"
                                        ? "default"
                                        : appointment.status === "Pending"
                                          ? "outline"
                                          : appointment.status === "In Progress"
                                            ? "secondary"
                                            : "destructive"
                                    }
                                  >
                                    {appointment.status}
                                  </Badge>
                                </div>
                                <p className="text-sm font-medium">{appointment.patient}</p>
                                <p className="text-sm text-muted-foreground">{appointment.procedure}</p>
                                <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                  <span>{appointment.duration}</span>
                                  <span>{appointment.doctor}</span>
                                  <span className="font-medium text-primary">{appointment.fee}</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 md:self-center">
                              <Button variant="outline" size="sm">
                                Reschedule
                              </Button>
                              <Button variant="outline" size="sm">
                                Cancel
                              </Button>
                              <Button size="sm">Check In</Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="afternoon">
                  <div className="space-y-4">
                    {[
                      {
                        time: "2:15 PM",
                        patient: "Robert Wilson",
                        procedure: "Crown Fitting",
                        status: "Confirmed",
                        duration: "1 hour",
                        doctor: "Dr. Johnson",
                        fee: "₹5,500",
                      },
                      {
                        time: "3:30 PM",
                        patient: "Jennifer Lopez",
                        procedure: "Teeth Whitening",
                        status: "Confirmed",
                        duration: "1 hour",
                        doctor: "Dr. Martinez",
                        fee: "₹4,000",
                      },
                      {
                        time: "4:45 PM",
                        patient: "David Brown",
                        procedure: "Follow-up",
                        status: "Cancelled",
                        duration: "30 min",
                        doctor: "Dr. Johnson",
                        fee: "₹600",
                      },
                    ].map((appointment, i) => (
                      <Card key={i} className="overflow-hidden">
                        <div
                          className={`h-1 ${
                            appointment.status === "Confirmed"
                              ? "bg-green-500"
                              : appointment.status === "Pending"
                                ? "bg-amber-500"
                                : appointment.status === "In Progress"
                                  ? "bg-blue-500"
                                  : "bg-red-500"
                          }`}
                        ></div>
                        <CardContent className="p-4">
                          <div className="flex flex-col md:flex-row justify-between gap-4">
                            <div className="flex items-start gap-4">
                              <div className="bg-primary/10 p-2 rounded-full">
                                <Clock className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <h3 className="font-medium">{appointment.time}</h3>
                                  <Badge
                                    variant={
                                      appointment.status === "Confirmed"
                                        ? "default"
                                        : appointment.status === "Pending"
                                          ? "outline"
                                          : appointment.status === "In Progress"
                                            ? "secondary"
                                            : "destructive"
                                    }
                                  >
                                    {appointment.status}
                                  </Badge>
                                </div>
                                <p className="text-sm font-medium">{appointment.patient}</p>
                                <p className="text-sm text-muted-foreground">{appointment.procedure}</p>
                                <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                  <span>{appointment.duration}</span>
                                  <span>{appointment.doctor}</span>
                                  <span className="font-medium text-primary">{appointment.fee}</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 md:self-center">
                              <Button variant="outline" size="sm">
                                Reschedule
                              </Button>
                              <Button variant="outline" size="sm">
                                Cancel
                              </Button>
                              <Button size="sm">Check In</Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="evening">
                  <div className="p-4 text-center text-muted-foreground">
                    No evening appointments scheduled for today.
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}


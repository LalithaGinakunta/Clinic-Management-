"use client"

import { useState } from "react"
import { CalendarIcon, Clock, Plus } from "lucide-react"
import { format } from "date-fns"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { EnhancedAppointmentForm } from "@/components/appointments/enhanced-appointment-form"
import { AppointmentList } from "@/components/appointments/appointment-list"

interface AppointmentCalendarProps {
  userRole?: "dentist" | "admin" | "patient"
}

export function AppointmentCalendar({ userRole = "admin" }: AppointmentCalendarProps) {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [isBookingOpen, setIsBookingOpen] = useState(false)
  const [view, setView] = useState<"day" | "week" | "month">("day")

  return (
    <div className="p-4 md:p-8 pt-6">
      <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
        <div className="flex items-center space-x-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant={"outline"}
                className={cn(
                  "justify-start text-left font-normal w-[240px] elegant-input",
                  !date && "text-muted-foreground",
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
            </PopoverContent>
          </Popover>
          <Select value={view} onValueChange={(value) => setView(value as "day" | "week" | "month")}>
            <SelectTrigger className="w-[120px] elegant-input">
              <SelectValue placeholder="View" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Day</SelectItem>
              <SelectItem value="week">Week</SelectItem>
              <SelectItem value="month">Month</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={() => setDate(new Date())} className="elegant-button">
            Today
          </Button>
          <Button onClick={() => setIsBookingOpen(true)} className="elegant-button">
            <Plus className="mr-2 h-4 w-4" />
            {userRole === "patient" ? "Book Appointment" : "New Appointment"}
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-7">
        <Card className="md:col-span-2 elegant-card">
          <CardHeader>
            <CardTitle>
              {view === "day"
                ? format(date || new Date(), "MMMM d, yyyy")
                : view === "week"
                  ? `Week of ${format(date || new Date(), "MMMM d, yyyy")}`
                  : format(date || new Date(), "MMMM yyyy")}
            </CardTitle>
            <CardDescription>
              {userRole === "dentist"
                ? "Your schedule"
                : userRole === "admin"
                  ? "Practice schedule"
                  : "Available appointments"}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
          </CardContent>
          <CardFooter className="flex justify-between p-4">
            <Button variant="outline" size="sm" className="elegant-button">
              <Clock className="mr-2 h-4 w-4" />
              {userRole === "patient" ? "My Appointments" : "All Appointments"}
            </Button>
            <Button variant="outline" size="sm" className="elegant-button">
              {userRole === "patient" ? "Reschedule" : "Manage Schedule"}
            </Button>
          </CardFooter>
        </Card>
        <Card className="md:col-span-5 elegant-card">
          <CardHeader>
            <CardTitle>
              {view === "day"
                ? `Appointments for ${format(date || new Date(), "MMMM d, yyyy")}`
                : view === "week"
                  ? `Appointments for week of ${format(date || new Date(), "MMMM d, yyyy")}`
                  : `Appointments for ${format(date || new Date(), "MMMM yyyy")}`}
            </CardTitle>
            <CardDescription>
              {userRole === "dentist"
                ? "Your patient appointments"
                : userRole === "admin"
                  ? "All scheduled appointments"
                  : "Your upcoming appointments"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AppointmentList date={date || new Date()} view={view} userRole={userRole} />
          </CardContent>
        </Card>
      </div>
      {isBookingOpen && (
        <EnhancedAppointmentForm isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} selectedDate={date} />
      )}
    </div>
  )
}


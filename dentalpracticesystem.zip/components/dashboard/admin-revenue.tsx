"use client"

import { Chart, ChartContainer, ChartTooltip, ChartLegend, ChartLegendItem } from "@/components/ui/chart"
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Function to format Indian currency
const formatIndianCurrency = (value: number) => {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value)
}

const monthlyData = [
  { name: "Jan", revenue: 400000, expenses: 240000 },
  { name: "Feb", revenue: 300000, expenses: 139800 },
  { name: "Mar", revenue: 980000, expenses: 200000 },
  { name: "Apr", revenue: 390800, expenses: 278000 },
  { name: "May", revenue: 480000, expenses: 190800 },
  { name: "Jun", revenue: 380000, expenses: 230000 },
]

const serviceData = [
  { name: "Cleaning", revenue: 1200000 },
  { name: "Checkup", revenue: 800000 },
  { name: "Filling", revenue: 1500000 },
  { name: "Root Canal", revenue: 900000 },
  { name: "Extraction", revenue: 600000 },
]

const insuranceData = [
  { name: "BlueCross", value: 45 },
  { name: "Aetna", value: 25 },
  { name: "Cigna", value: 15 },
  { name: "Delta Dental", value: 10 },
  { name: "Other", value: 5 },
]

// Custom tooltip content component
const CustomTooltipContent = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-lg shadow-md p-3 animate-in">
        <p className="font-medium text-sm mb-1">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={`item-${index}`} className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }}></div>
            <span className="font-medium">{entry.name}:</span>
            <span>{formatIndianCurrency(entry.value)}</span>
          </div>
        ))}
      </div>
    )
  }
  return null
}

export function AdminRevenue() {
  return (
    <div className="space-y-4">
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="services">Services</TabsTrigger>
          <TabsTrigger value="insurance">Insurance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 pt-4">
          <Card className="elegant-card">
            <CardHeader>
              <CardTitle>Revenue Overview</CardTitle>
              <CardDescription>Monthly revenue and expenses for the current year</CardDescription>
            </CardHeader>
            <CardContent>
              <Chart className="h-[300px]">
                <ChartLegend className="mb-4 justify-end gap-4">
                  <ChartLegendItem name="Revenue" color="hsl(var(--primary))" />
                  <ChartLegendItem name="Expenses" color="hsl(var(--muted-foreground))" />
                </ChartLegend>
                <ChartContainer>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={monthlyData}
                      margin={{
                        top: 5,
                        right: 10,
                        left: 10,
                        bottom: 0,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                      <XAxis
                        dataKey="name"
                        className="text-sm text-muted-foreground"
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        className="text-sm text-muted-foreground"
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `₹${value / 1000}K`}
                      />
                      <ChartTooltip content={<CustomTooltipContent />} />
                      <Area
                        type="monotone"
                        dataKey="revenue"
                        stroke="hsl(var(--primary))"
                        fill="hsl(var(--primary))"
                        fillOpacity={0.2}
                        strokeWidth={2}
                      />
                      <Area
                        type="monotone"
                        dataKey="expenses"
                        stroke="hsl(var(--muted-foreground))"
                        fill="hsl(var(--muted-foreground))"
                        fillOpacity={0.1}
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </Chart>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card className="hover-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatIndianCurrency(7800000)}</div>
                <p className="text-xs text-muted-foreground">+12% from last year</p>
              </CardContent>
            </Card>
            <Card className="hover-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatIndianCurrency(3200000)}</div>
                <p className="text-xs text-muted-foreground">+5% from last year</p>
              </CardContent>
            </Card>
            <Card className="hover-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatIndianCurrency(4600000)}</div>
                <p className="text-xs text-muted-foreground">+18% from last year</p>
              </CardContent>
            </Card>
            <Card className="hover-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Profit Margin</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">59%</div>
                <p className="text-xs text-muted-foreground">+4% from last year</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="services" className="space-y-4 pt-4">
          <Card className="elegant-card">
            <CardHeader>
              <CardTitle>Revenue by Service</CardTitle>
              <CardDescription>Revenue breakdown by service type</CardDescription>
            </CardHeader>
            <CardContent>
              <Chart className="h-[300px]">
                <ChartContainer>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={serviceData}
                      margin={{
                        top: 5,
                        right: 10,
                        left: 10,
                        bottom: 20,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                      <XAxis
                        dataKey="name"
                        className="text-sm text-muted-foreground"
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        className="text-sm text-muted-foreground"
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `₹${value / 100000}L`}
                      />
                      <ChartTooltip content={<CustomTooltipContent />} />
                      <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </Chart>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insurance" className="space-y-4 pt-4">
          <Card className="elegant-card">
            <CardHeader>
              <CardTitle>Insurance Claims</CardTitle>
              <CardDescription>Distribution of insurance claims by provider</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] flex items-center justify-center">
                <p className="text-muted-foreground">Insurance claims chart will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button className="elegant-button">Generate Detailed Financial Report</Button>
      </div>
    </div>
  )
}


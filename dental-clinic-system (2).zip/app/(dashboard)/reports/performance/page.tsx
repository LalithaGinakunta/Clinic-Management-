import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Calendar } from "lucide-react"
import { Chart, ChartContainer } from "@/components/ui/chart"
import {
  Bar,
  BarChart as RechartsBarChart,
  Line,
  LineChart as RechartsLineChart,
  Pie,
  PieChart as RechartsPieChart,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

export default function PerformancePage() {
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82ca9d"]

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Performance Metrics</h1>
          <p className="text-muted-foreground">Detailed analysis of clinic and staff performance</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            Date Range
          </Button>
          <Button>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Appointment Utilization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">92%</div>
            <p className="text-xs text-muted-foreground">+3% from last year</p>
            <div className="mt-4 h-2 w-full bg-muted">
              <div className="h-2 w-[92%] bg-primary"></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">No-Show Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.5%</div>
            <p className="text-xs text-muted-foreground">-1.2% from last year</p>
            <div className="mt-4 h-2 w-full bg-muted">
              <div className="h-2 w-[4.5%] bg-destructive"></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Patient Satisfaction</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.8/5</div>
            <p className="text-xs text-muted-foreground">Based on 324 reviews</p>
            <div className="mt-4 h-2 w-full bg-muted">
              <div className="h-2 w-[96%] bg-green-500"></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Staff Efficiency</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">95%</div>
            <p className="text-xs text-muted-foreground">+2% from last quarter</p>
            <div className="mt-4 h-2 w-full bg-muted">
              <div className="h-2 w-[95%] bg-blue-500"></div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="staff">Staff Performance</TabsTrigger>
          <TabsTrigger value="appointments">Appointment Metrics</TabsTrigger>
          <TabsTrigger value="satisfaction">Patient Satisfaction</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends</CardTitle>
                <CardDescription>Key performance indicators over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsLineChart
                          data={[
                            { month: "Jan", satisfaction: 4.6, utilization: 88, noShow: 6.2 },
                            { month: "Feb", satisfaction: 4.7, utilization: 89, noShow: 5.8 },
                            { month: "Mar", satisfaction: 4.7, utilization: 90, noShow: 5.5 },
                            { month: "Apr", satisfaction: 4.8, utilization: 91, noShow: 5.0 },
                            { month: "May", satisfaction: 4.8, utilization: 92, noShow: 4.8 },
                            { month: "Jun", satisfaction: 4.9, utilization: 93, noShow: 4.5 },
                          ]}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis yAxisId="left" orientation="left" />
                          <YAxis yAxisId="right" orientation="right" />
                          <Tooltip />
                          <Legend />
                          <Line
                            yAxisId="left"
                            type="monotone"
                            dataKey="satisfaction"
                            stroke="#8884d8"
                            name="Satisfaction (1-5)"
                          />
                          <Line
                            yAxisId="left"
                            type="monotone"
                            dataKey="utilization"
                            stroke="#82ca9d"
                            name="Utilization (%)"
                          />
                          <Line
                            yAxisId="right"
                            type="monotone"
                            dataKey="noShow"
                            stroke="#ff7300"
                            name="No-Show Rate (%)"
                          />
                        </RechartsLineChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Efficiency by Department</CardTitle>
                <CardDescription>Performance metrics by department</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsBarChart
                          data={[
                            { department: "General Dentistry", efficiency: 96, satisfaction: 4.8 },
                            { department: "Orthodontics", efficiency: 94, satisfaction: 4.7 },
                            { department: "Pediatric", efficiency: 92, satisfaction: 4.9 },
                            { department: "Oral Surgery", efficiency: 90, satisfaction: 4.6 },
                            { department: "Periodontics", efficiency: 93, satisfaction: 4.7 },
                          ]}
                          margin={{
                            top: 20,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="department" />
                          <YAxis yAxisId="left" orientation="left" />
                          <YAxis yAxisId="right" orientation="right" domain={[0, 5]} />
                          <Tooltip />
                          <Legend />
                          <Bar yAxisId="left" dataKey="efficiency" fill="#3b82f6" name="Efficiency (%)" />
                          <Line
                            yAxisId="right"
                            type="monotone"
                            dataKey="satisfaction"
                            stroke="#f59e0b"
                            name="Satisfaction (1-5)"
                          />
                        </RechartsBarChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Operational Efficiency</CardTitle>
              <CardDescription>Key operational metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Average Wait Time</h3>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold">8.5 min</div>
                    <div className="text-sm text-green-600">-12% ↓</div>
                  </div>
                  <p className="text-xs text-muted-foreground">Target: 10 minutes</p>
                  <div className="h-2 w-full bg-muted">
                    <div className="h-2 w-[85%] bg-green-500"></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Chair Utilization</h3>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold">87%</div>
                    <div className="text-sm text-green-600">+5% ↑</div>
                  </div>
                  <p className="text-xs text-muted-foreground">Target: 85%</p>
                  <div className="h-2 w-full bg-muted">
                    <div className="h-2 w-[87%] bg-green-500"></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Treatment Completion Rate</h3>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold">94%</div>
                    <div className="text-sm text-green-600">+2% ↑</div>
                  </div>
                  <p className="text-xs text-muted-foreground">Target: 90%</p>
                  <div className="h-2 w-full bg-muted">
                    <div className="h-2 w-[94%] bg-green-500"></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="staff">
          <Card>
            <CardHeader>
              <CardTitle>Staff Performance</CardTitle>
              <CardDescription>Procedures completed by doctor</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ChartContainer>
                  <Chart>
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsBarChart
                        data={[
                          { name: "Dr. Johnson", procedures: 185, revenue: 4250000, satisfaction: 4.9 },
                          { name: "Dr. Martinez", procedures: 162, revenue: 3850000, satisfaction: 4.8 },
                          { name: "Dr. Patel", procedures: 145, revenue: 3250000, satisfaction: 4.7 },
                          { name: "Dr. Gupta", procedures: 128, revenue: 2950000, satisfaction: 4.8 },
                        ]}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis yAxisId="left" orientation="left" />
                        <YAxis
                          yAxisId="right"
                          orientation="right"
                          tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`}
                        />
                        <Tooltip
                          formatter={(value, name) => {
                            if (name === "revenue") {
                              return [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Revenue"]
                            } else if (name === "satisfaction") {
                              return [value, "Satisfaction (1-5)"]
                            }
                            return [value, "Procedures"]
                          }}
                        />
                        <Legend />
                        <Bar yAxisId="left" dataKey="procedures" fill="#3b82f6" name="Procedures" />
                        <Bar yAxisId="right" dataKey="revenue" fill="#10b981" name="Revenue (₹)" />
                        <Line
                          yAxisId="left"
                          type="monotone"
                          dataKey="satisfaction"
                          stroke="#f59e0b"
                          name="Satisfaction (1-5)"
                        />
                      </RechartsBarChart>
                    </ResponsiveContainer>
                  </Chart>
                </ChartContainer>
              </div>

              <div className="mt-8 grid gap-6 md:grid-cols-2">
                <div>
                  <h3 className="text-lg font-medium mb-4">Staff Efficiency Metrics</h3>
                  <div className="space-y-4">
                    {[
                      { name: "Dr. Johnson", efficiency: 96, onTime: 98, notes: 95 },
                      { name: "Dr. Martinez", efficiency: 94, onTime: 96, notes: 92 },
                      { name: "Dr. Patel", efficiency: 93, onTime: 95, notes: 97 },
                      { name: "Dr. Gupta", efficiency: 92, onTime: 94, notes: 94 },
                    ].map((doctor, i) => (
                      <div key={i} className="p-4 border rounded-md">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-medium">{doctor.name}</h4>
                          <div className="text-sm font-medium text-green-600">{doctor.efficiency}% Efficiency</div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>On-time Rate:</span>
                            <span>{doctor.onTime}%</span>
                          </div>
                          <div className="h-1.5 w-full bg-muted">
                            <div className="h-1.5 bg-blue-500" style={{ width: `${doctor.onTime}%` }}></div>
                          </div>

                          <div className="flex justify-between text-sm">
                            <span>Documentation Completion:</span>
                            <span>{doctor.notes}%</span>
                          </div>
                          <div className="h-1.5 w-full bg-muted">
                            <div className="h-1.5 bg-green-500" style={{ width: `${doctor.notes}%` }}></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Staff Training & Development</h3>
                  <div className="space-y-4">
                    {[
                      { name: "Dr. Johnson", training: "Advanced Implantology", completion: 100, date: "Mar 15, 2025" },
                      { name: "Dr. Martinez", training: "Pediatric Dentistry", completion: 85, date: "In Progress" },
                      { name: "Dr. Patel", training: "Cosmetic Dentistry", completion: 100, date: "Feb 10, 2025" },
                      { name: "Dr. Gupta", training: "Endodontics", completion: 75, date: "In Progress" },
                    ].map((training, i) => (
                      <div key={i} className="p-4 border rounded-md">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-medium">{training.name}</h4>
                          <div
                            className={`text-sm font-medium ${training.completion === 100 ? "text-green-600" : "text-amber-600"}`}
                          >
                            {training.completion}% Complete
                          </div>
                        </div>
                        <p className="text-sm">{training.training}</p>
                        <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                          <span>Completion Date: {training.date}</span>
                        </div>
                        <div className="mt-2 h-1.5 w-full bg-muted">
                          <div
                            className={`h-1.5 ${training.completion === 100 ? "bg-green-500" : "bg-amber-500"}`}
                            style={{ width: `${training.completion}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appointments">
          <Card>
            <CardHeader>
              <CardTitle>Appointment Metrics</CardTitle>
              <CardDescription>Analysis of appointment efficiency</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <h3 className="text-lg font-medium mb-4">Appointment Status Distribution</h3>
                  <div className="h-[300px]">
                    <ChartContainer>
                      <Chart>
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsPieChart>
                            <Pie
                              data={[
                                { name: "Completed", value: 78 },
                                { name: "Rescheduled", value: 12 },
                                { name: "No-Show", value: 5 },
                                { name: "Cancelled", value: 5 },
                              ]}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            >
                              {[
                                { name: "Completed", value: 78 },
                                { name: "Rescheduled", value: 12 },
                                { name: "No-Show", value: 5 },
                                { name: "Cancelled", value: 5 },
                              ].map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                            <Legend />
                          </RechartsPieChart>
                        </ResponsiveContainer>
                      </Chart>
                    </ChartContainer>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Appointment Trends</h3>
                  <div className="h-[300px]">
                    <ChartContainer>
                      <Chart>
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsLineChart
                            data={[
                              { month: "Jan", scheduled: 245, completed: 192, noShow: 12 },
                              { month: "Feb", scheduled: 258, completed: 205, noShow: 14 },
                              { month: "Mar", scheduled: 275, completed: 220, noShow: 15 },
                              { month: "Apr", scheduled: 262, completed: 215, noShow: 12 },
                              { month: "May", scheduled: 280, completed: 230, noShow: 13 },
                              { month: "Jun", scheduled: 295, completed: 245, noShow: 10 },
                            ]}
                            margin={{
                              top: 5,
                              right: 30,
                              left: 20,
                              bottom: 5,
                            }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="scheduled" stroke="#3b82f6" name="Scheduled" />
                            <Line type="monotone" dataKey="completed" stroke="#10b981" name="Completed" />
                            <Line type="monotone" dataKey="noShow" stroke="#f43f5e" name="No-Show" />
                          </RechartsLineChart>
                        </ResponsiveContainer>
                      </Chart>
                    </ChartContainer>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <h3 className="text-lg font-medium mb-4">Appointment Efficiency by Procedure</h3>
                <div className="rounded-md border">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Procedure
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Avg. Duration
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          On-Time Start %
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Completion Rate
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Patient Satisfaction
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {[
                        {
                          procedure: "Dental Cleaning",
                          duration: "45 min",
                          onTime: 96,
                          completion: 99,
                          satisfaction: 4.8,
                        },
                        { procedure: "Filling", duration: "60 min", onTime: 92, completion: 98, satisfaction: 4.7 },
                        { procedure: "Root Canal", duration: "90 min", onTime: 88, completion: 95, satisfaction: 4.5 },
                        {
                          procedure: "Crown Fitting",
                          duration: "75 min",
                          onTime: 90,
                          completion: 97,
                          satisfaction: 4.6,
                        },
                        { procedure: "Extraction", duration: "45 min", onTime: 94, completion: 98, satisfaction: 4.4 },
                      ].map((item, i) => (
                        <tr key={i}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {item.procedure}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.duration}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.onTime}%</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.completion}%</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.satisfaction}/5.0</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="satisfaction">
          <Card>
            <CardHeader>
              <CardTitle>Patient Satisfaction</CardTitle>
              <CardDescription>Analysis of patient feedback and satisfaction</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <h3 className="text-lg font-medium mb-4">Overall Satisfaction Trend</h3>
                  <div className="h-[300px]">
                    <ChartContainer>
                      <Chart>
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsLineChart
                            data={[
                              { month: "Jan", satisfaction: 4.6, reviews: 45 },
                              { month: "Feb", satisfaction: 4.7, reviews: 52 },
                              { month: "Mar", satisfaction: 4.7, reviews: 58 },
                              { month: "Apr", satisfaction: 4.8, reviews: 62 },
                              { month: "May", satisfaction: 4.8, reviews: 55 },
                              { month: "Jun", satisfaction: 4.9, reviews: 52 },
                            ]}
                            margin={{
                              top: 5,
                              right: 30,
                              left: 20,
                              bottom: 5,
                            }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis yAxisId="left" orientation="left" domain={[4, 5]} />
                            <YAxis yAxisId="right" orientation="right" />
                            <Tooltip />
                            <Legend />
                            <Line
                              yAxisId="left"
                              type="monotone"
                              dataKey="satisfaction"
                              stroke="#3b82f6"
                              name="Satisfaction (1-5)"
                            />
                            <Bar yAxisId="right" dataKey="reviews" fill="#10b981" name="Number of Reviews" />
                          </RechartsLineChart>
                        </ResponsiveContainer>
                      </Chart>
                    </ChartContainer>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Satisfaction by Category</h3>
                  <div className="h-[300px]">
                    <ChartContainer>
                      <Chart>
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsBarChart
                            data={[
                              { category: "Staff Friendliness", rating: 4.9 },
                              { category: "Treatment Quality", rating: 4.8 },
                              { category: "Wait Time", rating: 4.5 },
                              { category: "Cleanliness", rating: 4.9 },
                              { category: "Communication", rating: 4.7 },
                              { category: "Value for Money", rating: 4.4 },
                            ]}
                            layout="vertical"
                            margin={{
                              top: 5,
                              right: 30,
                              left: 100,
                              bottom: 5,
                            }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis type="number" domain={[0, 5]} />
                            <YAxis dataKey="category" type="category" />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="rating" fill="#3b82f6" name="Rating (1-5)" />
                          </RechartsBarChart>
                        </ResponsiveContainer>
                      </Chart>
                    </ChartContainer>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <h3 className="text-lg font-medium mb-4">Recent Patient Feedback</h3>
                <div className="space-y-4">
                  {[
                    {
                      patient: "Sarah Johnson",
                      date: "Jun 15, 2025",
                      rating: 5,
                      comment:
                        "Dr. Johnson was excellent! Very thorough and took the time to explain everything. The staff was friendly and the office was spotless.",
                      procedure: "Dental Cleaning",
                    },
                    {
                      patient: "Michael Chen",
                      date: "Jun 12, 2025",
                      rating: 4,
                      comment:
                        "Good experience overall. The root canal was much less painful than I expected. Wait time was a bit longer than scheduled.",
                      procedure: "Root Canal",
                    },
                    {
                      patient: "Emily Davis",
                      date: "Jun 10, 2025",
                      rating: 5,
                      comment:
                        "Amazing experience from start to finish. The staff was very accommodating with my schedule and Dr. Martinez was fantastic.",
                      procedure: "Consultation",
                    },
                    {
                      patient: "Robert Wilson",
                      date: "Jun 8, 2025",
                      rating: 4,
                      comment:
                        "The crown fitting went well. Dr. Johnson was very professional. Only giving 4 stars because the temporary crown was a bit uncomfortable.",
                      procedure: "Crown Fitting",
                    },
                  ].map((feedback, i) => (
                    <div key={i} className="p-4 border rounded-md">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-medium">{feedback.patient}</h4>
                        <div className="flex items-center">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <svg
                                key={i}
                                className={`h-4 w-4 ${i < feedback.rating ? "text-yellow-400" : "text-gray-300"}`}
                                fill="currentColor"
                                viewBox="0 0 20 20"
                              >
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                              </svg>
                            ))}
                        </div>
                      </div>
                      <p className="text-sm">{feedback.comment}</p>
                      <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                        <span>Procedure: {feedback.procedure}</span>
                        <span>{feedback.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}


"use client"

import { Button } from "@/components/ui/button"

import { Chart, ChartContainer, ChartTooltip, ChartLegend, ChartLegendItem } from "@/components/ui/chart"
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

// Function to format Indian currency
const formatIndianCurrency = (value: number) => {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value)
}

const monthlyData = [
  { name: "Jan", revenue: 400000, expenses: 240000 },
  { name: "Feb", revenue: 300000, expenses: 139800 },
  { name: "Mar", revenue: 980000, expenses: 200000 },
  { name: "Apr", revenue: 390800, expenses: 278000 },
  { name: "May", revenue: 480000, expenses: 190800 },
  { name: "Jun", revenue: 380000, expenses: 230000 },
  { name: "Jul", revenue: 430000, expenses: 210000 },
  { name: "Aug", revenue: 530000, expenses: 240000 },
  { name: "Sep", revenue: 450000, expenses: 220000 },
  { name: "Oct", revenue: 600000, expenses: 280000 },
  { name: "Nov", revenue: 550000, expenses: 250000 },
  { name: "Dec", revenue: 700000, expenses: 300000 },
]

const serviceData = [
  { name: "Cleaning", revenue: 1200000 },
  { name: "Checkup", revenue: 800000 },
  { name: "Filling", revenue: 1500000 },
  { name: "Root Canal", revenue: 900000 },
  { name: "Extraction", revenue: 600000 },
  { name: "X-Ray", revenue: 400000 },
]

// Custom tooltip content component
const CustomTooltipContent = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-lg shadow-md p-3 animate-in">
        <p className="font-medium text-sm mb-1">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={`item-${index}`} className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }}></div>
            <span className="font-medium">{entry.name}:</span>
            <span>{formatIndianCurrency(entry.value)}</span>
          </div>
        ))}
      </div>
    )
  }
  return null
}

export function RevenueReport() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card className="col-span-2 elegant-card">
        <CardHeader>
          <CardTitle>Annual Revenue Overview</CardTitle>
          <CardDescription>Monthly revenue and expenses for the current year</CardDescription>
        </CardHeader>
        <CardContent>
          <Chart className="h-[300px]">
            <ChartLegend className="mb-4 justify-end gap-4">
              <ChartLegendItem name="Revenue" color="hsl(var(--primary))" />
              <ChartLegendItem name="Expenses" color="hsl(var(--muted-foreground))" />
            </ChartLegend>
            <ChartContainer>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={monthlyData}
                  margin={{
                    top: 5,
                    right: 10,
                    left: 10,
                    bottom: 0,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="name" className="text-sm text-muted-foreground" tickLine={false} axisLine={false} />
                  <YAxis tickLine={false} axisLine={false} />
                  <YAxis
                    className="text-sm text-muted-foreground"
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `₹${value / 100000}L`}
                  />
                  <ChartTooltip content={<CustomTooltipContent />} />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stroke="hsl(var(--primary))"
                    fill="hsl(var(--primary))"
                    fillOpacity={0.2}
                    strokeWidth={2}
                  />
                  <Area
                    type="monotone"
                    dataKey="expenses"
                    stroke="hsl(var(--muted-foreground))"
                    fill="hsl(var(--muted-foreground))"
                    fillOpacity={0.1}
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </ChartContainer>
          </Chart>
        </CardContent>
      </Card>

      <Card className="elegant-card">
        <CardHeader>
          <CardTitle>Revenue by Service</CardTitle>
          <CardDescription>Revenue breakdown by service type</CardDescription>
        </CardHeader>
        <CardContent>
          <Chart className="h-[300px]">
            <ChartContainer>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={serviceData}
                  margin={{
                    top: 5,
                    right: 10,
                    left: 10,
                    bottom: 20,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="name" className="text-sm text-muted-foreground" tickLine={false} axisLine={false} />
                  <YAxis
                    className="text-sm text-muted-foreground"
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `₹${value / 100000}L`}
                  />
                  <ChartTooltip content={<CustomTooltipContent />} />
                  <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </Chart>
        </CardContent>
      </Card>

      <Card className="elegant-card">
        <CardHeader>
          <CardTitle>Financial Summary</CardTitle>
          <CardDescription>Key financial metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                <p className="text-2xl font-bold">{formatIndianCurrency(7800000)}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Total Expenses</p>
                <p className="text-2xl font-bold">{formatIndianCurrency(3200000)}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Net Profit</p>
                <p className="text-2xl font-bold">{formatIndianCurrency(4600000)}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Profit Margin</p>
                <p className="text-2xl font-bold">59%</p>
              </div>
            </div>
            <div className="pt-4">
              <Button className="w-full elegant-button">View Detailed Report</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}


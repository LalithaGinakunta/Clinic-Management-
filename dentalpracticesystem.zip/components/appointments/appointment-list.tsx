"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, FileText, MessageSquare } from "lucide-react"
import { format, addDays, isSameDay, startOfWeek, endOfWeek, isSameMonth } from "date-fns"

interface AppointmentListProps {
  date: Date
  view: "day" | "week" | "month"
  userRole?: "dentist" | "admin" | "patient"
}

// Sample appointments data
const appointments = [
  {
    id: "1",
    patient: "Sarah Johnson",
    patientId: "p1",
    dentist: "Dr. Emily White",
    dentistId: "d1",
    time: "9:00 AM",
    type: "Cleaning",
    date: new Date(),
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "SJ",
  },
  {
    id: "2",
    patient: "Michael Brown",
    patientId: "p2",
    dentist: "Dr. James Miller",
    dentistId: "d2",
    time: "10:30 AM",
    type: "Checkup",
    date: new Date(),
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "MB",
  },
  {
    id: "3",
    patient: "Emily Davis",
    patientId: "p3",
    dentist: "Dr. Emily White",
    dentistId: "d1",
    time: "11:45 AM",
    type: "Filling",
    date: addDays(new Date(), 1),
    status: "Pending",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "ED",
  },
  {
    id: "4",
    patient: "Robert Wilson",
    patientId: "p4",
    dentist: "Dr. James Miller",
    dentistId: "d2",
    time: "1:15 PM",
    type: "Root Canal",
    date: addDays(new Date(), 2),
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "RW",
  },
  {
    id: "5",
    patient: "Jennifer Lee",
    patientId: "p5",
    dentist: "Dr. Emily White",
    dentistId: "d1",
    time: "2:30 PM",
    type: "Checkup",
    date: addDays(new Date(), 3),
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "JL",
  },
]

export function AppointmentList({ date, view, userRole = "admin" }: AppointmentListProps) {
  // Filter appointments based on the selected view and date
  const filteredAppointments = appointments.filter((appointment) => {
    if (view === "day") {
      return isSameDay(appointment.date, date)
    } else if (view === "week") {
      const weekStart = startOfWeek(date)
      const weekEnd = endOfWeek(date)
      return appointment.date >= weekStart && appointment.date <= weekEnd
    } else {
      return isSameMonth(appointment.date, date)
    }
  })

  // Filter appointments based on user role
  const roleFilteredAppointments = filteredAppointments.filter((appointment) => {
    if (userRole === "dentist") {
      return appointment.dentistId === "d1" // Assuming the logged-in dentist has ID "d1"
    } else if (userRole === "patient") {
      return appointment.patientId === "p1" // Assuming the logged-in patient has ID "p1"
    }
    return true // Admin sees all appointments
  })

  if (roleFilteredAppointments.length === 0) {
    return (
      <div className="flex h-[400px] items-center justify-center rounded-md border border-dashed">
        <div className="flex flex-col items-center space-y-2 text-center">
          <Calendar className="h-10 w-10 text-muted-foreground" />
          <h3 className="font-medium">No appointments</h3>
          <p className="text-sm text-muted-foreground">
            {view === "day"
              ? "No appointments scheduled for this day."
              : view === "week"
                ? "No appointments scheduled for this week."
                : "No appointments scheduled for this month."}
          </p>
          <Button variant="outline" size="sm">
            {userRole === "patient" ? "Book Appointment" : "Schedule Appointment"}
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {roleFilteredAppointments.map((appointment) => (
        <div key={appointment.id} className="flex items-center justify-between space-x-4 rounded-md border p-4">
          <div className="flex items-center space-x-4">
            <Avatar>
              <AvatarImage src={appointment.avatar} alt={appointment.patient} />
              <AvatarFallback>{appointment.initials}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium leading-none">
                {userRole === "patient" ? appointment.dentist : appointment.patient}
              </p>
              <div className="flex items-center text-sm text-muted-foreground">
                <Clock className="mr-1 h-3 w-3" />
                {format(appointment.date, "MMM d")} at {appointment.time} - {appointment.type}
              </div>
              {userRole === "admin" && <p className="text-xs text-muted-foreground">Dentist: {appointment.dentist}</p>}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant={appointment.status === "Confirmed" ? "default" : "secondary"}>{appointment.status}</Badge>
            {userRole !== "patient" && (
              <Button size="icon" variant="ghost">
                <FileText className="h-4 w-4" />
                <span className="sr-only">View Records</span>
              </Button>
            )}
            <Button size="icon" variant="ghost">
              <MessageSquare className="h-4 w-4" />
              <span className="sr-only">Message</span>
            </Button>
            {userRole === "patient" && (
              <Button size="sm" variant="outline">
                Reschedule
              </Button>
            )}
            {userRole !== "patient" && (
              <Button size="sm" variant="outline">
                Edit
              </Button>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}


"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Calendar, Clock, FileText, User } from "lucide-react"

interface PatientDetailsProps {
  patientId: string
  onClose: () => void
}

export function PatientDetails({ patientId, onClose }: PatientDetailsProps) {
  // In a real app, you would fetch patient data based on the ID
  const patient = {
    id: patientId,
    name: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    phone: "(555) 123-4567",
    dob: "1985-06-15",
    address: "123 Main St, Anytown, USA",
    insurance: "BlueCross BlueShield",
    policyNumber: "BC123456789",
    medicalHistory: [
      { date: "2023-03-15", procedure: "Dental Cleaning", notes: "Regular checkup, no issues found." },
      { date: "2022-09-10", procedure: "Filling", notes: "Cavity in lower right molar." },
      { date: "2022-01-20", procedure: "X-Ray", notes: "Full mouth X-ray for assessment." },
    ],
    upcomingAppointments: [{ date: "2023-09-20", time: "10:00 AM", type: "Cleaning" }],
    notes: "Patient prefers morning appointments. Has dental anxiety, consider sedation for complex procedures.",
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">Patient Details</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="overview">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="medical-history">Medical History</TabsTrigger>
            <TabsTrigger value="appointments">Appointments</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-4 pt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="mr-2 h-5 w-5" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 gap-3">
                    <div className="space-y-1">
                      <Label>Full Name</Label>
                      <Input value={patient.name} readOnly />
                    </div>
                    <div className="space-y-1">
                      <Label>Email</Label>
                      <Input value={patient.email} readOnly />
                    </div>
                    <div className="space-y-1">
                      <Label>Phone</Label>
                      <Input value={patient.phone} readOnly />
                    </div>
                    <div className="space-y-1">
                      <Label>Date of Birth</Label>
                      <Input value={patient.dob} readOnly />
                    </div>
                    <div className="space-y-1">
                      <Label>Address</Label>
                      <Input value={patient.address} readOnly />
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="mr-2 h-5 w-5" />
                    Insurance Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 gap-3">
                    <div className="space-y-1">
                      <Label>Insurance Provider</Label>
                      <Input value={patient.insurance} readOnly />
                    </div>
                    <div className="space-y-1">
                      <Label>Policy Number</Label>
                      <Input value={patient.policyNumber} readOnly />
                    </div>
                    <div className="space-y-1">
                      <Label>Notes</Label>
                      <Textarea value={patient.notes} readOnly />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={onClose}>
                Close
              </Button>
              <Button>Edit Patient</Button>
            </div>
          </TabsContent>
          <TabsContent value="medical-history" className="space-y-4 pt-4">
            <Card>
              <CardHeader>
                <CardTitle>Medical History</CardTitle>
                <CardDescription>Past treatments and procedures</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {patient.medicalHistory.map((record, index) => (
                    <div key={index} className="border rounded-md p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-semibold">{record.procedure}</h4>
                          <p className="text-sm text-muted-foreground">{record.date}</p>
                        </div>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </div>
                      <p className="mt-2 text-sm">{record.notes}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="appointments" className="space-y-4 pt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="mr-2 h-5 w-5" />
                  Upcoming Appointments
                </CardTitle>
              </CardHeader>
              <CardContent>
                {patient.upcomingAppointments.length > 0 ? (
                  <div className="space-y-4">
                    {patient.upcomingAppointments.map((appointment, index) => (
                      <div key={index} className="flex items-center justify-between border rounded-md p-4">
                        <div className="flex items-center">
                          <div className="mr-4 rounded-full bg-primary/10 p-2">
                            <Clock className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium">{appointment.type}</h4>
                            <p className="text-sm text-muted-foreground">
                              {appointment.date} at {appointment.time}
                            </p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            Reschedule
                          </Button>
                          <Button variant="outline" size="sm">
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground">No upcoming appointments</p>
                    <Button className="mt-2">Schedule Appointment</Button>
                  </div>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Appointment History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {patient.medicalHistory.map((record, index) => (
                    <div key={index} className="flex justify-between items-center border-b py-2 last:border-0">
                      <div>
                        <p className="font-medium">{record.procedure}</p>
                        <p className="text-sm text-muted-foreground">{record.date}</p>
                      </div>
                      <Button variant="ghost" size="sm">
                        Details
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="billing" className="space-y-4 pt-4">
            <Card>
              <CardHeader>
                <CardTitle>Billing Information</CardTitle>
                <CardDescription>View and manage patient billing</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Billing information will be displayed here</p>
                  <Button className="mt-2">View Invoices</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}


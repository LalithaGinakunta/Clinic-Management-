"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageSquare, FileText, Clock, Phone, Video } from "lucide-react"

const appointments = [
  {
    id: "1",
    patient: "Sarah Johnson",
    time: "9:00 AM",
    type: "Cleaning",
    status: "Checked In",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "SJ",
    notes: "Regular checkup and cleaning",
    room: "Room 3",
  },
  {
    id: "2",
    patient: "Michael Brown",
    time: "10:30 AM",
    type: "Checkup",
    status: "Scheduled",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "MB",
    notes: "First visit, new patient",
    room: "Room 1",
  },
  {
    id: "3",
    patient: "Emily Davis",
    time: "11:45 AM",
    type: "Filling",
    status: "Scheduled",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "ED",
    notes: "Cavity in lower right molar",
    room: "Room 2",
  },
  {
    id: "4",
    patient: "Robert Wilson",
    time: "1:15 PM",
    type: "Root Canal",
    status: "Scheduled",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "RW",
    notes: "Follow-up from previous visit",
    room: "Room 2",
  },
  {
    id: "5",
    patient: "Jennifer Lee",
    time: "2:30 PM",
    type: "Checkup",
    status: "Scheduled",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "JL",
    notes: "Regular 6-month checkup",
    room: "Room 1",
  },
]

export function DentistAppointments() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Today's Schedule</CardTitle>
          <CardDescription>You have {appointments.length} appointments scheduled for today</CardDescription>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Clock className="mr-2 h-4 w-4" />
            View Full Schedule
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {appointments.map((appointment) => (
            <div
              key={appointment.id}
              className="flex items-center justify-between space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
            >
              <div className="flex items-center space-x-4">
                <Avatar>
                  <AvatarImage src={appointment.avatar} alt={appointment.patient} />
                  <AvatarFallback className="bg-primary/10 text-primary">{appointment.initials}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium leading-none">{appointment.patient}</p>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="mr-1 h-3 w-3" />
                    {appointment.time} - {appointment.type}
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground mt-1">
                    <span className="text-primary">{appointment.room}</span>
                    <span className="mx-1">•</span>
                    <span>{appointment.notes}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge
                  variant={appointment.status === "Checked In" ? "default" : "outline"}
                  className={appointment.status === "Checked In" ? "bg-green-500 hover:bg-green-600" : ""}
                >
                  {appointment.status}
                </Badge>
                <div className="flex space-x-1">
                  <Button size="icon" variant="ghost" className="h-8 w-8">
                    <FileText className="h-4 w-4 text-blue-500" />
                    <span className="sr-only">View Records</span>
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8">
                    <MessageSquare className="h-4 w-4 text-green-500" />
                    <span className="sr-only">Message</span>
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8">
                    <Phone className="h-4 w-4 text-amber-500" />
                    <span className="sr-only">Call</span>
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8">
                    <Video className="h-4 w-4 text-purple-500" />
                    <span className="sr-only">Video Call</span>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}


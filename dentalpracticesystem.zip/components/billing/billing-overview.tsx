"use client"

import { useState } from "react"
import { Download, Filter, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BillingStats } from "@/components/billing/billing-stats"
import { InvoiceForm } from "@/components/billing/invoice-form"

// Function to format Indian currency
const formatIndianCurrency = (value: number) => {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value)
}

// Sample invoices data
const invoices = [
  {
    id: "INV-001",
    patient: "Sarah Johnson",
    date: "2023-08-15",
    amount: 15000,
    status: "Paid",
    service: "Dental Cleaning",
  },
  {
    id: "INV-002",
    patient: "Michael Brown",
    date: "2023-08-20",
    amount: 25000,
    status: "Pending",
    service: "Filling",
  },
  {
    id: "INV-003",
    patient: "Emily Davis",
    date: "2023-08-25",
    amount: 7500,
    status: "Overdue",
    service: "Checkup",
  },
  {
    id: "INV-004",
    patient: "Robert Wilson",
    date: "2023-09-01",
    amount: 45000,
    status: "Paid",
    service: "Root Canal",
  },
  {
    id: "INV-005",
    patient: "Jennifer Lee",
    date: "2023-09-05",
    amount: 12000,
    status: "Pending",
    service: "X-Ray",
  },
]

export function BillingOverview() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isInvoiceFormOpen, setIsInvoiceFormOpen] = useState(false)

  const filteredInvoices = invoices.filter(
    (invoice) =>
      invoice.patient.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.id.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="p-4 md:p-8 pt-6">
      <Tabs defaultValue="invoices" className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <TabsList>
            <TabsTrigger value="invoices">Invoices</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
            <TabsTrigger value="insurance">Insurance Claims</TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="elegant-button">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
            <Button size="sm" onClick={() => setIsInvoiceFormOpen(true)} className="elegant-button">
              <Plus className="mr-2 h-4 w-4" />
              New Invoice
            </Button>
          </div>
        </div>

        <TabsContent value="invoices" className="space-y-4">
          <BillingStats />

          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search invoices..."
                className="w-full pl-8 elegant-input"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="sm" className="elegant-button">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>

          <Card className="elegant-card">
            <CardHeader className="px-6 py-4">
              <CardTitle>Invoices</CardTitle>
              <CardDescription>Manage patient invoices and payments</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Invoice</TableHead>
                    <TableHead>Patient</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInvoices.map((invoice) => (
                    <TableRow key={invoice.id} className="hover:bg-muted/50 transition-colors">
                      <TableCell className="font-medium">{invoice.id}</TableCell>
                      <TableCell>{invoice.patient}</TableCell>
                      <TableCell>{invoice.date}</TableCell>
                      <TableCell>{invoice.service}</TableCell>
                      <TableCell>{formatIndianCurrency(invoice.amount)}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            invoice.status === "Paid"
                              ? "default"
                              : invoice.status === "Pending"
                                ? "outline"
                                : "destructive"
                          }
                          className={
                            invoice.status === "Paid"
                              ? "bg-green-500 hover:bg-green-600 elegant-badge"
                              : invoice.status === "Pending"
                                ? "border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100 elegant-badge"
                                : "elegant-badge"
                          }
                        >
                          {invoice.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="elegant-button">
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments" className="space-y-4">
          <Card className="elegant-card">
            <CardHeader>
              <CardTitle>Payments</CardTitle>
              <CardDescription>Track and manage patient payments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] flex items-center justify-center border rounded-md">
                <p className="text-muted-foreground">Payments content will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insurance" className="space-y-4">
          <Card className="elegant-card">
            <CardHeader>
              <CardTitle>Insurance Claims</CardTitle>
              <CardDescription>Manage insurance claims and approvals</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] flex items-center justify-center border rounded-md">
                <p className="text-muted-foreground">Insurance claims content will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {isInvoiceFormOpen && <InvoiceForm isOpen={isInvoiceFormOpen} onClose={() => setIsInvoiceFormOpen(false)} />}
    </div>
  )
}


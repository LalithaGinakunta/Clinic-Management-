"use client"

import { createContext, useContext, useState, type ReactNode, useEffect } from "react"

type UserRole = "patient" | "dentist" | "admin"

interface User {
  id: string
  name: string
  email: string
  role: UserRole
  avatar?: string
}

interface AuthContextType {
  user: User | null
  setUser: (user: User | null) => void
  login: (email: string, password: string, role: UserRole) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Sample users for demo purposes
const sampleUsers: Record<UserRole, User> = {
  patient: {
    id: "p1",
    name: "Michael Brown",
    email: "patient@example.com",
    role: "patient",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  dentist: {
    id: "d1",
    name: "Dr. Sarah Johnson",
    email: "dentist@dentalpro.com",
    role: "dentist",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  admin: {
    id: "a1",
    name: "Alex Rodriguez",
    email: "admin@dentalpro.com",
    role: "admin",
    avatar: "/placeholder.svg?height=40&width=40",
  },
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Check for saved user on initial load
  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
    setIsLoading(false)
  }, [])

  // Save user to localStorage when it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem("user", JSON.stringify(user))
    } else {
      localStorage.removeItem("user")
    }
  }, [user])

  const login = async (email: string, password: string, role: UserRole): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call
    return new Promise((resolve) => {
      setTimeout(() => {
        setUser(sampleUsers[role])
        setIsLoading(false)
        resolve(true)
      }, 1000)
    })
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  return <AuthContext.Provider value={{ user, setUser, login, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}


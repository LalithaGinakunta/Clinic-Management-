"use client"

import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendItem,
} from "@/components/ui/chart"
import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts"

const data = [
  { name: "Cleaning", value: 40, color: "hsl(var(--primary))" },
  { name: "Checkup", value: 30, color: "hsl(var(--primary) / 0.8)" },
  { name: "Filling", value: 15, color: "hsl(var(--primary) / 0.6)" },
  { name: "Root Canal", value: 10, color: "hsl(var(--primary) / 0.4)" },
  { name: "Other", value: 5, color: "hsl(var(--primary) / 0.2)" },
]

export function AppointmentStats() {
  return (
    <Chart className="h-[240px]">
      <ChartLegend className="mb-4 justify-center gap-6">
        {data.map((entry) => (
          <ChartLegendItem key={entry.name} name={entry.name} color={entry.color} />
        ))}
      </ChartLegend>
      <ChartContainer>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={2} dataKey="value">
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <ChartTooltip content={<ChartTooltipContent />} />
          </PieChart>
        </ResponsiveContainer>
      </ChartContainer>
    </Chart>
  )
}


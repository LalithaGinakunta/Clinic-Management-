"use client"

import { createContext, useContext, useState, type ReactNode, useEffect } from "react"

export type UserRole = "dentist" | "admin" | "patient"

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  avatar?: string
}

interface UserContextType {
  user: User | null
  setUser: (user: User | null) => void
  login: (email: string, password: string, role: UserRole) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

const UserContext = createContext<UserContextType | undefined>(undefined)

// Sample users for demo purposes
const sampleUsers: Record<UserRole, User> = {
  dentist: {
    id: "d1",
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@dentalpro.com",
    role: "dentist",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  admin: {
    id: "a1",
    name: "Alex Rodriguez",
    email: "alex.rodriguez@dentalpro.com",
    role: "admin",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  patient: {
    id: "p1",
    name: "Michael Brown",
    email: "michael.brown@example.com",
    role: "patient",
    avatar: "/placeholder.svg?height=40&width=40",
  },
}

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(sampleUsers.dentist) // Default to dentist for demo
  const [isLoading, setIsLoading] = useState(false)

  // Initialize from localStorage if available
  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (e) {
        console.error("Failed to parse saved user", e)
      }
    }
    setIsLoading(false)
  }, [])

  // Save user to localStorage when it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem("user", JSON.stringify(user))
    }
  }, [user])

  const login = async (email: string, password: string, role: UserRole): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call
    return new Promise((resolve) => {
      setTimeout(() => {
        setUser(sampleUsers[role])
        setIsLoading(false)
        resolve(true)
      }, 1000)
    })
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  return <UserContext.Provider value={{ user, setUser, login, logout, isLoading }}>{children}</UserContext.Provider>
}

export function useUser() {
  const context = useContext(UserContext)
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider")
  }
  return context
}


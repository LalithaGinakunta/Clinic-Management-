"use client"

import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendItem,
} from "@/components/ui/chart"
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, XAxis, YAxis, Cell, Pie, PieChart } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const appointmentsByDayData = [
  { name: "Mon", appointments: 25 },
  { name: "Tue", appointments: 30 },
  { name: "Wed", appointments: 35 },
  { name: "Thu", appointments: 40 },
  { name: "Fri", appointments: 45 },
  { name: "Sat", appointments: 20 },
  { name: "Sun", appointments: 0 },
]

const appointmentTypeData = [
  { name: "Cleaning", value: 40, color: "hsl(var(--primary))" },
  { name: "Checkup", value: 30, color: "hsl(var(--primary) / 0.8)" },
  { name: "Filling", value: 15, color: "hsl(var(--primary) / 0.6)" },
  { name: "Root Canal", value: 10, color: "hsl(var(--primary) / 0.4)" },
  { name: "Other", value: 5, color: "hsl(var(--primary) / 0.2)" },
]

export function AppointmentReport() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card className="col-span-2">
        <CardHeader>
          <CardTitle>Appointments by Day of Week</CardTitle>
          <CardDescription>Distribution of appointments across weekdays</CardDescription>
        </CardHeader>
        <CardContent>
          <Chart className="h-[300px]">
            <ChartContainer>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={appointmentsByDayData}
                  margin={{
                    top: 5,
                    right: 10,
                    left: 10,
                    bottom: 20,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="name" className="text-sm text-muted-foreground" tickLine={false} axisLine={false} />
                  <YAxis className="text-sm text-muted-foreground" tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="appointments" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </Chart>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Appointment Types</CardTitle>
          <CardDescription>Distribution of appointments by type</CardDescription>
        </CardHeader>
        <CardContent>
          <Chart className="h-[300px]">
            <ChartLegend className="mb-4 justify-center gap-6">
              {appointmentTypeData.map((entry) => (
                <ChartLegendItem key={entry.name} name={entry.name} color={entry.color} />
              ))}
            </ChartLegend>
            <ChartContainer>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={appointmentTypeData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {appointmentTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <ChartTooltip content={<ChartTooltipContent />} />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </Chart>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Appointment Statistics</CardTitle>
          <CardDescription>Key metrics for appointments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Total Appointments</p>
                <p className="text-2xl font-bold">1,245</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Avg. Daily</p>
                <p className="text-2xl font-bold">28</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">No-Show Rate</p>
                <p className="text-2xl font-bold">5%</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Utilization</p>
                <p className="text-2xl font-bold">85%</p>
              </div>
            </div>
            <div className="pt-4">
              <Button className="w-full">View Detailed Report</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}


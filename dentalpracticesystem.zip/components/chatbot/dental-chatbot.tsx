"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MessageSquare, Send, X, Calendar, SmileIcon as Tooth } from "lucide-react"
import { useRouter } from "next/navigation"
import { useUser } from "@/components/user-provider"
import { cn } from "@/lib/utils"
import Image from "next/image"

interface Message {
  id: string
  content: string
  sender: "user" | "bot"
  timestamp: Date
  options?: string[]
  type?: "text" | "appointment" | "faq"
}

// Sample FAQ data
const faqData = [
  {
    question: "How often should I visit the dentist?",
    answer:
      "For most people, dentists recommend a checkup every 6 months. However, people with specific dental issues may need more frequent visits.",
  },
  {
    question: "How can I prevent cavities?",
    answer:
      "Brush twice daily with fluoride toothpaste, floss daily, limit sugary foods and drinks, and visit your dentist regularly for checkups and cleanings.",
  },
  {
    question: "What should I do in a dental emergency?",
    answer:
      "For severe pain, knocked-out teeth, or other emergencies, contact our emergency line at +91-9876543210. For less urgent issues, book an appointment through our system.",
  },
  {
    question: "Do you accept insurance?",
    answer:
      "Yes, we accept most major insurance plans. Please contact our office with your insurance information to verify coverage before your appointment.",
  },
  {
    question: "How long does a typical cleaning take?",
    answer:
      "A standard dental cleaning usually takes between 30 to 60 minutes, depending on the condition of your teeth and gums.",
  },
]

export function DentalChatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const router = useRouter()
  const { user } = useUser()

  // Initialize chat with welcome message
  useEffect(() => {
    if (messages.length === 0) {
      const initialMessages: Message[] = [
        {
          id: "1",
          content: `Hello${user ? ` ${user.name}` : ""}! I'm  = [
        {
          id: "1",
          content: \`Hello${user ? ` ${user.name}` : ""}! I'm your dental assistant. How can I help you today?`,
          sender: "bot",
          timestamp: new Date(),
          options: ["Book an appointment", "Dental emergency", "Common questions", "Contact a dentist"],
        },
      ]
      setMessages(initialMessages)
    }
  }, [messages.length, user])

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = () => {
    if (input.trim() === "") return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate bot thinking
    setTimeout(() => {
      const botResponse = generateBotResponse(input)
      setMessages((prev) => [...prev, botResponse])
      setIsTyping(false)
    }, 1000)
  }

  const handleOptionClick = (option: string) => {
    // Add user selection as a message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: option,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setIsTyping(true)

    // Simulate bot thinking
    setTimeout(() => {
      const botResponse = handleOptionResponse(option)
      setMessages((prev) => [...prev, botResponse])
      setIsTyping(false)
    }, 1000)
  }

  const generateBotResponse = (userInput: string): Message => {
    const input = userInput.toLowerCase()

    // Check for appointment-related queries
    if (input.includes("appointment") || input.includes("book") || input.includes("schedule")) {
      return {
        id: Date.now().toString(),
        content: "I'd be happy to help you book an appointment. Would you like to schedule one now?",
        sender: "bot",
        timestamp: new Date(),
        options: ["Yes, book appointment", "No, just asking"],
        type: "appointment",
      }
    }

    // Check for emergency-related queries
    if (
      input.includes("emergency") ||
      input.includes("pain") ||
      input.includes("bleeding") ||
      input.includes("accident")
    ) {
      return {
        id: Date.now().toString(),
        content:
          "If you're experiencing a dental emergency, please call our emergency line at +91-9876543210 immediately. For severe pain, bleeding, or trauma, you should seek immediate care.",
        sender: "bot",
        timestamp: new Date(),
        options: ["Call emergency line", "Book urgent appointment"],
        type: "text",
      }
    }

    // Check for FAQ matches
    for (const faq of faqData) {
      if (input.includes(faq.question.toLowerCase())) {
        return {
          id: Date.now().toString(),
          content: faq.answer,
          sender: "bot",
          timestamp: new Date(),
          type: "faq",
        }
      }
    }

    // Default response
    return {
      id: Date.now().toString(),
      content:
        "I can help you with booking appointments, answering common dental questions, or connecting you with our team. What would you like to know?",
      sender: "bot",
      timestamp: new Date(),
      options: ["Book an appointment", "Dental FAQs", "Contact us"],
      type: "text",
    }
  }

  const handleOptionResponse = (option: string): Message => {
    switch (option) {
      case "Book an appointment":
      case "Yes, book appointment":
        return {
          id: Date.now().toString(),
          content:
            "Great! I can help you book an appointment. You can either use our online booking system or I can guide you through the process here.",
          sender: "bot",
          timestamp: new Date(),
          options: ["Use online booking", "Guide me through it"],
          type: "appointment",
        }

      case "Use online booking":
        // In a real app, we would navigate to the appointments page
        setTimeout(() => {
          router.push("/appointments")
        }, 1000)

        return {
          id: Date.now().toString(),
          content:
            "I'll take you to our appointment booking page where you can select your preferred date, time, and dentist.",
          sender: "bot",
          timestamp: new Date(),
          type: "text",
        }

      case "Guide me through it":
        return {
          id: Date.now().toString(),
          content:
            "To book an appointment, I'll need some information from you. What type of dental service are you looking for?",
          sender: "bot",
          timestamp: new Date(),
          options: ["Cleaning", "Checkup", "Filling", "Consultation", "Other"],
          type: "appointment",
        }

      case "Dental emergency":
        return {
          id: Date.now().toString(),
          content:
            "If you're experiencing a dental emergency such as severe pain, swelling, bleeding, or a knocked-out tooth, please call our emergency line at +91-9876543210 immediately.",
          sender: "bot",
          timestamp: new Date(),
          options: ["Call now", "What qualifies as an emergency?"],
          type: "text",
        }

      case "Common questions":
      case "Dental FAQs":
        return {
          id: Date.now().toString(),
          content: "Here are some frequently asked questions about dental care:",
          sender: "bot",
          timestamp: new Date(),
          options: faqData.map((faq) => faq.question),
          type: "faq",
        }

      case "Contact a dentist":
      case "Contact us":
        return {
          id: Date.now().toString(),
          content:
            "You can reach our dental office at +91-9876543210 during business hours (Mon-Fri: 9AM-6PM, Sat: 9AM-2PM). Alternatively, you can email us at contact@dentalpro.com.",
          sender: "bot",
          timestamp: new Date(),
          type: "text",
        }

      default:
        // Check if the option matches any FAQ questions
        const matchedFaq = faqData.find((faq) => faq.question === option)
        if (matchedFaq) {
          return {
            id: Date.now().toString(),
            content: matchedFaq.answer,
            sender: "bot",
            timestamp: new Date(),
            options: ["Ask another question", "Book an appointment"],
            type: "faq",
          }
        }

        // Default response for other options
        return {
          id: Date.now().toString(),
          content: "Is there anything else I can help you with?",
          sender: "bot",
          timestamp: new Date(),
          options: ["Book an appointment", "Dental FAQs", "Contact us", "No, thank you"],
          type: "text",
        }
    }
  }

  return (
    <>
      {/* Floating chat button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "fixed bottom-4 right-4 z-50 rounded-full p-3 shadow-lg transition-all duration-300 hover:scale-110",
          isOpen ? "bg-red-500 hover:bg-red-600" : "bg-primary hover:bg-primary/90",
        )}
        size="icon"
      >
        {isOpen ? <X className="h-6 w-6" /> : <MessageSquare className="h-6 w-6" />}
      </Button>

      {/* Chat window */}
      <div
        className={cn(
          "fixed bottom-20 right-4 z-50 w-80 md:w-96 transition-all duration-300 transform",
          isOpen ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none",
        )}
      >
        <Card className="shadow-xl border-primary/20 overflow-hidden elegant-card">
          <CardHeader className="bg-primary text-primary-foreground p-3">
            <div className="flex items-center space-x-2">
              <div className="relative w-8 h-8">
                <Image src="/images/dental-pro-logo.png" alt="Dental Pro Logo" fill className="object-contain" />
              </div>
              <div>
                <CardTitle className="text-base">Dental Assistant</CardTitle>
                <div className="flex items-center">
                  <span className="h-2 w-2 rounded-full bg-green-400 mr-1.5"></span>
                  <span className="text-xs">Online</span>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-96 overflow-y-auto p-3 bg-muted/30">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={cn("mb-3 max-w-[85%] animate-in", message.sender === "user" ? "ml-auto" : "mr-auto")}
                >
                  <div className="flex items-start gap-2">
                    {message.sender === "bot" && (
                      <Avatar className="h-8 w-8 border-2 border-primary">
                        <AvatarImage src="/images/dental-pro-logo.png" alt="Chatbot" />
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          <Tooth className="h-4 w-4" />
                        </AvatarFallback>
                      </Avatar>
                    )}
                    <div
                      className={cn(
                        "rounded-lg p-3",
                        message.sender === "user" ? "bg-primary text-primary-foreground" : "bg-muted",
                      )}
                    >
                      <p className="text-sm">{message.content}</p>
                      {message.options && (
                        <div className="mt-2 flex flex-wrap gap-2">
                          {message.options.map((option) => (
                            <Button
                              key={option}
                              variant="outline"
                              size="sm"
                              className={cn(
                                "text-xs py-1 h-auto",
                                message.sender === "user"
                                  ? "bg-primary/20 hover:bg-primary/30 border-primary-foreground/20"
                                  : "bg-background hover:bg-accent",
                              )}
                              onClick={() => handleOptionClick(option)}
                            >
                              {option === "Book an appointment" && <Calendar className="mr-1 h-3 w-3" />}
                              {option}
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                    {message.sender === "user" && (
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user?.avatar} alt={user?.name || "User"} />
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {user?.name?.charAt(0) || "U"}
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                  <div
                    className={cn(
                      "text-xs text-muted-foreground mt-1",
                      message.sender === "user" ? "text-right" : "text-left",
                    )}
                  >
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex items-center space-x-2 mb-3">
                  <Avatar className="h-8 w-8 border-2 border-primary">
                    <AvatarImage src="/images/dental-pro-logo.png" alt="Chatbot" />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      <Tooth className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-muted rounded-lg p-3">
                    <div className="flex space-x-1">
                      <div className="h-2 w-2 rounded-full bg-muted-foreground/40 animate-bounce [animation-delay:0ms]"></div>
                      <div className="h-2 w-2 rounded-full bg-muted-foreground/40 animate-bounce [animation-delay:150ms]"></div>
                      <div className="h-2 w-2 rounded-full bg-muted-foreground/40 animate-bounce [animation-delay:300ms]"></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </CardContent>
          <CardFooter className="p-3 border-t">
            <form
              onSubmit={(e) => {
                e.preventDefault()
                handleSendMessage()
              }}
              className="flex w-full items-center space-x-2"
            >
              <Input
                placeholder="Type your message..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="elegant-input"
              />
              <Button type="submit" size="icon" disabled={!input.trim()} className="elegant-button">
                <Send className="h-4 w-4" />
                <span className="sr-only">Send</span>
              </Button>
            </form>
          </CardFooter>
        </Card>
      </div>
    </>
  )
}


import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Calendar, TrendingUp, TrendingDown } from "lucide-react"
import { Chart, ChartContainer } from "@/components/ui/chart"
import {
  Bar,
  BarChart as RechartsBarChart,
  Line,
  LineChart as RechartsLineChart,
  Pie,
  PieChart as RechartsPieChart,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

export default function FinancialReportsPage() {
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82ca9d"]

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Financial Reports</h1>
          <p className="text-muted-foreground">Detailed financial analysis and reporting</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            Date Range
          </Button>
          <Button>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-800">Total Revenue (YTD)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-800">₹2,23,50,000</div>
            <p className="text-xs text-green-700">+18% from last year</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-800">Total Expenses (YTD)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-800">₹1,45,75,000</div>
            <p className="text-xs text-blue-700">+8% from last year</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-purple-800">Net Profit (YTD)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-800">₹77,75,000</div>
            <p className="text-xs text-purple-700">+24% from last year</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-amber-800">Profit Margin</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-800">34.8%</div>
            <p className="text-xs text-amber-700">+3.2% from last year</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="revenue" className="space-y-4">
        <TabsList>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
          <TabsTrigger value="profitability">Profitability</TabsTrigger>
          <TabsTrigger value="cashflow">Cash Flow</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Trends</CardTitle>
                <CardDescription>Monthly revenue for the current year</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsBarChart
                          data={[
                            { month: "Jan", revenue: 1250000 },
                            { month: "Feb", revenue: 1420000 },
                            { month: "Mar", revenue: 1680000 },
                            { month: "Apr", revenue: 1530000 },
                            { month: "May", revenue: 1750000 },
                            { month: "Jun", revenue: 1820000 },
                            { month: "Jul", revenue: 1950000 },
                            { month: "Aug", revenue: 2010000 },
                            { month: "Sep", revenue: 1980000 },
                            { month: "Oct", revenue: 2150000 },
                            { month: "Nov", revenue: 2280000 },
                            { month: "Dec", revenue: 2450000 },
                          ]}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`} />
                          <Tooltip
                            formatter={(value) => [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Revenue"]}
                          />
                          <Legend />
                          <Bar dataKey="revenue" fill="#3b82f6" name="Revenue (₹)" />
                        </RechartsBarChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue by Procedure</CardTitle>
                <CardDescription>Distribution of revenue by procedure type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={[
                              { name: "Implants", value: 4250000 },
                              { name: "Root Canals", value: 2850000 },
                              { name: "Cleanings", value: 1750000 },
                              { name: "Fillings", value: 1500000 },
                              { name: "Crowns", value: 1250000 },
                              { name: "Others", value: 850000 },
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {[
                              { name: "Implants", value: 4250000 },
                              { name: "Root Canals", value: 2850000 },
                              { name: "Cleanings", value: 1750000 },
                              { name: "Fillings", value: 1500000 },
                              { name: "Crowns", value: 1250000 },
                              { name: "Others", value: 850000 },
                            ].map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip
                            formatter={(value) => [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Revenue"]}
                          />
                          <Legend />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Revenue by Payment Method</CardTitle>
              <CardDescription>Analysis of revenue by payment method</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ChartContainer>
                  <Chart>
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsBarChart
                        data={[
                          { method: "Credit Card", amount: 8500000, percentage: 38 },
                          { method: "Debit Card", amount: 5600000, percentage: 25 },
                          { method: "UPI", amount: 4200000, percentage: 19 },
                          { method: "Insurance", amount: 3400000, percentage: 15 },
                          { method: "Cash", amount: 650000, percentage: 3 },
                        ]}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="method" />
                        <YAxis
                          yAxisId="left"
                          orientation="left"
                          tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`}
                        />
                        <YAxis yAxisId="right" orientation="right" tickFormatter={(value) => `${value}%`} />
                        <Tooltip
                          formatter={(value, name) => {
                            if (name === "amount") {
                              return [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Amount"]
                            }
                            return [`${value}%`, "Percentage"]
                          }}
                        />
                        <Legend />
                        <Bar yAxisId="left" dataKey="amount" fill="#3b82f6" name="Amount (₹)" />
                        <Line
                          yAxisId="right"
                          type="monotone"
                          dataKey="percentage"
                          stroke="#f59e0b"
                          name="Percentage (%)"
                        />
                      </RechartsBarChart>
                    </ResponsiveContainer>
                  </Chart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expenses">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Expense Breakdown</CardTitle>
                <CardDescription>Distribution of expenses by category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={[
                              { name: "Staff Salaries", value: 8500000 },
                              { name: "Supplies", value: 3500000 },
                              { name: "Equipment", value: 1250000 },
                              { name: "Rent", value: 1800000 },
                              { name: "Utilities", value: 750000 },
                              { name: "Marketing", value: 650000 },
                              { name: "Others", value: 1200000 },
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {[
                              { name: "Staff Salaries", value: 8500000 },
                              { name: "Supplies", value: 3500000 },
                              { name: "Equipment", value: 1250000 },
                              { name: "Rent", value: 1800000 },
                              { name: "Utilities", value: 750000 },
                              { name: "Marketing", value: 650000 },
                              { name: "Others", value: 1200000 },
                            ].map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip
                            formatter={(value) => [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Expense"]}
                          />
                          <Legend />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Monthly Expenses</CardTitle>
                <CardDescription>Expense trends over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsLineChart
                          data={[
                            { month: "Jan", expenses: 850000, supplies: 280000, salaries: 570000 },
                            { month: "Feb", expenses: 920000, supplies: 320000, salaries: 600000 },
                            { month: "Mar", expenses: 980000, supplies: 350000, salaries: 630000 },
                            { month: "Apr", expenses: 940000, supplies: 310000, salaries: 630000 },
                            { month: "May", expenses: 1050000, supplies: 380000, salaries: 670000 },
                            { month: "Jun", expenses: 1120000, supplies: 420000, salaries: 700000 },
                          ]}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`} />
                          <Tooltip formatter={(value) => [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Amount"]} />
                          <Legend />
                          <Line
                            type="monotone"
                            dataKey="expenses"
                            stroke="#f43f5e"
                            name="Total Expenses"
                            strokeWidth={2}
                          />
                          <Line type="monotone" dataKey="supplies" stroke="#8884d8" name="Supplies" />
                          <Line type="monotone" dataKey="salaries" stroke="#82ca9d" name="Salaries" />
                        </RechartsLineChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Expense Analysis</CardTitle>
              <CardDescription>Detailed breakdown of expenses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Category
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Amount (YTD)
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        % of Total
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        YoY Change
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Trend
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {[
                      {
                        category: "Staff Salaries",
                        amount: "₹85,00,000",
                        percentage: 58.3,
                        change: "+7.5%",
                        trend: "up",
                      },
                      {
                        category: "Dental Supplies",
                        amount: "₹35,00,000",
                        percentage: 24.0,
                        change: "+12.2%",
                        trend: "up",
                      },
                      { category: "Equipment", amount: "₹12,50,000", percentage: 8.6, change: "-5.3%", trend: "down" },
                      { category: "Rent", amount: "₹18,00,000", percentage: 12.3, change: "+0.0%", trend: "neutral" },
                      { category: "Utilities", amount: "₹7,50,000", percentage: 5.1, change: "+3.8%", trend: "up" },
                      { category: "Marketing", amount: "₹6,50,000", percentage: 4.5, change: "+15.2%", trend: "up" },
                      { category: "Others", amount: "₹12,00,000", percentage: 8.2, change: "+2.1%", trend: "up" },
                    ].map((item, i) => (
                      <tr key={i}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {item.category}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.amount}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.percentage}%</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.change}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {item.trend === "up" ? (
                            <TrendingUp className="h-4 w-4 text-green-500" />
                          ) : item.trend === "down" ? (
                            <TrendingDown className="h-4 w-4 text-red-500" />
                          ) : (
                            <span className="inline-block h-4 w-4 bg-gray-300 rounded-full"></span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profitability">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Profit Margin Trend</CardTitle>
                <CardDescription>Monthly profit margin analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsLineChart
                          data={[
                            { month: "Jan", revenue: 1250000, expenses: 850000, margin: 32.0 },
                            { month: "Feb", revenue: 1420000, expenses: 920000, margin: 35.2 },
                            { month: "Mar", revenue: 1680000, expenses: 980000, margin: 41.7 },
                            { month: "Apr", revenue: 1530000, expenses: 940000, margin: 38.6 },
                            { month: "May", revenue: 1750000, expenses: 1050000, margin: 40.0 },
                            { month: "Jun", revenue: 1820000, expenses: 1120000, margin: 38.5 },
                          ]}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis
                            yAxisId="left"
                            orientation="left"
                            tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`}
                          />
                          <YAxis yAxisId="right" orientation="right" tickFormatter={(value) => `${value}%`} />
                          <Tooltip
                            formatter={(value, name) => {
                              if (name === "revenue") {
                                return [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Revenue"]
                              } else if (name === "expenses") {
                                return [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Expenses"]
                              }
                              return [`${value}%`, "Profit Margin"]
                            }}
                          />
                          <Legend />
                          <Bar yAxisId="left" dataKey="revenue" fill="#3b82f6" name="Revenue" />
                          <Bar yAxisId="left" dataKey="expenses" fill="#f43f5e" name="Expenses" />
                          <Line
                            yAxisId="right"
                            type="monotone"
                            dataKey="margin"
                            stroke="#10b981"
                            name="Profit Margin (%)"
                            strokeWidth={2}
                          />
                        </RechartsLineChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Profitability by Procedure</CardTitle>
                <CardDescription>Profit margin analysis by procedure type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsBarChart
                          data={[
                            { procedure: "Implants", revenue: 4250000, cost: 2125000, margin: 50 },
                            { procedure: "Root Canals", revenue: 2850000, cost: 1567500, margin: 45 },
                            { procedure: "Crowns", revenue: 1250000, cost: 687500, margin: 45 },
                            { procedure: "Fillings", revenue: 1500000, cost: 900000, margin: 40 },
                            { procedure: "Cleanings", revenue: 1750000, cost: 1137500, margin: 35 },
                            { procedure: "Others", revenue: 850000, cost: 552500, margin: 35 },
                          ]}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="procedure" />
                          <YAxis
                            yAxisId="left"
                            orientation="left"
                            tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`}
                          />
                          <YAxis yAxisId="right" orientation="right" tickFormatter={(value) => `${value}%`} />
                          <Tooltip
                            formatter={(value, name) => {
                              if (name === "revenue") {
                                return [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Revenue"]
                              } else if (name === "cost") {
                                return [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Cost"]
                              }
                              return [`${value}%`, "Profit Margin"]
                            }}
                          />
                          <Legend />
                          <Bar yAxisId="left" dataKey="revenue" fill="#3b82f6" name="Revenue" />
                          <Bar yAxisId="left" dataKey="cost" fill="#f43f5e" name="Cost" />
                          <Line
                            yAxisId="right"
                            type="monotone"
                            dataKey="margin"
                            stroke="#10b981"
                            name="Profit Margin (%)"
                          />
                        </RechartsBarChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Profitability Analysis</CardTitle>
              <CardDescription>Detailed profitability metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Metric
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Current Year
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Previous Year
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        YoY Change
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Industry Avg
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {[
                      {
                        metric: "Gross Profit Margin",
                        current: "58.3%",
                        previous: "54.8%",
                        change: "+3.5%",
                        industry: "52.0%",
                      },
                      {
                        metric: "Net Profit Margin",
                        current: "34.8%",
                        previous: "31.6%",
                        change: "+3.2%",
                        industry: "28.5%",
                      },
                      {
                        metric: "Return on Assets (ROA)",
                        current: "22.5%",
                        previous: "19.8%",
                        change: "+2.7%",
                        industry: "18.2%",
                      },
                      {
                        metric: "Return on Investment (ROI)",
                        current: "45.2%",
                        previous: "41.5%",
                        change: "+3.7%",
                        industry: "38.0%",
                      },
                      {
                        metric: "Revenue per Employee",
                        current: "₹28,50,000",
                        previous: "₹25,20,000",
                        change: "+13.1%",
                        industry: "₹24,00,000",
                      },
                      {
                        metric: "Profit per Employee",
                        current: "₹9,90,000",
                        previous: "₹7,95,000",
                        change: "+24.5%",
                        industry: "₹6,84,000",
                      },
                    ].map((item, i) => (
                      <tr key={i}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.metric}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.current}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.previous}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-green-500">{item.change}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.industry}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cashflow">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Cash Flow Statement</CardTitle>
                <CardDescription>Monthly cash flow analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsBarChart
                          data={[
                            { month: "Jan", inflow: 1150000, outflow: 950000, netflow: 200000 },
                            { month: "Feb", inflow: 1320000, outflow: 1020000, netflow: 300000 },
                            { month: "Mar", inflow: 1580000, outflow: 1080000, netflow: 500000 },
                            { month: "Apr", inflow: 1430000, outflow: 1040000, netflow: 390000 },
                            { month: "May", inflow: 1650000, outflow: 1150000, netflow: 500000 },
                            { month: "Jun", inflow: 1720000, outflow: 1220000, netflow: 500000 },
                          ]}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`} />
                          <Tooltip formatter={(value) => [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Amount"]} />
                          <Legend />
                          <Bar dataKey="inflow" fill="#10b981" name="Cash Inflow" />
                          <Bar dataKey="outflow" fill="#f43f5e" name="Cash Outflow" />
                          <Line
                            type="monotone"
                            dataKey="netflow"
                            stroke="#3b82f6"
                            name="Net Cash Flow"
                            strokeWidth={2}
                          />
                        </RechartsBarChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Accounts Receivable Aging</CardTitle>
                <CardDescription>Analysis of outstanding payments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={[
                              { name: "Current", value: 1250000 },
                              { name: "1-30 Days", value: 850000 },
                              { name: "31-60 Days", value: 450000 },
                              { name: "61-90 Days", value: 250000 },
                              { name: "90+ Days", value: 150000 },
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {[
                              { name: "Current", value: 1250000 },
                              { name: "1-30 Days", value: 850000 },
                              { name: "31-60 Days", value: 450000 },
                              { name: "61-90 Days", value: 250000 },
                              { name: "90+ Days", value: 150000 },
                            ].map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Amount"]} />
                          <Legend />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Cash Flow Analysis</CardTitle>
              <CardDescription>Detailed cash flow metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Cash Conversion Cycle</h3>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold">28 days</div>
                    <div className="text-sm text-green-600">-3 days ↓</div>
                  </div>
                  <p className="text-xs text-muted-foreground">Industry average: 35 days</p>
                  <div className="h-2 w-full bg-muted">
                    <div className="h-2 w-[80%] bg-green-500"></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Days Sales Outstanding</h3>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold">32 days</div>
                    <div className="text-sm text-green-600">-2 days ↓</div>
                  </div>
                  <p className="text-xs text-muted-foreground">Target: 30 days</p>
                  <div className="h-2 w-full bg-muted">
                    <div className="h-2 w-[94%] bg-amber-500"></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Cash Reserve Ratio</h3>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold">3.2x</div>
                    <div className="text-sm text-green-600">+0.4x ↑</div>
                  </div>
                  <p className="text-xs text-muted-foreground">Target: 3.0x</p>
                  <div className="h-2 w-full bg-muted">
                    <div className="h-2 w-[107%] bg-green-500"></div>
                  </div>
                </div>
              </div>

              <div className="mt-8 rounded-md border">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Month
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Opening Balance
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Cash Inflow
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Cash Outflow
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Net Cash Flow
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Closing Balance
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {[
                      {
                        month: "January",
                        opening: "₹45,00,000",
                        inflow: "₹11,50,000",
                        outflow: "₹9,50,000",
                        net: "₹2,00,000",
                        closing: "₹47,00,000",
                      },
                      {
                        month: "February",
                        opening: "₹47,00,000",
                        inflow: "₹13,20,000",
                        outflow: "₹10,20,000",
                        net: "₹3,00,000",
                        closing: "₹50,00,000",
                      },
                      {
                        month: "March",
                        opening: "₹50,00,000",
                        inflow: "₹15,80,000",
                        outflow: "₹10,80,000",
                        net: "₹5,00,000",
                        closing: "₹55,00,000",
                      },
                      {
                        month: "April",
                        opening: "₹55,00,000",
                        inflow: "₹14,30,000",
                        outflow: "₹10,40,000",
                        net: "₹3,90,000",
                        closing: "₹58,90,000",
                      },
                      {
                        month: "May",
                        opening: "₹58,90,000",
                        inflow: "₹16,50,000",
                        outflow: "₹11,50,000",
                        net: "₹5,00,000",
                        closing: "₹63,90,000",
                      },
                      {
                        month: "June",
                        opening: "₹63,90,000",
                        inflow: "₹17,20,000",
                        outflow: "₹12,20,000",
                        net: "₹5,00,000",
                        closing: "₹68,90,000",
                      },
                    ].map((item, i) => (
                      <tr key={i}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.month}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.opening}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-green-500">{item.inflow}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-red-500">{item.outflow}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-500">{item.net}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {item.closing}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}


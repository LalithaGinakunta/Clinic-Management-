import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageSquare, Search, Send, FileText, Calendar, User, ThumbsUp, ThumbsDown } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"

export default function PortalPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Patient Communication Portal</h1>
          <p className="text-muted-foreground">Secure messaging and patient resources</p>
        </div>
        <div className="flex items-center gap-2">
          <Button>
            <MessageSquare className="mr-2 h-4 w-4" />
            New Message
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Patient Search</CardTitle>
              <CardDescription>Find patients to message</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Search patients..." className="pl-8" />
              </div>
              <div className="mt-4 space-y-2">
                {[
                  { name: "Sarah Johnson", id: "P-1001", status: "Active", unread: 2 },
                  { name: "Michael Chen", id: "P-1002", status: "Active", unread: 0 },
                  { name: "Emily Davis", id: "P-1003", status: "Active", unread: 1 },
                  { name: "Robert Wilson", id: "P-1004", status: "Active", unread: 0 },
                  { name: "Jennifer Lopez", id: "P-1005", status: "New", unread: 0 },
                ].map((patient, i) => (
                  <div
                    key={i}
                    className={`flex items-center justify-between p-2 rounded-md cursor-pointer ${
                      i === 0 ? "bg-primary/10" : "hover:bg-muted"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={`/placeholder.svg?height=32&width=32`} alt={patient.name} />
                        <AvatarFallback>
                          {patient.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{patient.name}</p>
                        <p className="text-xs text-muted-foreground">{patient.id}</p>
                      </div>
                    </div>
                    {patient.unread > 0 && <Badge className="ml-auto">{patient.unread}</Badge>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Patient Resources</CardTitle>
              <CardDescription>Educational materials</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { title: "Oral Hygiene Guide", type: "PDF", icon: FileText },
                  { title: "Post-Treatment Care", type: "PDF", icon: FileText },
                  { title: "Dental Procedures Explained", type: "Video", icon: FileText },
                  { title: "Nutrition and Dental Health", type: "PDF", icon: FileText },
                ].map((resource, i) => (
                  <div key={i} className="flex items-center gap-3 p-2 rounded-md hover:bg-muted cursor-pointer">
                    <div className="bg-primary/10 p-2 rounded-full">
                      <resource.icon className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{resource.title}</p>
                      <p className="text-xs text-muted-foreground">{resource.type}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2">
          <Card className="h-full flex flex-col">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src="/placeholder.svg" alt="Sarah Johnson" />
                    <AvatarFallback>SJ</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle>Sarah Johnson</CardTitle>
                    <CardDescription>Patient ID: P-1001</CardDescription>
                  </div>
                </div>
                <div>
                  <Badge variant="outline">Last visit: Mar 15, 2025</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-1 overflow-auto">
              <Tabs defaultValue="messages" className="h-full flex flex-col">
                <TabsList>
                  <TabsTrigger value="messages">Messages</TabsTrigger>
                  <TabsTrigger value="appointments">Appointments</TabsTrigger>
                  <TabsTrigger value="records">Records</TabsTrigger>
                  <TabsTrigger value="feedback">Feedback</TabsTrigger>
                </TabsList>
                <TabsContent value="messages" className="flex-1 flex flex-col">
                  <div className="flex-1 space-y-4 py-4">
                    <div className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src="/placeholder.svg" alt="Dr. Johnson" />
                        <AvatarFallback>DJ</AvatarFallback>
                      </Avatar>
                      <div className="bg-muted p-3 rounded-lg rounded-tl-none max-w-[80%]">
                        <p className="text-sm">
                          Hello Sarah, I wanted to follow up on your recent cleaning appointment. How are you feeling?
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">Mar 16, 2025 • 10:23 AM</p>
                      </div>
                    </div>
                    <div className="flex gap-3 justify-end">
                      <div className="bg-primary/10 p-3 rounded-lg rounded-tr-none max-w-[80%]">
                        <p className="text-sm">
                          Hi Dr. Johnson, I'm feeling great! My teeth feel much cleaner. I did have a question about
                          flossing technique though.
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">Mar 16, 2025 • 11:45 AM</p>
                      </div>
                      <Avatar className="h-8 w-8">
                        <AvatarImage src="/placeholder.svg" alt="Sarah Johnson" />
                        <AvatarFallback>SJ</AvatarFallback>
                      </Avatar>
                    </div>
                    <div className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src="/placeholder.svg" alt="Dr. Johnson" />
                        <AvatarFallback>DJ</AvatarFallback>
                      </Avatar>
                      <div className="bg-muted p-3 rounded-lg rounded-tl-none max-w-[80%]">
                        <p className="text-sm">
                          I'm glad to hear that! Regarding flossing, I recommend using a C-shape technique where you
                          wrap the floss around each tooth. I've attached a guide that demonstrates this.
                        </p>
                        <div className="mt-2 p-2 bg-background rounded border flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          <span className="text-sm">Flossing_Guide.pdf</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">Mar 16, 2025 • 1:30 PM</p>
                      </div>
                    </div>
                    <div className="flex gap-3 justify-end">
                      <div className="bg-primary/10 p-3 rounded-lg rounded-tr-none max-w-[80%]">
                        <p className="text-sm">
                          Thank you for the guide! That's very helpful. Also, I wanted to ask if I should schedule
                          another cleaning in 6 months?
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">Mar 16, 2025 • 2:15 PM</p>
                      </div>
                      <Avatar className="h-8 w-8">
                        <AvatarImage src="/placeholder.svg" alt="Sarah Johnson" />
                        <AvatarFallback>SJ</AvatarFallback>
                      </Avatar>
                    </div>
                    <div className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src="/placeholder.svg" alt="Dr. Johnson" />
                        <AvatarFallback>DJ</AvatarFallback>
                      </Avatar>
                      <div className="bg-muted p-3 rounded-lg rounded-tl-none max-w-[80%]">
                        <p className="text-sm">
                          Yes, I recommend scheduling your next cleaning in 6 months. You can use our online booking
                          system or call the office to set that up. Let me know if you have any other questions!
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">Mar 16, 2025 • 3:05 PM</p>
                      </div>
                    </div>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex gap-2">
                      <Textarea placeholder="Type your message..." className="min-h-[80px]" />
                      <Button className="self-end" size="icon">
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="appointments">
                  <div className="space-y-4 py-4">
                    <h3 className="text-lg font-medium">Upcoming Appointments</h3>
                    <div className="space-y-4">
                      {[
                        {
                          date: "Sep 15, 2025",
                          time: "10:30 AM",
                          type: "Regular Cleaning",
                          doctor: "Dr. Johnson",
                          status: "Confirmed",
                        },
                      ].map((appointment, i) => (
                        <Card key={i}>
                          <CardContent className="p-4">
                            <div className="flex items-start gap-4">
                              <div className="bg-primary/10 p-2 rounded-full">
                                <Calendar className="h-5 w-5 text-primary" />
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center justify-between">
                                  <h4 className="font-medium">{appointment.type}</h4>
                                  <Badge>{appointment.status}</Badge>
                                </div>
                                <p className="text-sm">
                                  {appointment.date} at {appointment.time}
                                </p>
                                <p className="text-sm text-muted-foreground">With {appointment.doctor}</p>
                                <div className="mt-2 flex gap-2">
                                  <Button variant="outline" size="sm">
                                    Reschedule
                                  </Button>
                                  <Button variant="outline" size="sm">
                                    Cancel
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    <h3 className="text-lg font-medium mt-6">Past Appointments</h3>
                    <div className="space-y-4">
                      {[
                        {
                          date: "Mar 15, 2025",
                          time: "9:00 AM",
                          type: "Regular Cleaning",
                          doctor: "Dr. Johnson",
                          status: "Completed",
                        },
                        {
                          date: "Sep 20, 2024",
                          time: "11:15 AM",
                          type: "Regular Cleaning",
                          doctor: "Dr. Martinez",
                          status: "Completed",
                        },
                      ].map((appointment, i) => (
                        <Card key={i}>
                          <CardContent className="p-4">
                            <div className="flex items-start gap-4">
                              <div className="bg-muted p-2 rounded-full">
                                <Calendar className="h-5 w-5 text-muted-foreground" />
                              </div>
                              <div>
                                <h4 className="font-medium">{appointment.type}</h4>
                                <p className="text-sm">
                                  {appointment.date} at {appointment.time}
                                </p>
                                <p className="text-sm text-muted-foreground">With {appointment.doctor}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    <div className="mt-4">
                      <Button>
                        <Calendar className="mr-2 h-4 w-4" />
                        Schedule New Appointment
                      </Button>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="records">
                  <div className="space-y-4 py-4">
                    <h3 className="text-lg font-medium">Treatment History</h3>
                    <div className="space-y-4">
                      {[
                        {
                          date: "Mar 15, 2025",
                          procedure: "Dental Cleaning",
                          notes: "Regular cleaning and examination. No cavities found.",
                          doctor: "Dr. Johnson",
                        },
                        {
                          date: "Sep 20, 2024",
                          procedure: "Dental Cleaning & X-Rays",
                          notes: "Full mouth X-rays taken. Minor plaque buildup removed.",
                          doctor: "Dr. Martinez",
                        },
                        {
                          date: "Mar 10, 2024",
                          procedure: "Filling (Tooth #18)",
                          notes: "Small cavity filled on lower left molar.",
                          doctor: "Dr. Johnson",
                        },
                      ].map((record, i) => (
                        <Card key={i}>
                          <CardContent className="p-4">
                            <div className="flex items-start gap-4">
                              <div className="bg-primary/10 p-2 rounded-full">
                                <FileText className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <h4 className="font-medium">{record.procedure}</h4>
                                <p className="text-sm">{record.date}</p>
                                <p className="text-sm mt-1">{record.notes}</p>
                                <p className="text-sm text-muted-foreground mt-1">Provider: {record.doctor}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    <h3 className="text-lg font-medium mt-6">Treatment Plan</h3>
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <div className="bg-primary/10 p-2 rounded-full">
                            <Calendar className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium">Preventive Care Plan</h4>
                            <p className="text-sm mt-1">Regular cleanings every 6 months with annual X-rays.</p>
                            <p className="text-sm text-muted-foreground mt-1">Next recommended visit: September 2025</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="mt-4">
                      <Button variant="outline">
                        <FileText className="mr-2 h-4 w-4" />
                        Request Records
                      </Button>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="feedback">
                  <div className="space-y-4 py-4">
                    <h3 className="text-lg font-medium">Provide Feedback</h3>
                    <p className="text-sm text-muted-foreground">
                      We value your opinion! Please share your thoughts on your recent experience.
                    </p>

                    <div className="space-y-4 mt-4">
                      <div>
                        <h4 className="text-sm font-medium mb-2">How would you rate your recent visit?</h4>
                        <div className="flex gap-2">
                          {[1, 2, 3, 4, 5].map((rating) => (
                            <Button
                              key={rating}
                              variant={rating === 5 ? "default" : "outline"}
                              size="sm"
                              className="h-10 w-10"
                            >
                              {rating}
                            </Button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium mb-2">Was the staff friendly and helpful?</h4>
                        <div className="flex gap-2">
                          <Button variant="default" size="sm" className="flex gap-2">
                            <ThumbsUp className="h-4 w-4" />
                            Yes
                          </Button>
                          <Button variant="outline" size="sm" className="flex gap-2">
                            <ThumbsDown className="h-4 w-4" />
                            No
                          </Button>
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium mb-2">Additional comments</h4>
                        <Textarea placeholder="Share your experience..." className="min-h-[100px]" />
                      </div>

                      <Button>Submit Feedback</Button>
                    </div>

                    <h3 className="text-lg font-medium mt-8">Previous Feedback</h3>
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <div className="bg-primary/10 p-2 rounded-full">
                            <User className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium">Visit on Sep 20, 2024</h4>
                              <div className="flex">
                                {[1, 2, 3, 4].map((star) => (
                                  <svg key={star} className="h-4 w-4 fill-primary" viewBox="0 0 20 20">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                  </svg>
                                ))}
                                <svg className="h-4 w-4 fill-muted stroke-muted-foreground" viewBox="0 0 20 20">
                                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                              </div>
                            </div>
                            <p className="text-sm mt-1">
                              "Dr. Martinez was very thorough and explained everything clearly. The hygienist was gentle
                              and professional."
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}


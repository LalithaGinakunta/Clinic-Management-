"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Package } from "lucide-react"

const inventoryAlerts = [
  {
    id: "1",
    item: "Dental Composite",
    currentStock: 5,
    minStock: 10,
    status: "Low",
  },
  {
    id: "2",
    item: "Disposable Gloves",
    currentStock: 2,
    minStock: 20,
    status: "Critical",
  },
  {
    id: "3",
    item: "Dental Anesthetic",
    currentStock: 8,
    minStock: 15,
    status: "Low",
  },
  {
    id: "4",
    item: "Dental Floss",
    currentStock: 3,
    minStock: 10,
    status: "Low",
  },
]

export function InventoryAlerts() {
  return (
    <div className="space-y-4">
      {inventoryAlerts.map((item) => (
        <div key={item.id} className="flex items-center justify-between space-x-4 rounded-md border p-4">
          <div className="flex items-center space-x-4">
            <div className="rounded-full bg-primary/10 p-2">
              <Package className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium leading-none">{item.item}</p>
              <p className="text-sm text-muted-foreground">
                Stock: {item.currentStock}/{item.minStock}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant={item.status === "Critical" ? "destructive" : "outline"}>{item.status}</Badge>
            <Button size="sm" variant="outline">
              Reorder
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}


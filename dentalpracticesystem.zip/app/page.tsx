import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, ArrowRight, Calendar, Clock, CreditCard, Shield, Star } from "lucide-react"
import DentalChatbot from "@/components/DentalChatbot"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation */}
      <header className="border-b bg-white dark:bg-gray-950 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="relative w-10 h-10">
              <Image src="/images/dental-pro-logo.png" alt="Dental Pro Logo" fill className="object-contain" priority />
            </div>
            <span className="text-xl font-semibold">
              <span className="text-dental-blue">Dental</span>
              <span className="text-dental-pink"> Prō</span>
            </span>
          </div>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="#services" className="text-sm font-medium hover:text-primary transition-colors">
              Services
            </Link>
            <Link href="#about" className="text-sm font-medium hover:text-primary transition-colors">
              About Us
            </Link>
            <Link href="#testimonials" className="text-sm font-medium hover:text-primary transition-colors">
              Testimonials
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:text-primary transition-colors">
              Contact
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <Link href="/login">
              <Button variant="outline" className="elegant-button">
                Log In
              </Button>
            </Link>
            <Link href="/register">
              <Button className="elegant-button">Register</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 to-pink-50 dark:from-gray-900 dark:to-gray-800 py-20 overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="container mx-auto px-4 flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2 space-y-6 animate-in slide-in">
            <Badge className="px-3 py-1 text-sm bg-primary/10 text-primary border-primary/20 mb-4">
              Modern Dental Care
            </Badge>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Your Smile Deserves <span className="text-primary">The Best Care</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl">
              Experience state-of-the-art dental care with our team of expert dentists. Book appointments, access
              records, and manage your dental health all in one place.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <Link href="/register">
                <Button size="lg" className="elegant-button">
                  Get Started
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/appointments">
                <Button size="lg" variant="outline" className="elegant-button">
                  <Calendar className="mr-2 h-4 w-4" />
                  Book Appointment
                </Button>
              </Link>
            </div>
            <div className="flex items-center gap-6 pt-4">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="w-10 h-10 rounded-full border-2 border-background overflow-hidden">
                    <Image
                      src={`/placeholder.svg?height=40&width=40&text=${i}`}
                      alt={`Patient ${i}`}
                      width={40}
                      height={40}
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>
              <div>
                <div className="flex items-center">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground">
                  <span className="font-medium">4.9/5</span> from over 2,000 reviews
                </p>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 relative">
            <div className="relative w-full h-[400px] md:h-[500px] animate-in slide-in">
              <Image
                src="/placeholder.svg?height=500&width=600&text=Dental+Care+Image"
                alt="Dental Care"
                fill
                className="object-contain"
                priority
              />
            </div>

            <div className="absolute -bottom-6 -left-6 bg-white dark:bg-gray-900 rounded-lg shadow-lg p-4 border animate-in slide-in">
              <div className="flex items-center gap-3">
                <div className="bg-green-100 dark:bg-green-900 rounded-full p-2">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="font-medium">Instant Booking</p>
                  <p className="text-sm text-muted-foreground">Schedule in seconds</p>
                </div>
              </div>
            </div>

            <div className="absolute -top-6 -right-6 bg-white dark:bg-gray-900 rounded-lg shadow-lg p-4 border animate-in slide-in">
              <div className="flex items-center gap-3">
                <div className="bg-blue-100 dark:bg-blue-900 rounded-full p-2">
                  <Shield className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="font-medium">Secure Records</p>
                  <p className="text-sm text-muted-foreground">Private & protected</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white dark:bg-gray-950" id="services">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <Badge className="px-3 py-1 text-sm bg-primary/10 text-primary border-primary/20 mb-4">Our Services</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Comprehensive Dental Care Services</h2>
            <p className="text-lg text-muted-foreground">
              We offer a wide range of dental services to keep your smile healthy and beautiful. Our team of experts is
              dedicated to providing the highest quality care.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Preventive Care",
                description: "Regular checkups, cleanings, and screenings to prevent dental issues before they start.",
                icon: Shield,
                color: "bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400",
              },
              {
                title: "Restorative Dentistry",
                description: "Fillings, crowns, bridges, and implants to restore damaged or missing teeth.",
                icon: CheckCircle,
                color: "bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400",
              },
              {
                title: "Cosmetic Dentistry",
                description: "Teeth whitening, veneers, and other treatments to enhance your smile's appearance.",
                icon: Star,
                color: "bg-yellow-100 dark:bg-yellow-900 text-yellow-600 dark:text-yellow-400",
              },
              {
                title: "Pediatric Dentistry",
                description: "Specialized care for children in a friendly, comfortable environment.",
                icon: Shield,
                color: "bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400",
              },
              {
                title: "Emergency Care",
                description: "Prompt attention for dental emergencies to relieve pain and prevent further damage.",
                icon: Clock,
                color: "bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-400",
              },
              {
                title: "Orthodontics",
                description: "Braces, aligners, and other treatments to straighten teeth and correct bite issues.",
                icon: CheckCircle,
                color: "bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400",
              },
            ].map((service, index) => (
              <Card key={index} className="border-none shadow-lg hover-card">
                <CardContent className="p-6">
                  <div className={`rounded-full p-3 w-fit ${service.color} mb-4`}>
                    <service.icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground mb-4">{service.description}</p>
                  <Link href="/services" className="text-primary font-medium flex items-center hover:underline">
                    Learn more <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <Badge className="px-3 py-1 text-sm bg-primary/10 text-primary border-primary/20 mb-4">How It Works</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Simple Process, Exceptional Care</h2>
            <p className="text-lg text-muted-foreground">
              Our streamlined digital platform makes managing your dental care easier than ever.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Book Your Appointment",
                description:
                  "Schedule appointments online anytime, anywhere. Choose your preferred dentist and time slot.",
                icon: Calendar,
                color: "bg-primary text-primary-foreground",
              },
              {
                title: "Receive Quality Care",
                description:
                  "Visit our office for your appointment and receive top-notch dental care from our experts.",
                icon: CheckCircle,
                color: "bg-primary text-primary-foreground",
              },
              {
                title: "Manage Your Records",
                description:
                  "Access your dental records, treatment plans, and payments through your secure patient portal.",
                icon: CreditCard,
                color: "bg-primary text-primary-foreground",
              },
            ].map((step, index) => (
              <div key={index} className="text-center">
                <div className="relative mb-8">
                  <div className={`rounded-full p-4 w-16 h-16 mx-auto flex items-center justify-center ${step.color}`}>
                    <step.icon className="h-8 w-8" />
                  </div>
                  <div className="absolute top-8 left-1/2 h-0.5 bg-primary/20 w-full hidden md:block"></div>
                  <div className="absolute top-7 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/register">
              <Button size="lg" className="elegant-button">
                Get Started Today
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white dark:bg-gray-950" id="testimonials">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <Badge className="px-3 py-1 text-sm bg-primary/10 text-primary border-primary/20 mb-4">Testimonials</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Patients Say</h2>
            <p className="text-lg text-muted-foreground">
              Don't just take our word for it. Here's what our patients have to say about their experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: "Priya Sharma",
                role: "Patient for 3 years",
                content:
                  "The online booking system is so convenient! I can schedule appointments anytime, and the reminders ensure I never miss a visit. The dental care is top-notch too!",
                avatar: "/placeholder.svg?height=60&width=60&text=PS",
              },
              {
                name: "Rahul Patel",
                role: "Patient for 1 year",
                content:
                  "As someone with dental anxiety, I appreciate how the team makes me feel comfortable. The patient portal is great for tracking my treatment plan and payments.",
                avatar: "/placeholder.svg?height=60&width=60&text=RP",
              },
              {
                name: "Ananya Gupta",
                role: "Patient for 2 years",
                content:
                  "My children love coming to the dentist now! The pediatric care is exceptional, and being able to manage all our family's appointments in one place is a lifesaver.",
                avatar: "/placeholder.svg?height=60&width=60&text=AG",
              },
            ].map((testimonial, index) => (
              <Card key={index} className="border-none shadow-lg hover-card">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="flex -space-x-2">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-muted-foreground mb-6 italic">"{testimonial.content}"</p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                      <Image
                        src={testimonial.avatar || "/placeholder.svg"}
                        alt={testimonial.name}
                        width={48}
                        height={48}
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="md:w-2/3">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Experience Better Dental Care?</h2>
              <p className="text-xl opacity-90 mb-6">
                Join thousands of satisfied patients who have transformed their dental experience with Dental Prō.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/register">
                  <Button size="lg" variant="secondary" className="elegant-button">
                    Create Account
                  </Button>
                </Link>
                <Link href="/appointments">
                  <Button
                    size="lg"
                    variant="outline"
                    className="bg-transparent border-white text-white hover:bg-white/10 elegant-button"
                  >
                    Book Appointment
                  </Button>
                </Link>
              </div>
            </div>
            <div className="md:w-1/3 relative">
              <div className="relative w-full h-[200px] md:h-[300px]">
                <Image
                  src="/placeholder.svg?height=300&width=300&text=Dental+Care"
                  alt="Dental Care"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-white dark:bg-gray-950" id="contact">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <Badge className="px-3 py-1 text-sm bg-primary/10 text-primary border-primary/20 mb-4">Contact Us</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Get in Touch</h2>
            <p className="text-lg text-muted-foreground">
              Have questions or need assistance? Our team is here to help.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-none shadow-lg hover-card">
              <CardContent className="p-6 text-center">
                <div className="rounded-full p-3 w-fit mx-auto bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6"
                  >
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Phone</h3>
                <p className="text-muted-foreground mb-4">Call us for immediate assistance</p>
                <a href="tel:+919876543210" className="text-primary font-medium hover:underline">
                  +91 9876 543 210
                </a>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg hover-card">
              <CardContent className="p-6 text-center">
                <div className="rounded-full p-3 w-fit mx-auto bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400 mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6"
                  >
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                    <polyline points="22,6 12,13 2,6"></polyline>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Email</h3>
                <p className="text-muted-foreground mb-4">Send us an email anytime</p>
                <a href="mailto:contact@dentalpro.com" className="text-primary font-medium hover:underline">
                  contact@dentalpro.com
                </a>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg hover-card">
              <CardContent className="p-6 text-center">
                <div className="rounded-full p-3 w-fit mx-auto bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400 mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6"
                  >
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                    <circle cx="12" cy="10" r="3"></circle>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Location</h3>
                <p className="text-muted-foreground mb-4">Visit our dental clinic</p>
                <p className="text-primary font-medium">123 Dental Street, Bangalore, India</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="relative w-10 h-10">
                  <Image src="/images/dental-pro-logo.png" alt="Dental Pro Logo" fill className="object-contain" />
                </div>
                <span className="text-xl font-semibold">
                  <span className="text-dental-blue">Dental</span>
                  <span className="text-dental-pink"> Prō</span>
                </span>
              </div>
              <p className="text-muted-foreground mb-4">
                Modern dental practice management system for dentists, staff, and patients.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-muted-foreground hover:text-primary">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                  </svg>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                  </svg>
                </a>
              </div>
            </div>

            <div>
              <h3 className="font-bold mb-4">Services</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Preventive Care
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Restorative Dentistry
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Cosmetic Dentistry
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Pediatric Dentistry
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Emergency Care
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold mb-4">Company</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Our Team
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Careers
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    Cookie Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    HIPAA Compliance
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t pt-8 text-center text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} Dental Prō. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Chatbot */}
      <DentalChatbot />
    </div>
  )
}


"use client"

import { useState } from "react"
import { Download, Filter, Package, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { InventoryForm } from "@/components/inventory/inventory-form"

// Sample inventory data
const inventoryItems = [
  {
    id: "1",
    name: "Dental Composite",
    category: "Materials",
    currentStock: 15,
    minStock: 10,
    supplier: "Dental Supplies Co.",
    lastOrdered: "2023-08-10",
    status: "In Stock",
  },
  {
    id: "2",
    name: "Disposable Gloves (S)",
    category: "Supplies",
    currentStock: 5,
    minStock: 20,
    supplier: "Medical Essentials",
    lastOrdered: "2023-08-05",
    status: "Low Stock",
  },
  {
    id: "3",
    name: "Dental Anesthetic",
    category: "Medications",
    currentStock: 8,
    minStock: 15,
    supplier: "Pharma Solutions",
    lastOrdered: "2023-07-28",
    status: "Low Stock",
  },
  {
    id: "4",
    name: "Dental Floss",
    category: "Supplies",
    currentStock: 30,
    minStock: 10,
    supplier: "Dental Supplies Co.",
    lastOrdered: "2023-08-15",
    status: "In Stock",
  },
  {
    id: "5",
    name: "Dental Burs",
    category: "Tools",
    currentStock: 25,
    minStock: 10,
    supplier: "Dental Tools Inc.",
    lastOrdered: "2023-07-20",
    status: "In Stock",
  },
  {
    id: "6",
    name: "Sterilization Pouches",
    category: "Supplies",
    currentStock: 2,
    minStock: 15,
    supplier: "Medical Essentials",
    lastOrdered: "2023-08-01",
    status: "Critical",
  },
  {
    id: "7",
    name: "X-Ray Films",
    category: "Imaging",
    currentStock: 18,
    minStock: 10,
    supplier: "Imaging Supplies",
    lastOrdered: "2023-07-15",
    status: "In Stock",
  },
]

export function InventoryOverview() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isInventoryFormOpen, setIsInventoryFormOpen] = useState(false)

  const filteredItems = inventoryItems.filter(
    (item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.supplier.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="p-4 md:p-8 pt-6">
      <Tabs defaultValue="all" className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <TabsList>
            <TabsTrigger value="all">All Items</TabsTrigger>
            <TabsTrigger value="low">Low Stock</TabsTrigger>
            <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
            <Button size="sm" onClick={() => setIsInventoryFormOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Item
            </Button>
          </div>
        </div>

        <TabsContent value="all" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Items</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{inventoryItems.length}</div>
                <p className="text-xs text-muted-foreground">
                  Across {new Set(inventoryItems.map((item) => item.category)).size} categories
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Low Stock Items</CardTitle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  className="h-4 w-4 text-muted-foreground"
                >
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {inventoryItems.filter((item) => item.status === "Low Stock" || item.status === "Critical").length}
                </div>
                <p className="text-xs text-muted-foreground">Items that need to be restocked</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Suppliers</CardTitle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  className="h-4 w-4 text-muted-foreground"
                >
                  <rect width="20" height="14" x="2" y="5" rx="2" />
                  <path d="M2 10h20" />
                </svg>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{new Set(inventoryItems.map((item) => item.supplier)).size}</div>
                <p className="text-xs text-muted-foreground">Active suppliers</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Recent Orders</CardTitle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  className="h-4 w-4 text-muted-foreground"
                >
                  <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                </svg>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-muted-foreground">Orders placed this month</p>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search inventory..."
                className="w-full pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>

          <Card>
            <CardHeader className="px-6 py-4">
              <CardTitle>Inventory</CardTitle>
              <CardDescription>Manage dental supplies and equipment</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Stock Level</TableHead>
                    <TableHead>Supplier</TableHead>
                    <TableHead>Last Ordered</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{item.category}</TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          <div className="flex justify-between text-xs">
                            <span>{item.currentStock}</span>
                            <span>{item.minStock}</span>
                          </div>
                          <Progress
                            value={(item.currentStock / item.minStock) * 100}
                            className="h-2"
                            indicatorClassName={
                              item.status === "Critical"
                                ? "bg-destructive"
                                : item.status === "Low Stock"
                                  ? "bg-warning"
                                  : "bg-primary"
                            }
                          />
                        </div>
                      </TableCell>
                      <TableCell>{item.supplier}</TableCell>
                      <TableCell>{item.lastOrdered}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            item.status === "In Stock"
                              ? "default"
                              : item.status === "Low Stock"
                                ? "outline"
                                : "destructive"
                          }
                        >
                          {item.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          Reorder
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="low" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Low Stock Items</CardTitle>
              <CardDescription>Items that need to be restocked</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {inventoryItems
                  .filter((item) => item.status === "Low Stock" || item.status === "Critical")
                  .map((item) => (
                    <div key={item.id} className="flex items-center justify-between border rounded-md p-4">
                      <div className="flex items-center gap-4">
                        <div className="rounded-full bg-primary/10 p-2">
                          <Package className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {item.currentStock} in stock (min: {item.minStock})
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={item.status === "Critical" ? "destructive" : "outline"}>{item.status}</Badge>
                        <Button size="sm">Reorder</Button>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="suppliers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Suppliers</CardTitle>
              <CardDescription>Manage your suppliers and orders</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array.from(new Set(inventoryItems.map((item) => item.supplier))).map((supplier, index) => (
                  <div key={index} className="flex items-center justify-between border rounded-md p-4">
                    <div>
                      <p className="font-medium">{supplier}</p>
                      <p className="text-sm text-muted-foreground">
                        {inventoryItems.filter((item) => item.supplier === supplier).length} items
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        View Items
                      </Button>
                      <Button size="sm">Contact</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {isInventoryFormOpen && (
        <InventoryForm isOpen={isInventoryFormOpen} onClose={() => setIsInventoryFormOpen(false)} />
      )}
    </div>
  )
}


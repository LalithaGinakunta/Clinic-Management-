"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PatientAppointments } from "@/components/dashboard/patient-appointments"
import { PatientRecords } from "@/components/dashboard/patient-records"
import { PatientBilling } from "@/components/dashboard/patient-billing"
import { Calendar, CreditCard, FileText, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"

export function PatientDashboard() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h2 className="text-xl font-semibold tracking-tight">Welcome to Your Patient Portal</h2>
          <p className="text-sm text-muted-foreground">Manage your appointments, records, and payments in one place</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Bell className="mr-2 h-4 w-4" />
            Notifications
          </Button>
          <Button size="sm">
            <Calendar className="mr-2 h-4 w-4" />
            Book Appointment
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Appointment</CardTitle>
            <Calendar className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Sep 15, 2023</div>
            <p className="text-xs text-muted-foreground">Dental Cleaning at 10:30 AM</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Medical Records</CardTitle>
            <FileText className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-muted-foreground">Last updated 2 weeks ago</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding Balance</CardTitle>
            <CreditCard className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$150.00</div>
            <p className="text-xs text-muted-foreground">Due by September 30, 2023</p>
          </CardContent>
        </Card>
      </div>
      <Tabs defaultValue="appointments" className="space-y-4">
        <TabsList>
          <TabsTrigger value="appointments">My Appointments</TabsTrigger>
          <TabsTrigger value="records">Medical Records</TabsTrigger>
          <TabsTrigger value="billing">Billing & Payments</TabsTrigger>
        </TabsList>
        <TabsContent value="appointments" className="space-y-4">
          <PatientAppointments />
        </TabsContent>
        <TabsContent value="records" className="space-y-4">
          <PatientRecords />
        </TabsContent>
        <TabsContent value="billing" className="space-y-4">
          <PatientBilling />
        </TabsContent>
      </Tabs>
    </div>
  )
}


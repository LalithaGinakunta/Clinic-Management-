import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, CreditCard, Download, DollarSign } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function BillingPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Billing & Insurance</h1>
          <p className="text-muted-foreground">Manage invoices, payments, and insurance claims</p>
        </div>
        <div className="flex items-center gap-2">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Invoice
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-800">Total Revenue (MTD)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-800">₹24,56,800</div>
            <p className="text-xs text-green-700">+12% from last month</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-800">Outstanding Invoices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-800">₹8,24,500</div>
            <p className="text-xs text-blue-700">32 invoices pending</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-purple-800">Insurance Claims</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-800">₹15,78,000</div>
            <p className="text-xs text-purple-700">18 claims in process</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-amber-800">Average Invoice</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-800">₹32,500</div>
            <p className="text-xs text-amber-700">Based on last 30 days</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div>
              <CardTitle>Invoices & Payments</CardTitle>
              <CardDescription>Manage billing and payment records</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Search invoices..." className="pl-8 w-[250px]" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Filter by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Invoices</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="invoices" className="space-y-4">
            <TabsList>
              <TabsTrigger value="invoices">Invoices</TabsTrigger>
              <TabsTrigger value="payments">Payments</TabsTrigger>
              <TabsTrigger value="claims">Insurance Claims</TabsTrigger>
            </TabsList>
            <TabsContent value="invoices">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice #</TableHead>
                      <TableHead>Patient</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      {
                        id: "INV-1001",
                        patient: "Sarah Johnson",
                        date: "Mar 15, 2025",
                        amount: "₹24,500",
                        status: "Paid",
                      },
                      {
                        id: "INV-1002",
                        patient: "Michael Chen",
                        date: "Mar 10, 2025",
                        amount: "₹85,000",
                        status: "Pending",
                      },
                      {
                        id: "INV-1003",
                        patient: "Emily Davis",
                        date: "Feb 28, 2025",
                        amount: "₹12,500",
                        status: "Paid",
                      },
                      {
                        id: "INV-1004",
                        patient: "Robert Wilson",
                        date: "Feb 22, 2025",
                        amount: "₹47,500",
                        status: "Overdue",
                      },
                      {
                        id: "INV-1005",
                        patient: "Jennifer Lopez",
                        date: "Feb 15, 2025",
                        amount: "₹19,500",
                        status: "Pending",
                      },
                      {
                        id: "INV-1006",
                        patient: "David Brown",
                        date: "Jan 30, 2025",
                        amount: "₹32,000",
                        status: "Paid",
                      },
                    ].map((invoice, i) => (
                      <TableRow key={i}>
                        <TableCell>{invoice.id}</TableCell>
                        <TableCell className="font-medium">{invoice.patient}</TableCell>
                        <TableCell>{invoice.date}</TableCell>
                        <TableCell>{invoice.amount}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              invoice.status === "Paid"
                                ? "default"
                                : invoice.status === "Pending"
                                  ? "outline"
                                  : "destructive"
                            }
                          >
                            {invoice.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              <Download className="h-4 w-4" />
                            </Button>
                            <Button size="sm">
                              <DollarSign className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
            <TabsContent value="payments">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Payment ID</TableHead>
                      <TableHead>Invoice #</TableHead>
                      <TableHead>Patient</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      {
                        id: "PAY-1001",
                        invoice: "INV-1001",
                        patient: "Sarah Johnson",
                        date: "Mar 15, 2025",
                        amount: "₹24,500",
                        method: "Credit Card",
                      },
                      {
                        id: "PAY-1002",
                        invoice: "INV-1003",
                        patient: "Emily Davis",
                        date: "Feb 28, 2025",
                        amount: "₹12,500",
                        method: "Debit Card",
                      },
                      {
                        id: "PAY-1003",
                        invoice: "INV-1006",
                        patient: "David Brown",
                        date: "Jan 30, 2025",
                        amount: "₹32,000",
                        method: "UPI",
                      },
                    ].map((payment, i) => (
                      <TableRow key={i}>
                        <TableCell>{payment.id}</TableCell>
                        <TableCell>{payment.invoice}</TableCell>
                        <TableCell className="font-medium">{payment.patient}</TableCell>
                        <TableCell>{payment.date}</TableCell>
                        <TableCell>{payment.amount}</TableCell>
                        <TableCell>{payment.method}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
            <TabsContent value="claims">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Claim ID</TableHead>
                      <TableHead>Patient</TableHead>
                      <TableHead>Insurance</TableHead>
                      <TableHead>Date Filed</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      {
                        id: "CLM-1001",
                        patient: "Michael Chen",
                        insurance: "HDFC ERGO",
                        date: "Mar 12, 2025",
                        amount: "₹75,000",
                        status: "In Process",
                      },
                      {
                        id: "CLM-1002",
                        patient: "Robert Wilson",
                        insurance: "Star Health",
                        date: "Feb 25, 2025",
                        amount: "₹42,000",
                        status: "Pending",
                      },
                      {
                        id: "CLM-1003",
                        patient: "Jennifer Lopez",
                        insurance: "Bajaj Allianz",
                        date: "Feb 18, 2025",
                        amount: "₹18,000",
                        status: "Approved",
                      },
                      {
                        id: "CLM-1004",
                        patient: "Emily Davis",
                        insurance: "ICICI Lombard",
                        date: "Jan 25, 2025",
                        amount: "₹35,000",
                        status: "Paid",
                      },
                    ].map((claim, i) => (
                      <TableRow key={i}>
                        <TableCell>{claim.id}</TableCell>
                        <TableCell className="font-medium">{claim.patient}</TableCell>
                        <TableCell>{claim.insurance}</TableCell>
                        <TableCell>{claim.date}</TableCell>
                        <TableCell>{claim.amount}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              claim.status === "Paid"
                                ? "default"
                                : claim.status === "Approved"
                                  ? "success"
                                  : claim.status === "In Process"
                                    ? "secondary"
                                    : "outline"
                            }
                          >
                            {claim.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              Track
                            </Button>
                            <Button size="sm">Update</Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Payment Methods</CardTitle>
            <CardDescription>Manage accepted payment methods</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  type: "Credit Card",
                  description: "Visa, Mastercard, American Express",
                  fee: "2.9% + ₹30",
                  status: "Active",
                },
                {
                  type: "Debit Card",
                  description: "All major debit cards",
                  fee: "1.5% + ₹30",
                  status: "Active",
                },
                {
                  type: "UPI",
                  description: "Google Pay, PhonePe, Paytm",
                  fee: "1.0%",
                  status: "Active",
                },
                {
                  type: "Insurance",
                  description: "Direct billing to insurance providers",
                  fee: "None",
                  status: "Active",
                },
                {
                  type: "Payment Plans",
                  description: "Monthly installment options",
                  fee: "None",
                  status: "Active",
                },
              ].map((method, i) => (
                <div key={i} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                  <div className="flex items-center space-x-4">
                    <div className="bg-primary/10 p-2 rounded-full">
                      <CreditCard className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{method.type}</p>
                      <p className="text-sm text-muted-foreground">{method.description}</p>
                      <p className="text-xs text-muted-foreground">Processing fee: {method.fee}</p>
                    </div>
                  </div>
                  <Badge variant={method.status === "Active" ? "default" : "outline"}>{method.status}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Insurance Providers</CardTitle>
            <CardDescription>Manage accepted insurance plans</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  name: "Star Health Insurance",
                  plans: "Family Health Optima, Senior Citizen",
                  status: "Active",
                },
                {
                  name: "HDFC ERGO",
                  plans: "Health Suraksha, My Health",
                  status: "Active",
                },
                {
                  name: "Bajaj Allianz",
                  plans: "Health Guard, Health Care Supreme",
                  status: "Active",
                },
                {
                  name: "ICICI Lombard",
                  plans: "Complete Health Insurance, Health Booster",
                  status: "Active",
                },
                {
                  name: "Max Bupa",
                  plans: "Health Companion, GoActive",
                  status: "Pending",
                },
              ].map((provider, i) => (
                <div key={i} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                  <div>
                    <p className="font-medium">{provider.name}</p>
                    <p className="text-sm text-muted-foreground">Plans: {provider.plans}</p>
                  </div>
                  <Badge variant={provider.status === "Active" ? "default" : "outline"}>{provider.status}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


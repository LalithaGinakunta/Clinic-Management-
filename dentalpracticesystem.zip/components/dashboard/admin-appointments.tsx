"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Calendar, Clock, Search, Filter } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const appointments = [
  {
    id: "1",
    patient: "Sarah Johnson",
    dentist: "Dr. Emily White",
    time: "9:00 AM",
    type: "Cleaning",
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "SJ",
  },
  {
    id: "2",
    patient: "Michael Brown",
    dentist: "Dr. James Miller",
    time: "10:30 AM",
    type: "Checkup",
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "MB",
  },
  {
    id: "3",
    patient: "Emily Davis",
    dentist: "Dr. Emily White",
    time: "11:45 AM",
    type: "Filling",
    status: "Pending",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "ED",
  },
  {
    id: "4",
    patient: "Robert Wilson",
    dentist: "Dr. James Miller",
    time: "1:15 PM",
    type: "Root Canal",
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "RW",
  },
  {
    id: "5",
    patient: "Jennifer Lee",
    dentist: "Dr. Emily White",
    time: "2:30 PM",
    type: "Checkup",
    status: "Confirmed",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "JL",
  },
]

export function AdminAppointments() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Today's Appointments</CardTitle>
          <CardDescription>Manage today's appointments and schedule</CardDescription>
        </div>
        <Button>
          <Calendar className="mr-2 h-4 w-4" />
          Schedule New
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4 justify-between">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder="Search appointments..." className="w-full pl-8" />
          </div>
          <div className="flex gap-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="confirmed">Confirmed</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="all">
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Filter by dentist" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Dentists</SelectItem>
                <SelectItem value="dr-white">Dr. Emily White</SelectItem>
                <SelectItem value="dr-miller">Dr. James Miller</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          {appointments.map((appointment) => (
            <div
              key={appointment.id}
              className="flex items-center justify-between space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
            >
              <div className="flex items-center space-x-4">
                <Avatar>
                  <AvatarImage src={appointment.avatar} alt={appointment.patient} />
                  <AvatarFallback className="bg-primary/10 text-primary">{appointment.initials}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium leading-none">{appointment.patient}</p>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="mr-1 h-3 w-3" />
                    {appointment.time} - {appointment.type}
                  </div>
                  <p className="text-xs text-muted-foreground">Dentist: {appointment.dentist}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge
                  variant={appointment.status === "Confirmed" ? "default" : "secondary"}
                  className={appointment.status === "Confirmed" ? "bg-green-500 hover:bg-green-600" : ""}
                >
                  {appointment.status}
                </Badge>
                <div className="flex space-x-1">
                  <Button size="sm" variant="outline">
                    Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}


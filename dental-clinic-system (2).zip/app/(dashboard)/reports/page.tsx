import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download, Calendar } from "lucide-react"
import { Chart, ChartContainer } from "@/components/ui/chart"
import {
  Bar,
  BarChart as RechartsBarChart,
  Line,
  LineChart as RechartsLineChart,
  Pie,
  PieChart as RechartsPieChart,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

export default function ReportsPage() {
  // Sample data for charts
  const revenueData = [
    { month: "Jan", revenue: 1250000 },
    { month: "Feb", revenue: 1420000 },
    { month: "Mar", revenue: 1680000 },
    { month: "Apr", revenue: 1530000 },
    { month: "May", revenue: 1750000 },
    { month: "Jun", revenue: 1820000 },
    { month: "Jul", revenue: 1950000 },
    { month: "Aug", revenue: 2010000 },
    { month: "Sep", revenue: 1980000 },
    { month: "Oct", revenue: 2150000 },
    { month: "Nov", revenue: 2280000 },
    { month: "Dec", revenue: 2450000 },
  ]

  const procedureData = [
    { name: "Cleanings", value: 35 },
    { name: "Fillings", value: 25 },
    { name: "Root Canals", value: 15 },
    { name: "Crowns", value: 10 },
    { name: "Extractions", value: 8 },
    { name: "Other", value: 7 },
  ]

  const patientData = [
    { month: "Jan", new: 24, returning: 65 },
    { month: "Feb", new: 28, returning: 59 },
    { month: "Mar", new: 32, returning: 78 },
    { month: "Apr", new: 26, returning: 72 },
    { month: "May", new: 30, returning: 80 },
    { month: "Jun", new: 34, returning: 85 },
  ]

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82ca9d"]

  // Format number to Indian currency format
  const formatIndianCurrency = (value: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reports & Analytics</h1>
          <p className="text-muted-foreground">View and generate reports on clinic performance</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            Date Range
          </Button>
          <Button>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <Tabs defaultValue="financial" className="space-y-4">
        <TabsList>
          <TabsTrigger value="financial">Financial</TabsTrigger>
          <TabsTrigger value="patients">Patients</TabsTrigger>
          <TabsTrigger value="procedures">Procedures</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>
        <TabsContent value="financial" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-green-800">Total Revenue (YTD)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-800">₹2,23,50,000</div>
                <p className="text-xs text-green-700">+18% from last year</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-blue-800">Average Revenue (Monthly)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-800">₹18,62,500</div>
                <p className="text-xs text-blue-700">+12% from last year</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-purple-800">Insurance Claims Paid</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-800">₹1,56,78,000</div>
                <p className="text-xs text-purple-700">92% claim approval rate</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-amber-800">Outstanding Payments</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-800">₹24,35,000</div>
                <p className="text-xs text-amber-700">-5% from last month</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div>
                  <CardTitle>Revenue Trends</CardTitle>
                  <CardDescription>Monthly revenue for the current year</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Select defaultValue="year">
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Select period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="year">This Year</SelectItem>
                      <SelectItem value="quarter">This Quarter</SelectItem>
                      <SelectItem value="month">This Month</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ChartContainer>
                  <Chart>
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsBarChart
                        data={revenueData}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`} />
                        <Tooltip formatter={(value) => [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Revenue"]} />
                        <Legend />
                        <Bar dataKey="revenue" fill="#3b82f6" name="Revenue (₹)" />
                      </RechartsBarChart>
                    </ResponsiveContainer>
                  </Chart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Revenue by Procedure</CardTitle>
                <CardDescription>Distribution of revenue by procedure type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={[
                              { name: "Implants", value: 4250000 },
                              { name: "Root Canals", value: 2850000 },
                              { name: "Cleanings", value: 1750000 },
                              { name: "Fillings", value: 1500000 },
                              { name: "Crowns", value: 1250000 },
                              { name: "Others", value: 850000 },
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {[
                              { name: "Implants", value: 4250000 },
                              { name: "Root Canals", value: 2850000 },
                              { name: "Cleanings", value: 1750000 },
                              { name: "Fillings", value: 1500000 },
                              { name: "Crowns", value: 1250000 },
                              { name: "Others", value: 850000 },
                            ].map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip
                            formatter={(value) => [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Revenue"]}
                          />
                          <Legend />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Monthly Expenses</CardTitle>
                <CardDescription>Breakdown of clinic expenses</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsBarChart
                          data={[
                            { category: "Staff", amount: 850000 },
                            { category: "Supplies", amount: 350000 },
                            { category: "Equipment", amount: 250000 },
                            { category: "Rent", amount: 180000 },
                            { category: "Utilities", amount: 75000 },
                            { category: "Marketing", amount: 65000 },
                            { category: "Others", amount: 120000 },
                          ]}
                          layout="vertical"
                          margin={{
                            top: 5,
                            right: 30,
                            left: 60,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis type="number" tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`} />
                          <YAxis dataKey="category" type="category" />
                          <Tooltip formatter={(value) => [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Amount"]} />
                          <Legend />
                          <Bar dataKey="amount" fill="#10b981" name="Expenses (₹)" />
                        </RechartsBarChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="patients" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,284</div>
                <p className="text-xs text-muted-foreground">+124 this year</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">New Patients (YTD)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">174</div>
                <p className="text-xs text-muted-foreground">+15% from last year</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Patient Retention</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">89%</div>
                <p className="text-xs text-muted-foreground">+3% from last year</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Avg. Patient Value</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹68,500</div>
                <p className="text-xs text-muted-foreground">+8% from last year</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Patient Demographics</CardTitle>
                <CardDescription>Age distribution of patients</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={[
                              { name: "0-18", value: 24 },
                              { name: "19-35", value: 32 },
                              { name: "36-50", value: 28 },
                              { name: "51+", value: 16 },
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {[
                              { name: "0-18", value: 24 },
                              { name: "19-35", value: 32 },
                              { name: "36-50", value: 28 },
                              { name: "51+", value: 16 },
                            ].map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Patient Growth</CardTitle>
                <CardDescription>New vs. returning patients</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer>
                    <Chart>
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsBarChart
                          data={patientData}
                          margin={{
                            top: 20,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="new" stackId="a" fill="#8884d8" name="New Patients" />
                          <Bar dataKey="returning" stackId="a" fill="#82ca9d" name="Returning Patients" />
                        </RechartsBarChart>
                      </ResponsiveContainer>
                    </Chart>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Patient Acquisition Channels</CardTitle>
              <CardDescription>How patients discover your clinic</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ChartContainer>
                  <Chart>
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsBarChart
                        data={[
                          { channel: "Referrals", patients: 42 },
                          { channel: "Google Search", patients: 28 },
                          { channel: "Social Media", patients: 15 },
                          { channel: "Insurance Network", patients: 10 },
                          { channel: "Website", patients: 8 },
                          { channel: "Other", patients: 5 },
                        ]}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="channel" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="patients" fill="#3b82f6" name="Patients (%)" />
                      </RechartsBarChart>
                    </ResponsiveContainer>
                  </Chart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="procedures" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Procedures (YTD)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">2,456</div>
                <p className="text-xs text-muted-foreground">+12% from last year</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Most Common Procedure</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">Cleanings</div>
                <p className="text-xs text-muted-foreground">35% of all procedures</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Avg. Procedure Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">45 min</div>
                <p className="text-xs text-muted-foreground">-5 min from last year</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Avg. Procedure Value</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹32,500</div>
                <p className="text-xs text-muted-foreground">+5% from last year</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Procedure Distribution</CardTitle>
              <CardDescription>Breakdown of procedures performed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ChartContainer>
                  <Chart>
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsPieChart>
                        <Pie
                          data={procedureData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {procedureData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                  </Chart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Procedure Trends</CardTitle>
              <CardDescription>Monthly procedure counts by type</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ChartContainer>
                  <Chart>
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsLineChart
                        data={[
                          { month: "Jan", cleanings: 85, fillings: 45, rootCanals: 12, crowns: 8 },
                          { month: "Feb", cleanings: 78, fillings: 52, rootCanals: 15, crowns: 10 },
                          { month: "Mar", cleanings: 92, fillings: 48, rootCanals: 18, crowns: 12 },
                          { month: "Apr", cleanings: 88, fillings: 55, rootCanals: 14, crowns: 9 },
                          { month: "May", cleanings: 95, fillings: 58, rootCanals: 20, crowns: 15 },
                          { month: "Jun", cleanings: 102, fillings: 62, rootCanals: 22, crowns: 18 },
                        ]}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="cleanings" stroke="#3b82f6" name="Cleanings" />
                        <Line type="monotone" dataKey="fillings" stroke="#10b981" name="Fillings" />
                        <Line type="monotone" dataKey="rootCanals" stroke="#f59e0b" name="Root Canals" />
                        <Line type="monotone" dataKey="crowns" stroke="#8b5cf6" name="Crowns" />
                      </RechartsLineChart>
                    </ResponsiveContainer>
                  </Chart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="performance" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Appointment Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">92%</div>
                <p className="text-xs text-muted-foreground">+3% from last year</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">No-Show Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4.5%</div>
                <p className="text-xs text-muted-foreground">-1.2% from last year</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Patient Satisfaction</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4.8/5</div>
                <p className="text-xs text-muted-foreground">Based on 324 reviews</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Staff Efficiency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">95%</div>
                <p className="text-xs text-muted-foreground">+2% from last quarter</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Performance Metrics</CardTitle>
              <CardDescription>Key performance indicators over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ChartContainer>
                  <Chart>
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsLineChart
                        data={[
                          { month: "Jan", satisfaction: 4.6, utilization: 88, noShow: 6.2 },
                          { month: "Feb", satisfaction: 4.7, utilization: 89, noShow: 5.8 },
                          { month: "Mar", satisfaction: 4.7, utilization: 90, noShow: 5.5 },
                          { month: "Apr", satisfaction: 4.8, utilization: 91, noShow: 5.0 },
                          { month: "May", satisfaction: 4.8, utilization: 92, noShow: 4.8 },
                          { month: "Jun", satisfaction: 4.9, utilization: 93, noShow: 4.5 },
                        ]}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis yAxisId="left" orientation="left" />
                        <YAxis yAxisId="right" orientation="right" />
                        <Tooltip />
                        <Legend />
                        <Line
                          yAxisId="left"
                          type="monotone"
                          dataKey="satisfaction"
                          stroke="#8884d8"
                          name="Satisfaction (1-5)"
                        />
                        <Line
                          yAxisId="left"
                          type="monotone"
                          dataKey="utilization"
                          stroke="#82ca9d"
                          name="Utilization (%)"
                        />
                        <Line
                          yAxisId="right"
                          type="monotone"
                          dataKey="noShow"
                          stroke="#ff7300"
                          name="No-Show Rate (%)"
                        />
                      </RechartsLineChart>
                    </ResponsiveContainer>
                  </Chart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Staff Performance</CardTitle>
              <CardDescription>Procedures completed by doctor</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ChartContainer>
                  <Chart>
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsBarChart
                        data={[
                          { name: "Dr. Johnson", procedures: 185, revenue: 4250000 },
                          { name: "Dr. Martinez", procedures: 162, revenue: 3850000 },
                          { name: "Dr. Patel", procedures: 145, revenue: 3250000 },
                          { name: "Dr. Gupta", procedures: 128, revenue: 2950000 },
                        ]}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis yAxisId="left" orientation="left" />
                        <YAxis
                          yAxisId="right"
                          orientation="right"
                          tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`}
                        />
                        <Tooltip
                          formatter={(value, name) => {
                            if (name === "revenue") {
                              return [`₹${(Number(value) / 100000).toFixed(2)} Lakhs`, "Revenue"]
                            }
                            return [value, "Procedures"]
                          }}
                        />
                        <Legend />
                        <Bar yAxisId="left" dataKey="procedures" fill="#3b82f6" name="Procedures" />
                        <Bar yAxisId="right" dataKey="revenue" fill="#10b981" name="Revenue (₹)" />
                      </RechartsBarChart>
                    </ResponsiveContainer>
                  </Chart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}


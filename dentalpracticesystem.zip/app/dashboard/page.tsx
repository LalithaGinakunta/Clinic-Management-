"use client"

import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { DentistDashboard } from "@/components/dashboard/dentist-dashboard"
import { AdminDashboard } from "@/components/dashboard/admin-dashboard"
import { PatientDashboard } from "@/components/dashboard/patient-dashboard"
import { useAuth } from "@/components/auth-provider"
import { Skeleton } from "@/components/ui/skeleton"

export default function DashboardPage() {
  const { user, isLoading } = useAuth()

  if (isLoading) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Dashboard" text="Loading your dashboard..." />
        <div className="p-4 md:p-8 pt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {Array(4)
              .fill(0)
              .map((_, i) => (
                <Skeleton key={i} className="h-[120px] w-full" />
              ))}
          </div>
          <Skeleton className="mt-6 h-[400px] w-full" />
        </div>
      </DashboardShell>
    )
  }

  if (!user) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Dashboard" text="Please log in to view your dashboard" />
      </DashboardShell>
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader
        heading={`${user.role === "dentist" ? "Dentist" : user.role === "admin" ? "Admin" : "Patient"} Dashboard`}
        text={`Welcome back, ${user.name}`}
      />
      {user.role === "dentist" && <DentistDashboard />}
      {user.role === "admin" && <AdminDashboard />}
      {user.role === "patient" && <PatientDashboard />}
    </DashboardShell>
  )
}


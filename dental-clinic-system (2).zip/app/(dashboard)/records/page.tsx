import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, FileText, UserPlus } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function RecordsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Patient Records</h1>
          <p className="text-muted-foreground">Manage electronic dental records and patient information</p>
        </div>
        <div className="flex items-center gap-2">
          <Button>
            <UserPlus className="mr-2 h-4 w-4" />
            New Patient
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div>
              <CardTitle>Patient Directory</CardTitle>
              <CardDescription>View and manage patient records</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Search patients..." className="pl-8 w-[250px]" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Filter by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Patients</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="new">New Patients</SelectItem>
                  <SelectItem value="treatment">In Treatment</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="space-y-4">
            <TabsList>
              <TabsTrigger value="all">All Patients</TabsTrigger>
              <TabsTrigger value="recent">Recently Visited</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming Appointments</TabsTrigger>
            </TabsList>
            <TabsContent value="all">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Patient ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Last Visit</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      {
                        id: "P-1001",
                        name: "Sarah Johnson",
                        contact: "(555) 123-4567",
                        lastVisit: "Mar 15, 2025",
                        status: "Active",
                      },
                      {
                        id: "P-1002",
                        name: "Michael Chen",
                        contact: "(555) 234-5678",
                        lastVisit: "Mar 10, 2025",
                        status: "In Treatment",
                      },
                      {
                        id: "P-1003",
                        name: "Emily Davis",
                        contact: "(555) 345-6789",
                        lastVisit: "Feb 28, 2025",
                        status: "Active",
                      },
                      {
                        id: "P-1004",
                        name: "Robert Wilson",
                        contact: "(555) 456-7890",
                        lastVisit: "Feb 22, 2025",
                        status: "Active",
                      },
                      {
                        id: "P-1005",
                        name: "Jennifer Lopez",
                        contact: "(555) 567-8901",
                        lastVisit: "Feb 15, 2025",
                        status: "New Patient",
                      },
                      {
                        id: "P-1006",
                        name: "David Brown",
                        contact: "(555) 678-9012",
                        lastVisit: "Jan 30, 2025",
                        status: "Inactive",
                      },
                    ].map((patient, i) => (
                      <TableRow key={i}>
                        <TableCell>{patient.id}</TableCell>
                        <TableCell className="font-medium">{patient.name}</TableCell>
                        <TableCell>{patient.contact}</TableCell>
                        <TableCell>{patient.lastVisit}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              patient.status === "Active"
                                ? "default"
                                : patient.status === "In Treatment"
                                  ? "secondary"
                                  : patient.status === "New Patient"
                                    ? "outline"
                                    : "destructive"
                            }
                          >
                            {patient.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                            <Button size="sm">
                              <FileText className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
            <TabsContent value="recent">
              <p>Recently visited patients would be displayed here.</p>
            </TabsContent>
            <TabsContent value="upcoming">
              <p>Patients with upcoming appointments would be displayed here.</p>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Patient Demographics</CardTitle>
            <CardDescription>Overview of patient population</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Age Groups</p>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">0-18</span>
                      <span className="text-sm font-medium">24%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 rounded-full bg-primary" style={{ width: "24%" }}></div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">19-35</span>
                      <span className="text-sm font-medium">32%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 rounded-full bg-primary" style={{ width: "32%" }}></div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">36-50</span>
                      <span className="text-sm font-medium">28%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 rounded-full bg-primary" style={{ width: "28%" }}></div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">51+</span>
                      <span className="text-sm font-medium">16%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 rounded-full bg-primary" style={{ width: "16%" }}></div>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Insurance Types</p>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Private</span>
                      <span className="text-sm font-medium">65%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 rounded-full bg-cyan-500" style={{ width: "65%" }}></div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Medicare</span>
                      <span className="text-sm font-medium">20%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 rounded-full bg-cyan-500" style={{ width: "20%" }}></div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Self-Pay</span>
                      <span className="text-sm font-medium">15%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 rounded-full bg-cyan-500" style={{ width: "15%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Medical Records</CardTitle>
            <CardDescription>Latest updates to patient records</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  patient: "Michael Chen",
                  type: "Treatment Plan",
                  date: "Mar 10, 2025",
                  doctor: "Dr. Martinez",
                  description: "Root canal treatment plan created",
                },
                {
                  patient: "Sarah Johnson",
                  type: "X-Ray Results",
                  date: "Mar 15, 2025",
                  doctor: "Dr. Johnson",
                  description: "Full mouth X-rays reviewed and documented",
                },
                {
                  patient: "Emily Davis",
                  type: "Medical History",
                  date: "Feb 28, 2025",
                  doctor: "Dr. Johnson",
                  description: "Updated allergy information",
                },
                {
                  patient: "Robert Wilson",
                  type: "Prescription",
                  date: "Feb 22, 2025",
                  doctor: "Dr. Martinez",
                  description: "Prescribed antibiotics for infection",
                },
              ].map((record, i) => (
                <div key={i} className="flex items-start space-x-4 border-b pb-4 last:border-0 last:pb-0">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <FileText className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{record.patient}</p>
                      <Badge variant="outline">{record.type}</Badge>
                    </div>
                    <p className="text-sm">{record.description}</p>
                    <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                      <span>{record.date}</span>
                      <span>{record.doctor}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


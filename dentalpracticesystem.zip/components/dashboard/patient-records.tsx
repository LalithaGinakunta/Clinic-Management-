"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { FileText, Download, Image, AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const medicalRecords = [
  {
    id: "1",
    date: "August 5, 2023",
    type: "Treatment Notes",
    description: "Filling on lower right molar",
    dentist: "Dr. Emily White",
    important: false,
  },
  {
    id: "2",
    date: "June 12, 2023",
    type: "Checkup Report",
    description: "Regular dental checkup and cleaning",
    dentist: "Dr. James Miller",
    important: false,
  },
  {
    id: "3",
    date: "March 3, 2023",
    type: "X-Ray Results",
    description: "Full mouth X-ray for assessment",
    dentist: "Dr. Emily White",
    important: true,
  },
]

const prescriptions = [
  {
    id: "1",
    date: "August 5, 2023",
    medication: "Amoxicillin",
    dosage: "500mg",
    instructions: "Take 1 tablet 3 times daily for 7 days",
    dentist: "Dr. Emily White",
    refills: 0,
  },
  {
    id: "2",
    date: "March 3, 2023",
    medication: "Ibuprofen",
    dosage: "400mg",
    instructions: "Take 1 tablet every 6 hours as needed for pain",
    dentist: "Dr. Emily White",
    refills: 1,
  },
]

const xrays = [
  {
    id: "1",
    date: "March 3, 2023",
    type: "Full Mouth X-Ray",
    description: "Comprehensive dental assessment",
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "2",
    date: "August 5, 2022",
    type: "Bitewing X-Ray",
    description: "Check for cavities between teeth",
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
]

export function PatientRecords() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Medical Records</CardTitle>
        <CardDescription>View your dental records, prescriptions, and X-rays</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="records">
          <TabsList className="mb-4">
            <TabsTrigger value="records">Treatment Records</TabsTrigger>
            <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
            <TabsTrigger value="xrays">X-Rays & Images</TabsTrigger>
          </TabsList>
          <TabsContent value="records">
            <div className="space-y-4">
              {medicalRecords.map((record) => (
                <div
                  key={record.id}
                  className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0 md:space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
                >
                  <div className="flex items-start space-x-4">
                    <div className={`rounded-full p-2 ${record.important ? "bg-red-100" : "bg-primary/10"}`}>
                      <FileText className={`h-5 w-5 ${record.important ? "text-red-500" : "text-primary"}`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{record.type}</p>
                        {record.important && (
                          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                            <AlertCircle className="mr-1 h-3 w-3" />
                            Important
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{record.description}</p>
                      <div className="flex items-center mt-1 text-xs text-muted-foreground">
                        <span>{record.date}</span>
                        <span className="mx-2">•</span>
                        <span>{record.dentist}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      <FileText className="mr-2 h-4 w-4" />
                      View
                    </Button>
                    <Button size="sm" variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="prescriptions">
            <div className="space-y-4">
              {prescriptions.map((prescription) => (
                <div
                  key={prescription.id}
                  className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0 md:space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
                >
                  <div>
                    <p className="font-medium">
                      {prescription.medication} ({prescription.dosage})
                    </p>
                    <p className="text-sm text-muted-foreground">{prescription.instructions}</p>
                    <div className="flex items-center mt-1 text-xs text-muted-foreground">
                      <span>{prescription.date}</span>
                      <span className="mx-2">•</span>
                      <span>{prescription.dentist}</span>
                      {prescription.refills > 0 && (
                        <>
                          <span className="mx-2">•</span>
                          <span className="text-green-600 font-medium">Refills: {prescription.refills}</span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button size="sm" variant="outline">
                      <FileText className="mr-2 h-4 w-4" />
                      View
                    </Button>
                    <Button size="sm" variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                    {prescription.refills > 0 && (
                      <Button size="sm" className="bg-green-500 hover:bg-green-600">
                        Request Refill
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="xrays">
            <div className="space-y-4">
              {xrays.map((xray) => (
                <div
                  key={xray.id}
                  className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0 md:space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
                >
                  <div className="flex items-start space-x-4">
                    <img
                      src={xray.thumbnail || "/placeholder.svg"}
                      alt={xray.type}
                      className="h-20 w-20 rounded-md object-cover border"
                    />
                    <div>
                      <p className="font-medium">{xray.type}</p>
                      <p className="text-sm text-muted-foreground">{xray.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">{xray.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button size="sm" variant="outline">
                      <Image className="mr-2 h-4 w-4" />
                      View
                    </Button>
                    <Button size="sm" variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}


import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, Package, AlertTriangle, ShoppingCart } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"

export default function InventoryPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Inventory Management</h1>
          <p className="text-muted-foreground">Track and manage dental supplies and equipment</p>
        </div>
        <div className="flex items-center gap-2">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add Item
          </Button>
          <Button variant="outline">
            <ShoppingCart className="mr-2 h-4 w-4" />
            Order Supplies
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-800">Total Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-800">248</div>
            <p className="text-xs text-blue-700">Across 12 categories</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-amber-800">Low Stock Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-800">15</div>
            <p className="text-xs text-amber-700">Need to reorder soon</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-red-800">Out of Stock</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-800">3</div>
            <p className="text-xs text-red-700">Urgent reorder required</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-800">Inventory Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-800">$45,680</div>
            <p className="text-xs text-green-700">Total current value</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div>
              <CardTitle>Inventory Items</CardTitle>
              <CardDescription>Manage dental supplies and equipment</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Search inventory..." className="pl-8 w-[250px]" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Filter by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Items</SelectItem>
                  <SelectItem value="low">Low Stock</SelectItem>
                  <SelectItem value="out">Out of Stock</SelectItem>
                  <SelectItem value="equipment">Equipment</SelectItem>
                  <SelectItem value="supplies">Supplies</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="space-y-4">
            <TabsList>
              <TabsTrigger value="all">All Items</TabsTrigger>
              <TabsTrigger value="supplies">Dental Supplies</TabsTrigger>
              <TabsTrigger value="equipment">Equipment</TabsTrigger>
              <TabsTrigger value="medications">Medications</TabsTrigger>
            </TabsList>
            <TabsContent value="all">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Stock Level</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      {
                        id: "INV-001",
                        name: "Composite Filling Material",
                        category: "Supplies",
                        stock: { current: 25, max: 100 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-002",
                        name: "Dental Anesthetic",
                        category: "Medications",
                        stock: { current: 8, max: 50 },
                        status: "Low Stock",
                      },
                      {
                        id: "INV-003",
                        name: "Dental Impression Material",
                        category: "Supplies",
                        stock: { current: 12, max: 40 },
                        status: "Low Stock",
                      },
                      {
                        id: "INV-004",
                        name: "Dental Burs",
                        category: "Supplies",
                        stock: { current: 45, max: 100 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-005",
                        name: "Sterilization Pouches",
                        category: "Supplies",
                        stock: { current: 0, max: 200 },
                        status: "Out of Stock",
                      },
                      {
                        id: "INV-006",
                        name: "Digital X-Ray Sensors",
                        category: "Equipment",
                        stock: { current: 4, max: 5 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-007",
                        name: "Dental Cement",
                        category: "Supplies",
                        stock: { current: 18, max: 30 },
                        status: "In Stock",
                      },
                    ].map((item, i) => (
                      <TableRow key={i}>
                        <TableCell>{item.id}</TableCell>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">
                                {item.stock.current} / {item.stock.max}
                              </span>
                              <span className="text-sm font-medium">
                                {Math.round((item.stock.current / item.stock.max) * 100)}%
                              </span>
                            </div>
                            <Progress value={(item.stock.current / item.stock.max) * 100} className="h-2" />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              item.status === "In Stock"
                                ? "default"
                                : item.status === "Low Stock"
                                  ? "outline"
                                  : "destructive"
                            }
                          >
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              Update
                            </Button>
                            <Button size="sm">Order</Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
            <TabsContent value="supplies">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Stock Level</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      {
                        id: "INV-001",
                        name: "Composite Filling Material",
                        category: "Restorative",
                        stock: { current: 25, max: 100 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-003",
                        name: "Dental Impression Material",
                        category: "Impression",
                        stock: { current: 12, max: 40 },
                        status: "Low Stock",
                      },
                      {
                        id: "INV-004",
                        name: "Dental Burs",
                        category: "Instruments",
                        stock: { current: 45, max: 100 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-005",
                        name: "Sterilization Pouches",
                        category: "Sterilization",
                        stock: { current: 0, max: 200 },
                        status: "Out of Stock",
                      },
                      {
                        id: "INV-007",
                        name: "Dental Cement",
                        category: "Restorative",
                        stock: { current: 18, max: 30 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-009",
                        name: "Dental Floss (Bulk)",
                        category: "Preventive",
                        stock: { current: 35, max: 50 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-011",
                        name: "Prophy Paste",
                        category: "Preventive",
                        stock: { current: 8, max: 30 },
                        status: "Low Stock",
                      },
                    ].map((item, i) => (
                      <TableRow key={i}>
                        <TableCell>{item.id}</TableCell>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">
                                {item.stock.current} / {item.stock.max}
                              </span>
                              <span className="text-sm font-medium">
                                {Math.round((item.stock.current / item.stock.max) * 100)}%
                              </span>
                            </div>
                            <Progress value={(item.stock.current / item.stock.max) * 100} className="h-2" />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              item.status === "In Stock"
                                ? "default"
                                : item.status === "Low Stock"
                                  ? "outline"
                                  : "destructive"
                            }
                          >
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              Update
                            </Button>
                            <Button size="sm">Order</Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
            <TabsContent value="equipment">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Stock Level</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      {
                        id: "INV-006",
                        name: "Digital X-Ray Sensors",
                        category: "Diagnostic",
                        stock: { current: 4, max: 5 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-012",
                        name: "Dental Chair",
                        category: "Furniture",
                        stock: { current: 3, max: 4 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-013",
                        name: "Autoclave",
                        category: "Sterilization",
                        stock: { current: 2, max: 2 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-014",
                        name: "Intraoral Camera",
                        category: "Diagnostic",
                        stock: { current: 1, max: 3 },
                        status: "Low Stock",
                      },
                      {
                        id: "INV-015",
                        name: "Dental Handpiece",
                        category: "Instruments",
                        stock: { current: 5, max: 8 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-016",
                        name: "Ultrasonic Scaler",
                        category: "Instruments",
                        stock: { current: 2, max: 4 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-017",
                        name: "Curing Light",
                        category: "Instruments",
                        stock: { current: 0, max: 3 },
                        status: "Out of Stock",
                      },
                    ].map((item, i) => (
                      <TableRow key={i}>
                        <TableCell>{item.id}</TableCell>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">
                                {item.stock.current} / {item.stock.max}
                              </span>
                              <span className="text-sm font-medium">
                                {Math.round((item.stock.current / item.stock.max) * 100)}%
                              </span>
                            </div>
                            <Progress value={(item.stock.current / item.stock.max) * 100} className="h-2" />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              item.status === "In Stock"
                                ? "default"
                                : item.status === "Low Stock"
                                  ? "outline"
                                  : "destructive"
                            }
                          >
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              Update
                            </Button>
                            <Button size="sm">Order</Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
            <TabsContent value="medications">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Stock Level</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      {
                        id: "INV-002",
                        name: "Dental Anesthetic",
                        category: "Anesthetics",
                        stock: { current: 8, max: 50 },
                        status: "Low Stock",
                      },
                      {
                        id: "INV-018",
                        name: "Antibiotics",
                        category: "Medications",
                        stock: { current: 15, max: 30 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-019",
                        name: "Pain Relievers",
                        category: "Medications",
                        stock: { current: 12, max: 40 },
                        status: "Low Stock",
                      },
                      {
                        id: "INV-020",
                        name: "Fluoride Gel",
                        category: "Preventive",
                        stock: { current: 20, max: 25 },
                        status: "In Stock",
                      },
                      {
                        id: "INV-021",
                        name: "Antiseptic Mouthwash",
                        category: "Preventive",
                        stock: { current: 5, max: 20 },
                        status: "Low Stock",
                      },
                      {
                        id: "INV-022",
                        name: "Topical Fluoride",
                        category: "Preventive",
                        stock: { current: 0, max: 15 },
                        status: "Out of Stock",
                      },
                    ].map((item, i) => (
                      <TableRow key={i}>
                        <TableCell>{item.id}</TableCell>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">
                                {item.stock.current} / {item.stock.max}
                              </span>
                              <span className="text-sm font-medium">
                                {Math.round((item.stock.current / item.stock.max) * 100)}%
                              </span>
                            </div>
                            <Progress value={(item.stock.current / item.stock.max) * 100} className="h-2" />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              item.status === "In Stock"
                                ? "default"
                                : item.status === "Low Stock"
                                  ? "outline"
                                  : "destructive"
                            }
                          >
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              Update
                            </Button>
                            <Button size="sm">Order</Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Low Stock Alerts</CardTitle>
            <CardDescription>Items that need to be reordered soon</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  name: "Dental Anesthetic",
                  id: "INV-002",
                  stock: { current: 8, max: 50 },
                  supplier: "MedDent Supplies",
                  lastOrdered: "Feb 15, 2025",
                },
                {
                  name: "Dental Impression Material",
                  id: "INV-003",
                  stock: { current: 12, max: 40 },
                  supplier: "DentalPro",
                  lastOrdered: "Jan 30, 2025",
                },
                {
                  name: "Sterilization Pouches",
                  id: "INV-005",
                  stock: { current: 0, max: 200 },
                  supplier: "MedDent Supplies",
                  lastOrdered: "Dec 10, 2024",
                },
              ].map((item, i) => (
                <div key={i} className="flex items-start space-x-4 border-b pb-4 last:border-0 last:pb-0">
                  <div className={`p-2 rounded-full ${item.stock.current === 0 ? "bg-red-100" : "bg-amber-100"}`}>
                    <AlertTriangle
                      className={`h-4 w-4 ${item.stock.current === 0 ? "text-red-600" : "text-amber-600"}`}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium">{item.name}</p>
                      <Badge variant={item.stock.current === 0 ? "destructive" : "outline"}>
                        {item.stock.current === 0 ? "Out of Stock" : "Low Stock"}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      ID: {item.id} | Supplier: {item.supplier}
                    </p>
                    <div className="mt-2 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">
                          {item.stock.current} / {item.stock.max}
                        </span>
                        <span className="text-sm font-medium">
                          {Math.round((item.stock.current / item.stock.max) * 100)}%
                        </span>
                      </div>
                      <Progress value={(item.stock.current / item.stock.max) * 100} className="h-2" />
                    </div>
                    <div className="mt-2 flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">Last ordered: {item.lastOrdered}</span>
                      <Button size="sm">Order Now</Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>Latest inventory orders and deliveries</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  id: "ORD-1001",
                  date: "Mar 15, 2025",
                  items: "Multiple items",
                  supplier: "MedDent Supplies",
                  status: "Delivered",
                  total: "$1,245.00",
                },
                {
                  id: "ORD-1002",
                  date: "Mar 10, 2025",
                  items: "Dental Burs (x50)",
                  supplier: "DentalPro",
                  status: "In Transit",
                  total: "$350.00",
                },
                {
                  id: "ORD-1003",
                  date: "Mar 5, 2025",
                  items: "Composite Filling Material",
                  supplier: "MedDent Supplies",
                  status: "Delivered",
                  total: "$780.00",
                },
                {
                  id: "ORD-1004",
                  date: "Feb 28, 2025",
                  items: "Sterilization Equipment",
                  supplier: "MedTech Solutions",
                  status: "Processing",
                  total: "$2,450.00",
                },
              ].map((order, i) => (
                <div key={i} className="flex items-start space-x-4 border-b pb-4 last:border-0 last:pb-0">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <Package className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium">Order #{order.id}</p>
                      <Badge
                        variant={
                          order.status === "Delivered"
                            ? "default"
                            : order.status === "In Transit"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {order.status}
                      </Badge>
                    </div>
                    <p className="text-sm">{order.items}</p>
                    <div className="mt-1 flex justify-between items-center">
                      <div className="text-xs text-muted-foreground">
                        <span>{order.date}</span>
                        <span className="mx-2">•</span>
                        <span>{order.supplier}</span>
                      </div>
                      <span className="font-medium">{order.total}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


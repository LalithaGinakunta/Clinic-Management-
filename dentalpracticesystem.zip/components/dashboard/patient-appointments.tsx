"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, Video } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const upcomingAppointments = [
  {
    id: "1",
    date: "September 15, 2023",
    time: "10:30 AM",
    type: "Dental Cleaning",
    dentist: "Dr. Emily White",
    location: "Main Office",
    status: "Confirmed",
    isVirtual: false,
  },
  {
    id: "2",
    date: "October 20, 2023",
    time: "2:00 PM",
    type: "Checkup",
    dentist: "Dr. James Miller",
    location: "Main Office",
    status: "Scheduled",
    isVirtual: true,
  },
]

const pastAppointments = [
  {
    id: "3",
    date: "August 5, 2023",
    time: "11:00 AM",
    type: "Filling",
    dentist: "Dr. Emily White",
    location: "Main Office",
    status: "Completed",
    isVirtual: false,
  },
  {
    id: "4",
    date: "June 12, 2023",
    time: "9:30 AM",
    type: "Checkup",
    dentist: "Dr. James Miller",
    location: "Main Office",
    status: "Completed",
    isVirtual: true,
  },
  {
    id: "5",
    date: "March 3, 2023",
    time: "1:15 PM",
    type: "X-Ray",
    dentist: "Dr. Emily White",
    location: "Main Office",
    status: "Completed",
    isVirtual: false,
  },
]

export function PatientAppointments() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>My Appointments</CardTitle>
          <CardDescription>View and manage your dental appointments</CardDescription>
        </div>
        <Button>
          <Calendar className="mr-2 h-4 w-4" />
          Book Appointment
        </Button>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="upcoming">
          <TabsList className="mb-4">
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="past">Past</TabsTrigger>
          </TabsList>
          <TabsContent value="upcoming">
            <div className="space-y-4">
              {upcomingAppointments.length > 0 ? (
                upcomingAppointments.map((appointment) => (
                  <div
                    key={appointment.id}
                    className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0 md:space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-primary" />
                        <p className="font-medium">{appointment.date}</p>
                        {appointment.isVirtual && (
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            <Video className="mr-1 h-3 w-3" />
                            Virtual
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center mt-1">
                        <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">
                          {appointment.time} - {appointment.type}
                        </p>
                      </div>
                      <div className="flex items-center mt-1">
                        <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">
                          {appointment.location} with {appointment.dentist}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={appointment.status === "Confirmed" ? "bg-green-500 hover:bg-green-600" : ""}>
                        {appointment.status}
                      </Badge>
                      <div className="flex space-x-2">
                        {appointment.isVirtual && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 hover:text-blue-800"
                          >
                            <Video className="mr-2 h-4 w-4" />
                            Join
                          </Button>
                        )}
                        <Button size="sm" variant="outline">
                          Reschedule
                        </Button>
                        <Button size="sm" variant="outline" className="border-red-200 text-red-700 hover:bg-red-50">
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Calendar className="h-10 w-10 text-muted-foreground mb-2" />
                  <h3 className="font-medium">No upcoming appointments</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    You don't have any upcoming appointments scheduled.
                  </p>
                  <Button>Book an Appointment</Button>
                </div>
              )}
            </div>
          </TabsContent>
          <TabsContent value="past">
            <div className="space-y-4">
              {pastAppointments.map((appointment) => (
                <div
                  key={appointment.id}
                  className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0 md:space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-primary" />
                      <p className="font-medium">{appointment.date}</p>
                      {appointment.isVirtual && (
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          <Video className="mr-1 h-3 w-3" />
                          Virtual
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center mt-1">
                      <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        {appointment.time} - {appointment.type}
                      </p>
                    </div>
                    <div className="flex items-center mt-1">
                      <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        {appointment.location} with {appointment.dentist}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline">{appointment.status}</Badge>
                    <Button size="sm" variant="outline">
                      View Details
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}


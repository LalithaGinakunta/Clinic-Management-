import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { InventoryOverview } from "@/components/inventory/inventory-overview"

export default function InventoryPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Inventory" text="Track dental supplies and equipment" />
      <InventoryOverview />
    </DashboardShell>
  )
}


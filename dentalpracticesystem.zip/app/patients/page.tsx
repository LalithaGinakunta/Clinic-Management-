import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { PatientsList } from "@/components/patients/patients-list"

export default function PatientsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Patients" text="Manage patient records and information" />
      <PatientsList />
    </DashboardShell>
  )
}


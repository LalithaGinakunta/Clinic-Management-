import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { BillingOverview } from "@/components/billing/billing-overview"

export default function BillingPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Billing & Payments" text="Manage invoices, payments, and insurance claims" />
      <BillingOverview />
    </DashboardShell>
  )
}


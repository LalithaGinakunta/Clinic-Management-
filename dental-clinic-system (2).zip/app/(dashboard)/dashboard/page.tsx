import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, Users, CreditCard, Package, AlertCircle, ArrowUpRight, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, Dr. Johnson. Here's an overview of your clinic today.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button>
            <Calendar className="mr-2 h-4 w-4" />
            Today's Schedule
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Today's Appointments</CardTitle>
                <Calendar className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-700">12</div>
                <p className="text-xs text-blue-600">3 pending confirmations</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Patients</CardTitle>
                <Users className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-700">1,284</div>
                <p className="text-xs text-green-600">+8 new patients this week</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
                <CreditCard className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-700">₹8,45,600</div>
                <p className="text-xs text-purple-600">5 insurance claims pending</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Inventory Alerts</CardTitle>
                <Package className="h-4 w-4 text-amber-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-700">3</div>
                <p className="text-xs text-amber-600">Items below threshold</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>Upcoming Appointments</CardTitle>
                <CardDescription>Your schedule for the next few hours</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      time: "9:00 AM",
                      patient: "Sarah Johnson",
                      procedure: "Dental Cleaning",
                      status: "Confirmed",
                      fee: "₹1,200",
                    },
                    {
                      time: "10:30 AM",
                      patient: "Michael Chen",
                      procedure: "Root Canal",
                      status: "Confirmed",
                      fee: "₹8,500",
                    },
                    {
                      time: "11:45 AM",
                      patient: "Emily Davis",
                      procedure: "Consultation",
                      status: "Pending",
                      fee: "₹800",
                    },
                    {
                      time: "2:15 PM",
                      patient: "Robert Wilson",
                      procedure: "Crown Fitting",
                      status: "Confirmed",
                      fee: "₹5,500",
                    },
                  ].map((appointment, i) => (
                    <div key={i} className="flex items-center justify-between border-b pb-2">
                      <div className="flex items-center space-x-4">
                        <div className="bg-primary/10 p-2 rounded-full">
                          <Clock className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">
                            {appointment.time} - {appointment.patient}
                          </p>
                          <p className="text-sm text-muted-foreground">{appointment.procedure}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-medium text-primary">{appointment.fee}</span>
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${
                            appointment.status === "Confirmed"
                              ? "bg-green-100 text-green-800"
                              : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {appointment.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4">
                  <Button variant="outline" asChild>
                    <Link href="/appointments">
                      View all appointments
                      <ArrowUpRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>Alerts & Notifications</CardTitle>
                <CardDescription>Important updates requiring your attention</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      title: "Low Inventory Alert",
                      description: "Composite filling material is running low",
                      type: "warning",
                    },
                    {
                      title: "Insurance Verification",
                      description: "Verify insurance for patient #1082 before appointment",
                      type: "info",
                    },
                    {
                      title: "Lab Results Ready",
                      description: "X-ray results for Emily Davis are ready for review",
                      type: "success",
                    },
                    {
                      title: "System Maintenance",
                      description: "Scheduled maintenance tonight at 11 PM",
                      type: "info",
                    },
                  ].map((alert, i) => (
                    <div
                      key={i}
                      className={`p-3 rounded-lg border ${
                        alert.type === "warning"
                          ? "bg-amber-50 border-amber-200"
                          : alert.type === "info"
                            ? "bg-blue-50 border-blue-200"
                            : "bg-green-50 border-green-200"
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <AlertCircle
                          className={`h-5 w-5 ${
                            alert.type === "warning"
                              ? "text-amber-600"
                              : alert.type === "info"
                                ? "text-blue-600"
                                : "text-green-600"
                          }`}
                        />
                        <div>
                          <p className="font-medium">{alert.title}</p>
                          <p className="text-sm">{alert.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹12,45,800</div>
                <p className="text-xs text-muted-foreground">+15% from last month</p>
                <div className="mt-4 h-1 w-full bg-muted">
                  <div className="h-1 w-3/4 bg-primary"></div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">New Patients</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">32</div>
                <p className="text-xs text-muted-foreground">+8% from last month</p>
                <div className="mt-4 h-1 w-full bg-muted">
                  <div className="h-1 w-2/3 bg-green-500"></div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Appointment Completion</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">94%</div>
                <p className="text-xs text-muted-foreground">+2% from last month</p>
                <div className="mt-4 h-1 w-full bg-muted">
                  <div className="h-1 w-[94%] bg-blue-500"></div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Treatment Value</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹3,850</div>
                <p className="text-xs text-muted-foreground">+5% from last month</p>
                <div className="mt-4 h-1 w-full bg-muted">
                  <div className="h-1 w-4/5 bg-purple-500"></div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Breakdown</CardTitle>
                <CardDescription>Revenue by procedure type</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {[
                    { name: "Dental Implants", value: "₹4,25,000", percentage: 34 },
                    { name: "Root Canals", value: "₹2,85,000", percentage: 23 },
                    { name: "Cleanings", value: "₹1,75,000", percentage: 14 },
                    { name: "Fillings", value: "₹1,50,000", percentage: 12 },
                    { name: "Crowns & Bridges", value: "₹1,25,000", percentage: 10 },
                    { name: "Others", value: "₹85,800", percentage: 7 },
                  ].map((item, i) => (
                    <div key={i} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-3 h-3 rounded-full bg-${
                              i === 0
                                ? "blue"
                                : i === 1
                                  ? "green"
                                  : i === 2
                                    ? "yellow"
                                    : i === 3
                                      ? "purple"
                                      : i === 4
                                        ? "pink"
                                        : "gray"
                            }-500`}
                          ></div>
                          <span className="text-sm font-medium">{item.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">{item.value}</span>
                          <span className="text-xs text-muted-foreground">{item.percentage}%</span>
                        </div>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-muted">
                        <div
                          className={`h-1.5 rounded-full bg-${
                            i === 0
                              ? "blue"
                              : i === 1
                                ? "green"
                                : i === 2
                                  ? "yellow"
                                  : i === 3
                                    ? "purple"
                                    : i === 4
                                      ? "pink"
                                      : "gray"
                          }-500`}
                          style={{ width: `${item.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Patient Demographics</CardTitle>
                <CardDescription>Patient age distribution</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex items-center justify-center h-[250px]">
                  <div className="w-[250px] h-[250px] rounded-full border-8 border-muted relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-3xl font-bold">1,284</div>
                        <div className="text-sm text-muted-foreground">Total Patients</div>
                      </div>
                    </div>
                    <div className="absolute top-0 left-0 w-full h-full">
                      <svg viewBox="0 0 100 100" className="w-full h-full rotate-[-90deg]">
                        <circle cx="50" cy="50" r="40" fill="none" stroke="#f0f0f0" strokeWidth="20" />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke="#3b82f6"
                          strokeWidth="20"
                          strokeDasharray="75.4 251.2"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke="#10b981"
                          strokeWidth="20"
                          strokeDasharray="100.5 251.2"
                          strokeDashoffset="-75.4"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke="#eab308"
                          strokeWidth="20"
                          strokeDasharray="50.2 251.2"
                          strokeDashoffset="-176"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke="#8b5cf6"
                          strokeWidth="20"
                          strokeDasharray="25.1 251.2"
                          strokeDashoffset="-226.1"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <div className="text-sm">0-18 (30%)</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <div className="text-sm">19-35 (40%)</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="text-sm">36-50 (20%)</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                    <div className="text-sm">51+ (10%)</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Monthly Trends</CardTitle>
              <CardDescription>Performance metrics over the last 6 months</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="h-[300px] w-full">
                <div className="flex h-full items-end gap-2">
                  {[
                    { month: "Jan", revenue: 65, patients: 45 },
                    { month: "Feb", revenue: 70, patients: 48 },
                    { month: "Mar", revenue: 85, patients: 52 },
                    { month: "Apr", revenue: 75, patients: 49 },
                    { month: "May", revenue: 90, patients: 55 },
                    { month: "Jun", revenue: 95, patients: 58 },
                  ].map((item, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-2">
                      <div className="w-full flex items-end justify-center gap-1 h-[250px]">
                        <div
                          className="w-5 bg-primary rounded-t-sm"
                          style={{ height: `${item.revenue * 2.5}px` }}
                        ></div>
                        <div
                          className="w-5 bg-green-500 rounded-t-sm"
                          style={{ height: `${item.patients * 4}px` }}
                        ></div>
                      </div>
                      <div className="text-xs font-medium">{item.month}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-center gap-6 mt-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-primary"></div>
                  <div className="text-sm">Revenue (₹ Lakhs)</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <div className="text-sm">New Patients</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div>
                  <CardTitle>Available Reports</CardTitle>
                  <CardDescription>Generate and download reports</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Button>
                    <Calendar className="mr-2 h-4 w-4" />
                    Custom Date Range
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    title: "Financial Summary",
                    description: "Revenue, expenses, and profit breakdown",
                    lastGenerated: "Today, 9:30 AM",
                    icon: CreditCard,
                  },
                  {
                    title: "Patient Statistics",
                    description: "New patients, appointments, and demographics",
                    lastGenerated: "Yesterday, 5:15 PM",
                    icon: Users,
                  },
                  {
                    title: "Procedure Analysis",
                    description: "Most common procedures and revenue by procedure",
                    lastGenerated: "Mar 25, 2025, 11:45 AM",
                    icon: FileText,
                  },
                  {
                    title: "Inventory Report",
                    description: "Current stock levels and usage trends",
                    lastGenerated: "Mar 20, 2025, 3:30 PM",
                    icon: Package,
                  },
                ].map((report, i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row justify-between gap-4">
                        <div className="flex items-start gap-4">
                          <div className="bg-primary/10 p-3 rounded-full">
                            <report.icon className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-medium text-lg">{report.title}</h3>
                            <p className="text-sm text-muted-foreground">{report.description}</p>
                            <p className="text-xs text-muted-foreground mt-1">Last generated: {report.lastGenerated}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 md:self-center">
                          <Button variant="outline">Preview</Button>
                          <Button>Generate Report</Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-medium mb-4">Recent Reports</h3>
                <div className="rounded-md border">
                  <div className="p-4 border-b">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Financial Summary - March 2025</p>
                        <p className="text-sm text-muted-foreground">Generated on Mar 28, 2025, 7:30 AM</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="p-4 border-b">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Patient Statistics - March 2025</p>
                        <p className="text-sm text-muted-foreground">Generated on Mar 27, 2025, 4:15 PM</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="p-4 border-b">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Procedure Analysis - Q1 2025</p>
                        <p className="text-sm text-muted-foreground">Generated on Mar 25, 2025, 11:45 AM</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Inventory Report - March 2025</p>
                        <p className="text-sm text-muted-foreground">Generated on Mar 20, 2025, 3:30 PM</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Download
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}


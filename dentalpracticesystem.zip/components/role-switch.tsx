"use client"

import { useUser } from "@/components/user-provider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

export function RoleSwitch() {
  const { user, setUser } = useUser()

  if (!user) return null

  const handleRoleChange = (role: string) => {
    // In a real app, this would involve authentication
    // For demo purposes, we're just switching the user object
    setUser({
      ...user,
      role: role as "dentist" | "admin" | "patient",
    })
  }

  return (
    <div className="space-y-2">
      <Label htmlFor="role-switch">Demo: Switch Role</Label>
      <Select value={user.role} onValueChange={handleRoleChange}>
        <SelectTrigger id="role-switch">
          <SelectValue placeholder="Select role" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="dentist">Dentist</SelectItem>
          <SelectItem value="admin">Admin</SelectItem>
          <SelectItem value="patient">Patient</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}


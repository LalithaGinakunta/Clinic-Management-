"use client"

import { useState, useEffect } from "react"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { AppointmentCalendar } from "@/components/appointments/appointment-calendar"
import { useUser } from "@/components/user-provider"
import { Skeleton } from "@/components/ui/skeleton"

export default function AppointmentsPage() {
  const { user, isLoading } = useUser()
  const [title, setTitle] = useState("Appointments")

  useEffect(() => {
    if (user) {
      switch (user.role) {
        case "dentist":
          setTitle("Appointment Schedule")
          break
        case "admin":
          setTitle("Appointment Management")
          break
        case "patient":
          setTitle("My Appointments")
          break
        default:
          setTitle("Appointments")
      }
    }
  }, [user])

  if (isLoading) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Appointments" text="Loading appointments..." />
        <div className="p-4 md:p-8 pt-6">
          <Skeleton className="h-[600px] w-full" />
        </div>
      </DashboardShell>
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader heading={title} text="View and manage appointments" />
      <AppointmentCalendar userRole={user?.role} />
    </DashboardShell>
  )
}


"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { FileText, Plus, Calendar } from "lucide-react"

const treatmentPlans = [
  {
    id: "1",
    patient: "Sarah Johnson",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "SJ",
    treatmentType: "Full Mouth Restoration",
    startDate: "June 15, 2023",
    endDate: "December 20, 2023",
    progress: 65,
    nextAppointment: "September 15, 2023",
    status: "In Progress",
    procedures: [
      { name: "Initial Consultation", completed: true },
      { name: "X-Rays and Imaging", completed: true },
      { name: "Root Canal (Tooth #18)", completed: true },
      { name: "Crown Placement (Tooth #18)", completed: false },
      { name: "Filling (Tooth #5)", completed: false },
      { name: "Final Review", completed: false },
    ],
  },
  {
    id: "2",
    patient: "Michael Brown",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "MB",
    treatmentType: "Orthodontic Treatment",
    startDate: "May 10, 2023",
    endDate: "November 10, 2024",
    progress: 20,
    nextAppointment: "September 20, 2023",
    status: "In Progress",
    procedures: [
      { name: "Initial Consultation", completed: true },
      { name: "X-Rays and Imaging", completed: true },
      { name: "Braces Installation", completed: true },
      { name: "First Adjustment", completed: false },
      { name: "Second Adjustment", completed: false },
      { name: "Final Removal", completed: false },
    ],
  },
  {
    id: "3",
    patient: "Emily Davis",
    avatar: "/placeholder.svg?height=32&width=32",
    initials: "ED",
    treatmentType: "Cavity Fillings",
    startDate: "August 5, 2023",
    endDate: "October 10, 2023",
    progress: 30,
    nextAppointment: "September 25, 2023",
    status: "In Progress",
    procedures: [
      { name: "Initial Consultation", completed: true },
      { name: "X-Rays and Imaging", completed: true },
      { name: "Filling (Tooth #14)", completed: false },
      { name: "Filling (Tooth #15)", completed: false },
      { name: "Final Review", completed: false },
    ],
  },
]

export function DentistTreatmentPlans() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Treatment Plans</CardTitle>
          <CardDescription>Active treatment plans for your patients</CardDescription>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          New Treatment Plan
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {treatmentPlans.map((plan) => (
            <div key={plan.id} className="rounded-lg border p-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-4">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={plan.avatar} alt={plan.patient} />
                    <AvatarFallback className="bg-primary/10 text-primary">{plan.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium">{plan.patient}</h3>
                    <p className="text-sm text-muted-foreground">{plan.treatmentType}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 items-center">
                  <Badge
                    variant={plan.status === "Completed" ? "default" : "outline"}
                    className={plan.status === "Completed" ? "bg-green-500 hover:bg-green-600" : ""}
                  >
                    {plan.status}
                  </Badge>
                  <div className="text-xs text-muted-foreground">
                    {plan.startDate} - {plan.endDate}
                  </div>
                  <Button size="sm" variant="outline">
                    <FileText className="mr-2 h-4 w-4" />
                    View Details
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>{plan.progress}%</span>
                </div>
                <Progress value={plan.progress} className="h-2" />
              </div>

              <div className="mt-4 grid gap-2">
                <div className="flex items-center text-sm">
                  <Calendar className="mr-2 h-4 w-4 text-primary" />
                  <span>Next appointment: {plan.nextAppointment}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
                  {plan.procedures.map((procedure, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm">
                      <div
                        className={`h-4 w-4 rounded-full flex items-center justify-center ${procedure.completed ? "bg-green-500" : "border border-muted-foreground"}`}
                      >
                        {procedure.completed && (
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="10"
                            height="10"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="4"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="text-white"
                          >
                            <polyline points="20 6 9 17 4 12"></polyline>
                          </svg>
                        )}
                      </div>
                      <span className={procedure.completed ? "line-through text-muted-foreground" : ""}>
                        {procedure.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}


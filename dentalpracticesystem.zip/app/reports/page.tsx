import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { ReportsOverview } from "@/components/reports/reports-overview"

export default function ReportsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Reports & Analytics" text="View practice performance and statistics" />
      <ReportsOverview />
    </DashboardShell>
  )
}


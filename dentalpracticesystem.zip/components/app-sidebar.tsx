"use client"

import {
  Calendar,
  ClipboardList,
  CreditCard,
  FileText,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Package,
  PieChart,
  Settings,
  Stethoscope,
  Users,
  Moon,
  Sun,
} from "lucide-react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import Image from "next/image"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/components/auth-provider"
import { Badge } from "@/components/ui/badge"
import { useTheme } from "next-themes"

export function AppSidebar() {
  const pathname = usePathname()
  const { user, logout } = useAuth()
  const { theme, setTheme } = useTheme()

  // Define menu items based on user role
  const getDentistMenuItems = () => [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      href: "/dashboard",
    },
    {
      title: "Appointments",
      icon: Calendar,
      href: "/appointments",
      badge: "12",
    },
    {
      title: "Patients",
      icon: Users,
      href: "/patients",
    },
    {
      title: "Treatment Plans",
      icon: ClipboardList,
      href: "/treatments",
    },
    {
      title: "Messages",
      icon: MessageSquare,
      href: "/messages",
      badge: "3",
    },
    {
      title: "Reports",
      icon: PieChart,
      href: "/reports",
    },
  ]

  const getAdminMenuItems = () => [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      href: "/dashboard",
    },
    {
      title: "Appointments",
      icon: Calendar,
      href: "/appointments",
      badge: "24",
    },
    {
      title: "Patients",
      icon: Users,
      href: "/patients",
    },
    {
      title: "Billing",
      icon: CreditCard,
      href: "/billing",
    },
    {
      title: "Inventory",
      icon: Package,
      href: "/inventory",
      badge: "3",
    },
    {
      title: "Staff",
      icon: Stethoscope,
      href: "/staff",
    },
    {
      title: "Reports",
      icon: PieChart,
      href: "/reports",
    },
  ]

  const getPatientMenuItems = () => [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      href: "/dashboard",
    },
    {
      title: "Appointments",
      icon: Calendar,
      href: "/appointments",
      badge: "1",
    },
    {
      title: "Medical Records",
      icon: FileText,
      href: "/records",
    },
    {
      title: "Billing",
      icon: CreditCard,
      href: "/billing",
    },
    {
      title: "Messages",
      icon: MessageSquare,
      href: "/messages",
      badge: "2",
    },
  ]

  const getMenuItems = () => {
    if (!user) return []

    switch (user.role) {
      case "dentist":
        return getDentistMenuItems()
      case "admin":
        return getAdminMenuItems()
      case "patient":
        return getPatientMenuItems()
      default:
        return []
    }
  }

  const menuItems = getMenuItems()

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  if (!user) {
    return (
      <Sidebar>
        <SidebarHeader className="border-b">
          <div className="flex items-center gap-2 px-2">
            <div className="relative w-10 h-10">
              <Image src="/images/dental-pro-logo.png" alt="Dental Pro Logo" fill className="object-contain" />
            </div>
            <span className="text-lg font-semibold">
              <span className="text-dental-blue">Dental</span>
              <span className="text-dental-pink"> Prō</span>
            </span>
          </div>
        </SidebarHeader>
        <SidebarContent>
          <div className="p-4 text-center">
            <p>Please log in to access the system.</p>
          </div>
        </SidebarContent>
      </Sidebar>
    )
  }

  return (
    <Sidebar>
      <SidebarHeader className="border-b">
        <div className="flex items-center gap-2 px-2">
          <div className="relative w-10 h-10">
            <Image src="/images/dental-pro-logo.png" alt="Dental Pro Logo" fill className="object-contain" />
          </div>
          <span className="text-lg font-semibold">
            <span className="text-dental-blue">Dental</span>
            <span className="text-dental-pink"> Prō</span>
          </span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <div className="px-4 py-2">
          <div className="flex items-center space-x-2 bg-muted/50 rounded-lg p-2 hover-card">
            <Avatar className="h-8 w-8 border-2 border-primary">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback className="bg-primary/10 text-primary">{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="space-y-0.5">
              <p className="text-sm font-medium">{user.name}</p>
              <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
            </div>
          </div>
        </div>
        <SidebarMenu>
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.href}>
              <SidebarMenuButton
                asChild
                isActive={pathname === item.href}
                tooltip={item.title}
                className="elegant-nav-item"
              >
                <Link href={item.href} className="relative">
                  <item.icon className="h-5 w-5" />
                  <span>{item.title}</span>
                  {item.badge && (
                    <Badge
                      variant="secondary"
                      className="absolute right-0 top-0 -translate-y-1/2 translate-x-1/2 bg-primary text-white elegant-badge"
                    >
                      {item.badge}
                    </Badge>
                  )}
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarSeparator />
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild className="elegant-nav-item">
              <Link href="/settings">
                <Settings className="h-5 w-5" />
                <span>Settings</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={toggleTheme} className="elegant-nav-item">
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              <span>{theme === "dark" ? "Light Mode" : "Dark Mode"}</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={logout} className="elegant-nav-item">
              <LogOut className="h-5 w-5" />
              <span>Log out</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      <SidebarTrigger className="absolute right-4 top-4 md:hidden" />
    </Sidebar>
  )
}


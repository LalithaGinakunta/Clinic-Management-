"use client"

import { useState, useEffect } from "react"
import { format, addMonths, startOfDay, addMinutes, isBefore } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { Clock, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { useUser } from "@/components/user-provider"

interface EnhancedAppointmentFormProps {
  isOpen: boolean
  onClose: () => void
  selectedDate?: Date
}

// Sample dentists data
const dentists = [
  {
    id: "dr-emily-white",
    name: "Dr. Emily White",
    specialization: "General Dentistry",
    availability: ["Monday", "Tuesday", "Wednesday", "Friday"],
  },
  {
    id: "dr-james-miller",
    name: "Dr. James Miller",
    specialization: "Orthodontics",
    availability: ["Monday", "Thursday", "Friday"],
  },
  {
    id: "dr-sarah-johnson",
    name: "Dr. Sarah Johnson",
    specialization: "Pediatric Dentistry",
    availability: ["Tuesday", "Wednesday", "Thursday"],
  },
]

// Sample appointment types
const appointmentTypes = [
  { id: "cleaning", name: "Dental Cleaning", duration: 30, price: 1500 },
  { id: "checkup", name: "Regular Checkup", duration: 45, price: 2000 },
  { id: "filling", name: "Dental Filling", duration: 60, price: 3500 },
  { id: "rootcanal", name: "Root Canal", duration: 90, price: 8000 },
  { id: "extraction", name: "Tooth Extraction", duration: 45, price: 2500 },
  { id: "consultation", name: "Initial Consultation", duration: 60, price: 1000 },
]

// Generate time slots from 9 AM to 5 PM with 30-minute intervals
const generateTimeSlots = (date: Date) => {
  const slots = []
  const startTime = new Date(date)
  startTime.setHours(9, 0, 0, 0)

  const endTime = new Date(date)
  endTime.setHours(17, 0, 0, 0)

  let currentTime = startTime

  while (currentTime < endTime) {
    slots.push({
      time: format(currentTime, "h:mm a"),
      dateTime: new Date(currentTime),
      available: Math.random() > 0.3, // Randomly mark some slots as unavailable for demo
    })
    currentTime = addMinutes(currentTime, 30)
  }

  return slots
}

export function EnhancedAppointmentForm({ isOpen, onClose, selectedDate = new Date() }: EnhancedAppointmentFormProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [date, setDate] = useState<Date | undefined>(selectedDate)
  const [appointmentType, setAppointmentType] = useState("")
  const [timeSlot, setTimeSlot] = useState("")
  const [dentist, setDentist] = useState("")
  const [notes, setNotes] = useState("")
  const [timeSlots, setTimeSlots] = useState<any[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const { user } = useUser()

  // Update time slots when date changes
  useEffect(() => {
    if (date) {
      setTimeSlots(generateTimeSlots(date))
    }
  }, [date])

  const selectedAppointmentType = appointmentTypes.find((type) => type.id === appointmentType)

  const handleNextStep = () => {
    if (currentStep === 1 && !appointmentType) {
      toast({
        title: "Please select an appointment type",
        variant: "destructive",
      })
      return
    }

    if (currentStep === 2 && !date) {
      toast({
        title: "Please select a date",
        variant: "destructive",
      })
      return
    }

    if (currentStep === 3 && !timeSlot) {
      toast({
        title: "Please select a time slot",
        variant: "destructive",
      })
      return
    }

    if (currentStep === 4 && !dentist) {
      toast({
        title: "Please select a dentist",
        variant: "destructive",
      })
      return
    }

    if (currentStep < 5) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSubmit = () => {
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      toast({
        title: "Appointment booked successfully!",
        description: `Your appointment has been scheduled for ${format(date!, "MMMM d, yyyy")} at ${timeSlot}`,
        variant: "default",
      })
      onClose()
    }, 1500)
  }

  const formatIndianCurrency = (value: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(value)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden">
        <DialogHeader className="px-6 pt-6 pb-2">
          <DialogTitle className="text-2xl font-bold">Book an Appointment</DialogTitle>
          <DialogDescription>Complete the steps below to schedule your dental appointment</DialogDescription>
        </DialogHeader>

        {/* Progress indicator */}
        <div className="px-6 py-2">
          <div className="flex justify-between mb-1">
            {[1, 2, 3, 4, 5].map((step) => (
              <div key={step} className="flex flex-col items-center">
                <div
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors",
                    currentStep === step
                      ? "bg-primary text-primary-foreground"
                      : currentStep > step
                        ? "bg-primary/20 text-primary"
                        : "bg-muted text-muted-foreground",
                  )}
                >
                  {currentStep > step ? <CheckCircle2 className="h-4 w-4" /> : step}
                </div>
                <span className="text-xs mt-1 text-muted-foreground">
                  {step === 1
                    ? "Service"
                    : step === 2
                      ? "Date"
                      : step === 3
                        ? "Time"
                        : step === 4
                          ? "Dentist"
                          : "Confirm"}
                </span>
              </div>
            ))}
          </div>
          <div className="w-full bg-muted h-1 mt-2 rounded-full overflow-hidden">
            <div
              className="bg-primary h-full transition-all duration-300 ease-in-out"
              style={{ width: `${((currentStep - 1) / 4) * 100}%` }}
            />
          </div>
        </div>

        <div className="p-6">
          {/* Step 1: Select appointment type */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Select Service Type</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {appointmentTypes.map((type) => (
                  <Card
                    key={type.id}
                    className={cn(
                      "cursor-pointer hover:border-primary transition-colors hover-card",
                      appointmentType === type.id && "border-primary bg-primary/5",
                    )}
                    onClick={() => setAppointmentType(type.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium">{type.name}</h4>
                          <p className="text-sm text-muted-foreground">{type.duration} minutes</p>
                        </div>
                        <Badge variant="outline">{formatIndianCurrency(type.price)}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Select date */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Select Date</h3>
              <div className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  disabled={(date) => isBefore(date, startOfDay(new Date())) || date > addMonths(new Date(), 2)}
                  className="rounded-md border"
                />
              </div>
            </div>
          )}

          {/* Step 3: Select time slot */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Select Time</h3>
              <p className="text-sm text-muted-foreground">Available time slots for {format(date!, "MMMM d, yyyy")}</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {timeSlots.map((slot, index) => (
                  <Button
                    key={index}
                    variant={timeSlot === slot.time ? "default" : "outline"}
                    className={cn("justify-start", !slot.available && "opacity-50 cursor-not-allowed")}
                    disabled={!slot.available}
                    onClick={() => setTimeSlot(slot.time)}
                  >
                    <Clock className="mr-2 h-4 w-4" />
                    {slot.time}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Step 4: Select dentist */}
          {currentStep === 4 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Select Dentist</h3>
              <div className="grid grid-cols-1 gap-3">
                {dentists.map((doc) => (
                  <Card
                    key={doc.id}
                    className={cn(
                      "cursor-pointer hover:border-primary transition-colors hover-card",
                      dentist === doc.id && "border-primary bg-primary/5",
                    )}
                    onClick={() => setDentist(doc.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium">{doc.name}</h4>
                          <p className="text-sm text-muted-foreground">{doc.specialization}</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {doc.availability.map((day) => (
                              <Badge key={day} variant="outline" className="text-xs">
                                {day}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Step 5: Confirmation */}
          {currentStep === 5 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Confirm Your Appointment</h3>
              <div className="rounded-lg border p-4 space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Service:</span>
                  <span className="font-medium">{selectedAppointmentType?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Date:</span>
                  <span className="font-medium">{format(date!, "MMMM d, yyyy")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Time:</span>
                  <span className="font-medium">{timeSlot}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Dentist:</span>
                  <span className="font-medium">{dentists.find((doc) => doc.id === dentist)?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Duration:</span>
                  <span className="font-medium">{selectedAppointmentType?.duration} minutes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Price:</span>
                  <span className="font-medium">{formatIndianCurrency(selectedAppointmentType?.price || 0)}</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Additional Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Any specific concerns or information you'd like to share with the dentist"
                  className="elegant-input"
                />
              </div>

              <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 flex items-start space-x-2">
                <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
                <div className="text-sm text-amber-800">
                  <p className="font-medium">Please Note:</p>
                  <p>
                    Appointments can be rescheduled or cancelled up to 24 hours before the scheduled time without any
                    charges.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="px-6 py-4 border-t">
          {currentStep > 1 && (
            <Button variant="outline" onClick={handlePreviousStep} className="mr-auto">
              Back
            </Button>
          )}

          {currentStep < 5 ? (
            <Button onClick={handleNextStep} className="elegant-button">
              Continue <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={isSubmitting} className="elegant-button">
              {isSubmitting ? "Booking..." : "Confirm Booking"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}


"use client"

import { useState } from "react"
import { ChevronDown, Download, FileText, MoreHorizontal, Plus, Search, SlidersHorizontal } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PatientDetails } from "@/components/patients/patient-details"

// Sample patient data
const patients = [
  {
    id: "1",
    name: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    phone: "(555) 123-4567",
    lastVisit: "2023-03-15",
    nextAppointment: "2023-09-20",
    status: "Active",
  },
  {
    id: "2",
    name: "Michael Brown",
    email: "michael.brown@example.com",
    phone: "(555) 234-5678",
    lastVisit: "2023-02-28",
    nextAppointment: "2023-09-25",
    status: "Active",
  },
  {
    id: "3",
    name: "Emily Davis",
    email: "emily.davis@example.com",
    phone: "(555) 345-6789",
    lastVisit: "2023-04-10",
    nextAppointment: null,
    status: "Inactive",
  },
  {
    id: "4",
    name: "Robert Wilson",
    email: "robert.wilson@example.com",
    phone: "(555) 456-7890",
    lastVisit: "2023-05-05",
    nextAppointment: "2023-09-18",
    status: "Active",
  },
  {
    id: "5",
    name: "Jennifer Lee",
    email: "jennifer.lee@example.com",
    phone: "(555) 567-8901",
    lastVisit: "2023-01-20",
    nextAppointment: "2023-10-05",
    status: "Active",
  },
  {
    id: "6",
    name: "David Martinez",
    email: "david.martinez@example.com",
    phone: "(555) 678-9012",
    lastVisit: "2022-11-15",
    nextAppointment: null,
    status: "Inactive",
  },
  {
    id: "7",
    name: "Lisa Anderson",
    email: "lisa.anderson@example.com",
    phone: "(555) 789-0123",
    lastVisit: "2023-06-30",
    nextAppointment: "2023-09-30",
    status: "Active",
  },
]

export function PatientsList() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null)

  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      patient.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      patient.phone.includes(searchQuery),
  )

  return (
    <div className="p-4 md:p-8 pt-6">
      <div className="flex flex-col space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search patients..."
              className="w-full pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <SlidersHorizontal className="mr-2 h-4 w-4" />
              Filter
            </Button>
            <Button variant="outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Add Patient
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="px-6 py-4">
            <CardTitle>Patients</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Last Visit</TableHead>
                  <TableHead>Next Appointment</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[80px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPatients.map((patient) => (
                  <TableRow key={patient.id}>
                    <TableCell
                      className="font-medium cursor-pointer hover:underline"
                      onClick={() => setSelectedPatient(patient.id)}
                    >
                      {patient.name}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="text-sm">{patient.email}</span>
                        <span className="text-sm text-muted-foreground">{patient.phone}</span>
                      </div>
                    </TableCell>
                    <TableCell>{patient.lastVisit}</TableCell>
                    <TableCell>{patient.nextAppointment || "Not scheduled"}</TableCell>
                    <TableCell>
                      <Badge variant={patient.status === "Active" ? "default" : "secondary"}>{patient.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => setSelectedPatient(patient.id)}>
                            <FileText className="mr-2 h-4 w-4" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <ChevronDown className="mr-2 h-4 w-4" />
                            Schedule Appointment
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>Edit Patient</DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">Delete Patient</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {selectedPatient && <PatientDetails patientId={selectedPatient} onClose={() => setSelectedPatient(null)} />}
    </div>
  )
}


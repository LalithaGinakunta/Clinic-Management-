"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CreditCard, FileText, CheckCircle } from "lucide-react"
import { Progress } from "@/components/ui/progress"

// Function to format Indian currency
const formatIndianCurrency = (value: number) => {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value)
}

const invoices = [
  {
    id: "INV-001",
    date: "August 5, 2023",
    service: "Filling",
    amount: 15000,
    status: "Unpaid",
    dueDate: "September 30, 2023",
  },
  {
    id: "INV-002",
    date: "June 12, 2023",
    service: "Checkup and Cleaning",
    amount: 12000,
    status: "Paid",
    paidDate: "June 15, 2023",
  },
  {
    id: "INV-003",
    date: "March 3, 2023",
    service: "X-Ray",
    amount: 8000,
    status: "Paid",
    paidDate: "March 10, 2023",
  },
]

const insuranceClaims = [
  {
    id: "CLM-001",
    date: "August 5, 2023",
    service: "Filling",
    amount: 12000,
    status: "Pending",
    provider: "BlueCross BlueShield",
    progress: 30,
  },
  {
    id: "CLM-002",
    date: "June 12, 2023",
    service: "Checkup and Cleaning",
    amount: 10000,
    status: "Approved",
    provider: "BlueCross BlueShield",
    progress: 100,
  },
  {
    id: "CLM-003",
    date: "March 3, 2023",
    service: "X-Ray",
    amount: 6000,
    status: "Approved",
    provider: "BlueCross BlueShield",
    progress: 100,
  },
]

export function PatientBilling() {
  return (
    <Card className="elegant-card">
      <CardHeader>
        <CardTitle>Billing & Payments</CardTitle>
        <CardDescription>View and manage your invoices and insurance claims</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="invoices">
          <TabsList className="mb-4">
            <TabsTrigger value="invoices">Invoices</TabsTrigger>
            <TabsTrigger value="insurance">Insurance Claims</TabsTrigger>
            <TabsTrigger value="payment">Make a Payment</TabsTrigger>
          </TabsList>
          <TabsContent value="invoices">
            <div className="space-y-4">
              {invoices.map((invoice) => (
                <div
                  key={invoice.id}
                  className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0 md:space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50 hover-card"
                >
                  <div>
                    <div className="flex items-center">
                      <FileText className="mr-2 h-4 w-4 text-primary" />
                      <p className="font-medium">{invoice.id}</p>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{invoice.service}</p>
                    <div className="flex items-center mt-1 text-xs text-muted-foreground">
                      <span>{invoice.date}</span>
                      {invoice.status === "Unpaid" ? (
                        <>
                          <span className="mx-2">•</span>
                          <span className="text-amber-600">Due: {invoice.dueDate}</span>
                        </>
                      ) : (
                        <>
                          <span className="mx-2">•</span>
                          <span className="text-green-600">Paid: {invoice.paidDate}</span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="font-medium">{formatIndianCurrency(invoice.amount)}</p>
                      <Badge
                        variant={invoice.status === "Paid" ? "default" : "outline"}
                        className={
                          invoice.status === "Paid"
                            ? "bg-green-500 hover:bg-green-600 elegant-badge"
                            : "border-amber-200 bg-amber-50 text-amber-700 elegant-badge"
                        }
                      >
                        {invoice.status === "Paid" && <CheckCircle className="mr-1 h-3 w-3" />}
                        {invoice.status}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button size="sm" variant="outline" className="elegant-button">
                        <FileText className="mr-2 h-4 w-4" />
                        View
                      </Button>
                      {invoice.status === "Unpaid" && (
                        <Button size="sm" className="bg-primary hover:bg-primary/90 elegant-button">
                          <CreditCard className="mr-2 h-4 w-4" />
                          Pay
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="insurance">
            <div className="space-y-4">
              {insuranceClaims.map((claim) => (
                <div
                  key={claim.id}
                  className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0 md:space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50 hover-card"
                >
                  <div className="flex-1">
                    <div className="flex items-center">
                      <FileText className="mr-2 h-4 w-4 text-primary" />
                      <p className="font-medium">{claim.id}</p>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{claim.service}</p>
                    <div className="flex items-center mt-1 text-xs text-muted-foreground">
                      <span>{claim.date}</span>
                      <span className="mx-2">•</span>
                      <span>{claim.provider}</span>
                    </div>
                    <div className="mt-2">
                      <div className="flex justify-between text-xs mb-1">
                        <span>Claim Progress</span>
                        <span>{claim.progress}%</span>
                      </div>
                      <Progress
                        value={claim.progress}
                        className="h-2"
                        indicatorClassName={
                          claim.status === "Approved"
                            ? "bg-green-500"
                            : claim.status === "Pending"
                              ? "bg-amber-500"
                              : "bg-red-500"
                        }
                      />
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="font-medium">{formatIndianCurrency(claim.amount)}</p>
                      <Badge
                        variant={
                          claim.status === "Approved"
                            ? "default"
                            : claim.status === "Pending"
                              ? "outline"
                              : "destructive"
                        }
                        className={
                          claim.status === "Approved"
                            ? "bg-green-500 hover:bg-green-600 elegant-badge"
                            : claim.status === "Pending"
                              ? "border-amber-200 bg-amber-50 text-amber-700 elegant-badge"
                              : "elegant-badge"
                        }
                      >
                        {claim.status}
                      </Badge>
                    </div>
                    <Button size="sm" variant="outline" className="elegant-button">
                      <FileText className="mr-2 h-4 w-4" />
                      Details
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="payment">
            <div className="space-y-6 max-w-md mx-auto">
              <div className="border rounded-md p-6 hover-card">
                <h3 className="text-lg font-medium mb-4">Make a Payment</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Select Invoice</label>
                    <select className="w-full p-2 border rounded-md elegant-input">
                      <option value="INV-001">INV-001 - ₹15,000 (Filling)</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Payment Method</label>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="border rounded-md p-3 flex items-center space-x-2 cursor-pointer bg-muted/50 hover:bg-muted transition-colors">
                        <CreditCard className="h-5 w-5 text-primary" />
                        <span>Credit Card</span>
                      </div>
                      <div className="border rounded-md p-3 flex items-center space-x-2 cursor-pointer hover:bg-muted/50 transition-colors">
                        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path
                            d="M6 12H18M12 6V18"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <span>Other</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Card Information</label>
                    <input
                      type="text"
                      placeholder="Card Number"
                      className="w-full p-2 border rounded-md mb-2 elegant-input"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input type="text" placeholder="MM/YY" className="p-2 border rounded-md elegant-input" />
                      <input type="text" placeholder="CVC" className="p-2 border rounded-md elegant-input" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Billing Address</label>
                    <input
                      type="text"
                      placeholder="Name on Card"
                      className="w-full p-2 border rounded-md mb-2 elegant-input"
                    />
                    <input
                      type="text"
                      placeholder="Address"
                      className="w-full p-2 border rounded-md mb-2 elegant-input"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input type="text" placeholder="City" className="p-2 border rounded-md elegant-input" />
                      <input type="text" placeholder="PIN Code" className="p-2 border rounded-md elegant-input" />
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button className="w-full bg-primary hover:bg-primary/90 elegant-button">Pay ₹15,000</Button>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}


"use client"

import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendItem,
} from "@/components/ui/chart"
import { Cell, Pie, PieChart, ResponsiveContainer, Line, LineChart, CartesianGrid, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const patientAgeData = [
  { name: "0-18", value: 15, color: "hsl(var(--primary))" },
  { name: "19-35", value: 30, color: "hsl(var(--primary) / 0.8)" },
  { name: "36-50", value: 25, color: "hsl(var(--primary) / 0.6)" },
  { name: "51-65", value: 20, color: "hsl(var(--primary) / 0.4)" },
  { name: "65+", value: 10, color: "hsl(var(--primary) / 0.2)" },
]

const newPatientsData = [
  { name: "Jan", patients: 10 },
  { name: "Feb", patients: 15 },
  { name: "Mar", patients: 12 },
  { name: "Apr", patients: 18 },
  { name: "May", patients: 20 },
  { name: "Jun", patients: 25 },
  { name: "Jul", patients: 22 },
  { name: "Aug", patients: 30 },
  { name: "Sep", patients: 28 },
  { name: "Oct", patients: 35 },
  { name: "Nov", patients: 32 },
  { name: "Dec", patients: 40 },
]

export function PatientReport() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Patient Age Distribution</CardTitle>
          <CardDescription>Breakdown of patients by age group</CardDescription>
        </CardHeader>
        <CardContent>
          <Chart className="h-[300px]">
            <ChartLegend className="mb-4 justify-center gap-6">
              {patientAgeData.map((entry) => (
                <ChartLegendItem key={entry.name} name={entry.name} color={entry.color} />
              ))}
            </ChartLegend>
            <ChartContainer>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={patientAgeData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {patientAgeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <ChartTooltip content={<ChartTooltipContent />} />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </Chart>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>New Patients</CardTitle>
          <CardDescription>Monthly new patient acquisitions</CardDescription>
        </CardHeader>
        <CardContent>
          <Chart className="h-[300px]">
            <ChartContainer>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={newPatientsData}
                  margin={{
                    top: 5,
                    right: 10,
                    left: 10,
                    bottom: 0,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="name" className="text-sm text-muted-foreground" tickLine={false} axisLine={false} />
                  <YAxis className="text-sm text-muted-foreground" tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="patients"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    dot={{ r: 4, fill: "hsl(var(--primary))" }}
                    activeDot={{ r: 6, fill: "hsl(var(--primary))" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </Chart>
        </CardContent>
      </Card>

      <Card className="col-span-2">
        <CardHeader>
          <CardTitle>Patient Retention</CardTitle>
          <CardDescription>Patient retention metrics and statistics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2 border rounded-md p-4">
              <p className="text-sm font-medium text-muted-foreground">Total Patients</p>
              <p className="text-3xl font-bold">1,245</p>
              <p className="text-xs text-muted-foreground">+15% from last year</p>
            </div>
            <div className="space-y-2 border rounded-md p-4">
              <p className="text-sm font-medium text-muted-foreground">Active Patients</p>
              <p className="text-3xl font-bold">987</p>
              <p className="text-xs text-muted-foreground">79% of total patients</p>
            </div>
            <div className="space-y-2 border rounded-md p-4">
              <p className="text-sm font-medium text-muted-foreground">Retention Rate</p>
              <p className="text-3xl font-bold">85%</p>
              <p className="text-xs text-muted-foreground">+5% from last year</p>
            </div>
          </div>
          <div className="mt-6 flex justify-center">
            <Button>Generate Detailed Patient Report</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

